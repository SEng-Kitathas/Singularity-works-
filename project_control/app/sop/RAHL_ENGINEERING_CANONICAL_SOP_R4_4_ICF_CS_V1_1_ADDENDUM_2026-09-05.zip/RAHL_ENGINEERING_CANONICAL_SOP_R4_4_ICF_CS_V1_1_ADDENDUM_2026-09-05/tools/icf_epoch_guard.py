from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
import argparse,hashlib,json,os,tempfile,time
CLASSES=('intent','constraints','frontier','history')
SCHEMA='icf-cs.epoch-state.v1'
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha_file(p):return sha_bytes(Path(p).read_bytes())
@contextmanager
def exclusive_lock(state_path):
 lp=Path(str(state_path)+'.lock');lp.parent.mkdir(parents=True,exist_ok=True)
 f=open(lp,'a+b')
 try:
  if os.name=='nt':
   import msvcrt
   f.seek(0,2)
   if f.tell()==0:f.write(b'0');f.flush()
   f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_LOCK,1)
  else:
   import fcntl;fcntl.flock(f.fileno(),fcntl.LOCK_EX)
  yield
 finally:
  try:
   f.seek(0)
   if os.name=='nt':
    import msvcrt;msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
   else:
    import fcntl;fcntl.flock(f.fileno(),fcntl.LOCK_UN)
  finally:f.close()
def load_unlocked(p):
 d=json.loads(Path(p).read_text(encoding='utf-8'))
 if d.get('schema')!=SCHEMA or set(d.get('classes',{}))!=set(CLASSES):raise ValueError('bad epoch-state schema/classes')
 for c in CLASSES:
  e=d['classes'][c]
  if not isinstance(e.get('epoch'),int) or e['epoch']<1:raise ValueError('bad epoch '+c)
  if not isinstance(e.get('sha256'),str) or len(e['sha256'])!=64:raise ValueError('bad sha '+c)
  if not isinstance(e.get('source_id'),str) or not e['source_id'].strip():raise ValueError('bad source_id '+c)
  if not isinstance(e.get('source_path'),str) or not e['source_path'].strip():raise ValueError('bad source_path '+c)
 return d
def atomic_write(path,data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix=path.name+'.',dir=str(path.parent));os.close(fd)
 try:
  if isinstance(data,bytes):Path(tmp).write_bytes(data)
  else:Path(tmp).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
  os.replace(tmp,path)
 finally:
  if Path(tmp).exists():Path(tmp).unlink()
def validate_sources(d,classes=CLASSES):
 for c in classes:
  e=d['classes'][c];p=Path(e['source_path'])
  if not p.exists():return False,'MISSING_SOURCE '+c
  if sha_file(p)!=e['sha256']:return False,'UNTRACKED_SOURCE_DRIFT '+c
 return True,'CURRENT'
def token(d):return {c:{k:d['classes'][c][k] for k in ('epoch','sha256','source_id')} for c in CLASSES}
def snapshot(state_path):
 with exclusive_lock(state_path):
  d=load_unlocked(state_path);ok,msg=validate_sources(d)
  if not ok:return False,msg,None
  return True,'CURRENT',token(d)
def verify_token(state_path,tok,classes=CLASSES):
 with exclusive_lock(state_path):
  d=load_unlocked(state_path);ok,msg=validate_sources(d,classes)
  if not ok:return False,msg
  for c in classes:
   if c not in tok:return False,'MISSING_TOKEN '+c
   cur=d['classes'][c];exp=tok[c]
   if cur['epoch']!=exp.get('epoch') or cur['sha256']!=exp.get('sha256') or cur['source_id']!=exp.get('source_id'):return False,'STALE_TOKEN '+c
  return True,'MATCH'
def init_state(out,mapping,ids=None):
 ids=ids or {}
 with exclusive_lock(out):
  d={'schema':SCHEMA,'classes':{}}
  for c in CLASSES:
   p=Path(mapping[c]).resolve();d['classes'][c]={'epoch':1,'sha256':sha_file(p),'source_id':ids.get(c) or c,'source_path':str(p)}
  atomic_write(out,d);return d
def cas(state_path,cls,proposed_file,expect_epoch,expect_sha,expect_source_id=None,hold_ms=0):
 with exclusive_lock(state_path):
  d=load_unlocked(state_path);ok,msg=validate_sources(d)
  if not ok:return False,msg,d['classes'][cls]
  cur=d['classes'][cls]
  if cur['epoch']!=expect_epoch or cur['sha256']!=expect_sha or (expect_source_id is not None and cur['source_id']!=expect_source_id):return False,'STALE_TOKEN',cur
  if hold_ms>0:time.sleep(hold_ms/1000.0)
  new_bytes=Path(proposed_file).read_bytes();new_hash=sha_bytes(new_bytes)
  atomic_write(Path(cur['source_path']),new_bytes)
  new={'epoch':cur['epoch']+1,'sha256':new_hash,'source_id':cur['source_id'],'source_path':cur['source_path']};d['classes'][cls]=new;atomic_write(state_path,d);return True,'UPDATED',new
def main():
 ap=argparse.ArgumentParser();sp=ap.add_subparsers(dest='cmd',required=True)
 p=sp.add_parser('init');p.add_argument('state')
 for c in CLASSES:p.add_argument('--'+c,required=True);p.add_argument('--'+c+'-id')
 p=sp.add_parser('snapshot');p.add_argument('state');p.add_argument('--out')
 p=sp.add_parser('verify');p.add_argument('state');p.add_argument('token');p.add_argument('--classes',nargs='*',choices=CLASSES)
 p=sp.add_parser('cas');p.add_argument('state');p.add_argument('class_name',choices=CLASSES);p.add_argument('proposed_file');p.add_argument('--expect-epoch',type=int,required=True);p.add_argument('--expect-sha',required=True);p.add_argument('--expect-source-id');p.add_argument('--hold-ms',type=int,default=0)
 a=ap.parse_args()
 if a.cmd=='init':
  d=init_state(a.state,{c:getattr(a,c) for c in CLASSES},{c:getattr(a,c+'_id') for c in CLASSES if getattr(a,c+'_id')});print(json.dumps(token(d),sort_keys=True));return 0
 if a.cmd=='snapshot':
  ok,msg,t=snapshot(a.state)
  if not ok:print(msg);return 3
  s=json.dumps(t,indent=2,sort_keys=True)+'\n';Path(a.out).write_text(s,encoding='utf-8',newline='\n') if a.out else print(s,end='');return 0
 if a.cmd=='verify':
  t=json.loads(Path(a.token).read_text(encoding='utf-8'));ok,msg=verify_token(a.state,t,a.classes or CLASSES);print(msg);return 0 if ok else 3
 if a.cmd=='cas':
  ok,msg,new=cas(a.state,a.class_name,a.proposed_file,a.expect_epoch,a.expect_sha,a.expect_source_id,a.hold_ms);print(json.dumps({'status':msg,'current_or_new':new},sort_keys=True));return 0 if ok else 3
if __name__=='__main__':raise SystemExit(main())
