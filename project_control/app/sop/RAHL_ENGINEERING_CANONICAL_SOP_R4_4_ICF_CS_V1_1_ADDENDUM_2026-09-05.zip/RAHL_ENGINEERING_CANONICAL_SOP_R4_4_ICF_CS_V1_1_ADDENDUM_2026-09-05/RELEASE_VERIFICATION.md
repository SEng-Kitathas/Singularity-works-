# ICF-CS v1.1 — Release Verification Contract

Canonical base: `RAHL_ENGINEERING_CANONICAL_SOP_R4_4_2026-09-04.zip` SHA-256 `04f3e94efe8c901cc83a12a9c8531be8a9bb350728b8f9eba53db0fd082b3bbc`
Superseded demoted v1.0: `RAHL_ENGINEERING_CANONICAL_SOP_R4_4_ICF_CS_V1_0_ADDENDUM_2026-09-05.zip` SHA-256 `51ed7f424dff7c67534f7e53e8a7c10ebd93bf33ea575eea49dc3f05c24a92a9`

## Internal payload qualification
Frozen payload bytes require:
- exact canonical-base hash + CRC;
- exact manifest membership/hashes;
- semantic-read ledger v1 identity fields, coverage, hash/byte agreement, dispositions, and non-placeholder attestations;
- project-agnostic ICF-CS semantic bindings;
- phrase-bounded anti-binding witnesses plus disclosed residuals;
- qualification-contract hash pins for release-critical verifier/suite/runner/epoch-guard files;
- structurally separate qualification-surface verifier;
- exact hostile case name set and count;
- permanent reproduction of the five externally demonstrated audit failures;
- epoch-guard stale-token self-tests;
- zero unexpected hostile passes.

Internal PASS produces only `QUALIFIED_PAYLOAD`, never active doctrine.

## External release qualification
Activation additionally requires an external release witness outside the specimen to:
1. pin frozen manifest/ledger/qualification-contract hashes and every release-critical file hash;
2. rerun internal qualification;
3. seal twice deterministically and compare exact bytes;
4. verify ZIP CRC;
5. clean-extract and replay qualification;
6. issue a detached release receipt pinning the final payload ZIP SHA-256 and all required evidence;
7. distribute payload ZIP and detached receipt together;
8. verify the distribution bundle contains both and that the receipt matches the payload bytes.

`SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE`

A payload without its valid detached release receipt is not active binding doctrine.
