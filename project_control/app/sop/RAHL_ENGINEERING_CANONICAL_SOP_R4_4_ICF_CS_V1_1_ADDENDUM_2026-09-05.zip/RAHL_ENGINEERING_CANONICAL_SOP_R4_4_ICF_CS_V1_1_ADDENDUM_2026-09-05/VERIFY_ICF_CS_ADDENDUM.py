from __future__ import annotations
from pathlib import Path
import hashlib,json,re,sys,zipfile
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent).resolve()
PACKAGE_ID='RAHL_ENGINEERING_CANONICAL_SOP_R4_4_ICF_CS_V1_1_ADDENDUM_2026-09-05'
PARENT_ID='RAHL_ENGINEERING_CANONICAL_SOP_R4_4_2026-09-04'
PARENT_SHA='04f3e94efe8c901cc83a12a9c8531be8a9bb350728b8f9eba53db0fd082b3bbc'
PROJECT_SPECIFIC=['protoagi','ms1944','qwen','microseed','different_entity','cfe_readonly_audit']
ACTIVE=['00_READ_ME_FIRST.md','INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','MECHANIZED_EPOCH_PROFILE.md','CLAIM_CEILING.md','SEMANTIC_READ_LEDGER_PROTOCOL.md','RELEASE_VERIFICATION.md','machine/ICF_CS_V1_1.json','evidence/V1_0_DEMOTION_RECEIPT.json']
REQUIRED={
'00_READ_ME_FIRST.md':['SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE','REQUIRES_DETACHED_RELEASE_RECEIPT'],
'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md':['DIRECTION != CONSTRAINTS != FRONTIER != HISTORY','HISTORICAL_HANDOFF != CURRENT_INGRESS','DONOR != AUTHORITY','RECENT_TIMESTAMP != CURRENT_AUTHORITY','STALE_GREEN != CURRENT_EVIDENCE','CURRENT_INGRESS_POINTER != CURRENT_STATE_PROOF','CURRENT STATE -> ICF-CS -> CURRENT CANONICAL SOP + NEXT/DOCTRINE/REVISIT/TRACE -> LIVE SHADOW -> DTS -> LIVE READBACK BEFORE MUTATION','CONFLICT -> RECOVERY/AUDIT -> LOCALIZE -> REPAIR/SUPERSEDE -> READBACK -> RESUME','EXPECTED_LABEL != PROMPT_CONTENT','BENCHMARK_ITEM != DOCTRINE_AUTHORITY','FORMAT_FAILURE != SEMANTIC_FAILURE','SEMANTIC_AGREEMENT != AUTHORITY_FIDELITY','SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE'],
'MECHANIZED_EPOCH_PROFILE.md':['CLASS_EPOCH != GLOBAL_TIME','EPOCH_EQUAL != CONTENT_EQUAL','CAS_CHECK != AUTHORITY_CHECK','CAS_SUCCESS != SEMANTIC_VALIDITY','SELF_TEST_PASS != CROSS_PROJECT_EFFICACY'],
'CLAIM_CEILING.md':['phrase-based anti-binding catches every additive semantic reversal','Unknown paraphrases remain a residual','SELF_QUALIFICATION != CROSS_PROJECT_EFFICACY','KNOWN_FAULT_COVERAGE != LATENT_FAULT_COVERAGE','DOCTRINE_PRESENT != DOCTRINE_EMBODIED']}
ANTI=[
(re.compile(r'DIRECTION\s*=\s*CONSTRAINTS',re.I),'direction/constraint collapse'),(re.compile(r'CONSTRAINTS\s*=\s*FRONTIER',re.I),'constraint/frontier collapse'),(re.compile(r'FRONTIER\s*=\s*HISTORY',re.I),'frontier/history collapse'),(re.compile(r'HISTORICAL_HANDOFF\s*=\s*CURRENT_INGRESS',re.I),'historical handoff promoted'),(re.compile(r'DONOR\s*=\s*AUTHORITY',re.I),'donor promoted'),(re.compile(r'RECENT_TIMESTAMP\s*=\s*CURRENT_AUTHORITY',re.I),'timestamp promoted'),(re.compile(r'STALE_GREEN\s*=\s*CURRENT_EVIDENCE',re.I),'stale green promoted'),(re.compile(r'CURRENT_INGRESS_POINTER\s*=\s*CURRENT_STATE_PROOF',re.I),'pointer promoted'),(re.compile(r'EXPECTED_LABEL\s*=\s*PROMPT_CONTENT',re.I),'label leak'),(re.compile(r'BENCHMARK_ITEM\s*=\s*DOCTRINE_AUTHORITY',re.I),'benchmark promoted'),(re.compile(r'FORMAT_FAILURE\s*=\s*SEMANTIC_FAILURE',re.I),'format/semantic collapse'),(re.compile(r'SEMANTIC_AGREEMENT\s*=\s*AUTHORITY_FIDELITY',re.I),'agreement/fidelity collapse'),
(re.compile(r'(?:newest|latest|most recent)\s+(?:timestamp|file|document).{0,80}(?:wins|authoritative|authority)',re.I),'recency wins'),
(re.compile(r'(?:historical handoff|donor material|donor document|imported donor text).{0,140}(?:may|can|should|permitted to).{0,60}(?:serve as|be treated as|become|govern).{0,60}(?:current ingress|current authority|governing authority|project)',re.I),'donor/historical bypass'),
(re.compile(r'(?:old|prior|previous|stale)\s+(?:green|passing)\s+(?:verifier|verification|receipt).{0,120}(?:remains|is|counts as).{0,40}(?:current|live)\s+evidence',re.I),'stale green synonym'),
(re.compile(r'(?:expected\s+(?:answer|label|key)|scoring\s+key).{0,50}(?:may|can|should).{0,50}(?:appear|be\s+embedded|be\s+included).{0,50}(?:prompt|input|model input)',re.I),'label leak permissive synonym'),
(re.compile(r'\b(?:copy|embed|include)\b\s+(?:the\s+)?(?:expected\s+(?:answer|label|key)|scoring\s+key).{0,40}(?:into|in)\s+(?:the\s+)?(?:prompt|input|model input)',re.I),'label leak imperative synonym'),
(re.compile(r'benchmark.{0,80}(?:may|can|should).{0,40}(?:override|supersede|define).{0,40}(?:doctrine|authority)',re.I),'benchmark authority synonym'),
(re.compile(r'(?:semantic agreement|agreement with (?:the )?key).{0,100}(?:proves|establishes|guarantees).{0,50}(?:authority fidelity|doctrine fidelity)',re.I),'agreement fidelity synonym'),
(re.compile(r'R4\.2\s*\+\s*NEXT/DOCTRINE/REVISIT/TRACE',re.I),'obsolete version pin')]
def fail(m):print('FAIL:',m);raise SystemExit(2)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# exact base
p=ROOT/'parent'/(PARENT_ID+'.zip')
if not p.exists() or sha(p)!=PARENT_SHA:fail('exact canonical base missing/hash mismatch')
with zipfile.ZipFile(p) as z:
 if z.testzip() is not None:fail('canonical base CRC failure')
# manifest
mp=ROOT/'MANIFEST_SHA256.json'
try:m=json.loads(mp.read_text(encoding='utf-8'))
except Exception as e:fail('manifest parse '+repr(e))
if m.get('schema')!='rahl.sop.additive-overlay-manifest.v1' or m.get('package_id')!=PACKAGE_ID or m.get('parent_package_id')!=PARENT_ID or m.get('parent_sha256')!=PARENT_SHA:fail('manifest identity/schema')
actual={x.relative_to(ROOT).as_posix() for x in ROOT.rglob('*') if x.is_file() and x.name!='MANIFEST_SHA256.json'}
if set(m.get('files',{}))!=actual:fail('manifest membership mismatch')
for rel,spec in m['files'].items():
 q=ROOT/rel
 if q.stat().st_size!=spec.get('bytes') or sha(q)!=spec.get('sha256'):fail('manifest hash/size mismatch '+rel)
# contract
try:c=json.loads((ROOT/'machine/QUALIFICATION_CONTRACT.json').read_text(encoding='utf-8'))
except Exception as e:fail('qualification contract parse '+repr(e))
if c.get('schema')!='rahl.sop.icf-cs-qualification-contract.v1' or c.get('package_id')!=PACKAGE_ID or c.get('canonical_base_sha256')!=PARENT_SHA:fail('qualification contract identity/schema')
for rel,want in c.get('release_critical_hashes',{}).items():
 if not (ROOT/rel).exists() or sha(ROOT/rel)!=want:fail('release-critical hash mismatch '+rel)
# active project-agnostic semantic surfaces
for rel in ACTIVE:
 t=(ROOT/rel).read_text(encoding='utf-8');low=t.lower()
 for bad in PROJECT_SPECIFIC:
  if bad in low:fail('project-specific contamination '+rel+': '+bad)
 for rx,label in ANTI:
  if rx.search(t):fail('anti-binding violation '+rel+': '+label)
for rel,need in REQUIRED.items():
 t=(ROOT/rel).read_text(encoding='utf-8')
 for s in need:
  if s not in t:fail('required semantic binding missing '+rel+': '+s)
# machine identity
j=json.loads((ROOT/'machine/ICF_CS_V1_1.json').read_text(encoding='utf-8'))
if j.get('standard_name')!='Intent–Constraint–Frontier Continuity Standard' or j.get('version')!='1.1':fail('machine identity drift')
if j.get('core_law')!='DIRECTION != CONSTRAINTS != FRONTIER != HISTORY':fail('machine core-law drift')
if j.get('cold_start')!='CURRENT STATE -> ICF-CS -> CURRENT CANONICAL SOP + NEXT/DOCTRINE/REVISIT/TRACE -> LIVE SHADOW -> DTS -> LIVE READBACK BEFORE MUTATION':fail('machine cold-start drift')
if j.get('conflict')!='CONFLICT -> RECOVERY/AUDIT -> LOCALIZE -> REPAIR/SUPERSEDE -> READBACK -> RESUME':fail('machine conflict drift')
if j.get('live_classes')!=['intent','constraints','frontier']:fail('machine live-class drift')
if j.get('release_law')!='SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE':fail('machine release-law drift')
# semantic ledger: ported parent R4.4 v1 semantics
try:led=json.loads((ROOT/'SEMANTIC_READ_LEDGER.json').read_text(encoding='utf-8'))
except Exception as e:fail('ledger parse '+repr(e))
if led.get('schema')!='rahl.sop.semantic-read-ledger.v1' or led.get('package_id')!=PACKAGE_ID or led.get('parent_package_id')!=PARENT_ID or led.get('parent_sha256')!=PARENT_SHA:fail('ledger identity/schema')
loadbearing=set(c.get('semantic_loadbearing',[]));ent=led.get('entries',{})
if set(ent)!=loadbearing:fail('ledger coverage mismatch')
# parent manifest for any reuse
try:
 with zipfile.ZipFile(p) as z:pm=json.loads(z.read(PARENT_ID+'/MANIFEST_SHA256.json').decode())['files']
except Exception as e:fail('parent manifest read '+repr(e))
pending=[]
for rel,e in sorted(ent.items()):
 q=ROOT/rel
 if rel not in m['files'] or e.get('sha256')!=m['files'][rel]['sha256'] or e.get('bytes')!=m['files'][rel]['bytes'] or e.get('sha256')!=sha(q) or e.get('bytes')!=q.stat().st_size:fail('ledger hash disagreement '+rel)
 d=e.get('disposition')
 if d=='REUSED_EXACT_HASH':
  if rel not in pm or pm[rel]['sha256']!=e['sha256'] or e.get('parent_sha256')!=pm[rel]['sha256']:fail('ledger reuse contradicts parent '+rel)
 elif d=='FRESH_READ_COMPLETED':
  for f in ('read_by','read_at','read_note'):
   v=e.get(f)
   if not isinstance(v,str) or not v.strip() or v.strip().upper() in {'TBD','TODO','N/A','PENDING','NULL','X'}:fail('ledger attestation incomplete '+rel+': '+f)
 elif d=='FRESH_READ_REQUIRED':
  if any(e.get(f) is not None for f in ('read_by','read_at','read_note')):fail('unread carries attestation '+rel)
  pending.append(rel)
 else:fail('ledger disposition '+rel+': '+repr(d))
if pending:fail('semantic read pending: '+str(len(pending)))
print('PASS: ICF-CS v1.1 payload structure, exact R4.4 base, manifest, contract pins, semantic bindings, ledger-v1 identity/attestation, anti-binding residual-aware witnesses. STATE: QUALIFIED_PAYLOAD_PENDING_EXTERNAL_RECEIPT')
