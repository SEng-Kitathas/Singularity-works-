# ICF-CS v1.1 — Claim Ceiling and Residuals

Status: BINDING WITH THE STANDARD ONLY AFTER VALID DETACHED RELEASE RECEIPT

ICF-CS v1.1 does **not** claim:
- that current-ingress pointers prove current state;
- that timestamps establish authority;
- that intent establishes factual truth;
- that constraints are permanent;
- that frontier summaries replace source contact;
- that a historical green verifier remains current after consequence-bearing state changes;
- that benchmark answer keys are doctrine;
- that agreement with a benchmark key proves authority fidelity;
- that formatting correctness and semantic correctness are the same property;
- that expected labels may be exposed to evaluated input without changing the measurement;
- that semantic-read attestation proves comprehension;
- that a self-verifying payload is a verified release;
- that the primary verifier, meta-verifier, qualification runner, hostile suite, and contract are independently authored or free of common-mode risk;
- that phrase-based anti-binding catches every additive semantic reversal;
- that the known hostile paraphrases enumerate all possible paraphrases;
- that an epoch/hash token establishes truth or authority;
- that successful CAS establishes semantic validity;
- that a local file lock provides distributed consensus across unreconciled machines/storage planes;
- that a lock-held sequence across separate source/state replacements is a crash-atomic transaction;
- that mechanized-profile self-tests demonstrate cross-project efficacy;
- that package self-qualification demonstrates doctrine adoption in real projects.

The section-inventory/anti-binding/verifier witnesses remain structurally different but same-system witnesses. Unknown paraphrases remain a residual even after permanent re-attested paraphrase attacks are added.

`PHRASE_WITNESS != SEMANTIC_COMPLETENESS`
`COMMON_MODE_WITNESSES != INDEPENDENT_ASSURANCE`
`SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE`
`SELF_QUALIFICATION != CROSS_PROJECT_EFFICACY`
`CONSTANT_PASS_STATUS != DISCRIMINATIVE_EVIDENCE`
`KNOWN_FAULT_COVERAGE != LATENT_FAULT_COVERAGE`
`DOCTRINE_PRESENT != DOCTRINE_EMBODIED`

R4.4 remains sealed and unchanged. v1.0 remains preserved as demoted historical evidence; it is not silently rewritten.
