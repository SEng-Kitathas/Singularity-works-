# Rahl Engineering Canonical SOP R4.4 — ICF-CS v1.1 Additive Overlay Payload

Date: 2026-09-05
Payload status: `QUALIFIED_PAYLOAD_ONLY_IF_ALL_INTERNAL_GATES_PASS`
Activation status: `REQUIRES_DETACHED_RELEASE_RECEIPT`
Canonical sealed base: `RAHL_ENGINEERING_CANONICAL_SOP_R4_4_2026-09-04.zip`
Canonical base SHA-256: `04f3e94efe8c901cc83a12a9c8531be8a9bb350728b8f9eba53db0fd082b3bbc`
Supersedes demoted overlay: `RAHL_ENGINEERING_CANONICAL_SOP_R4_4_ICF_CS_V1_0_ADDENDUM_2026-09-05.zip` SHA-256 `51ed7f424dff7c67534f7e53e8a7c10ebd93bf33ea575eea49dc3f05c24a92a9`.

R4.4 remains byte-unchanged and canonical. ICF-CS v1.1 is a separately versioned additive successor to the demoted v1.0 overlay.

## Absolute release rule
This payload SHALL NOT declare itself active binding doctrine merely because its own verifier or hostile suite passes.

`SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE`

Activation requires a detached release receipt produced outside the specimen after frozen-byte semantic read, internal qualification, deterministic sealing, CRC verification, clean-extraction replay, and release-critical hash pinning. The detached receipt SHALL be distributed alongside this payload.

## Read order
1. `INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md`
2. `MECHANIZED_EPOCH_PROFILE.md`
3. `CLAIM_CEILING.md`
4. `machine/ICF_CS_V1_1.json`
5. `machine/QUALIFICATION_CONTRACT.json`
6. `SEMANTIC_READ_LEDGER_PROTOCOL.md`
7. qualification/release surfaces when auditing or releasing.

## Core law
`DIRECTION != CONSTRAINTS != FRONTIER != HISTORY`

Three live continuity classes—Intent, Constraints, Frontier—remain separate from chronological/forensic History.

## Cold start
`CURRENT STATE -> ICF-CS -> CURRENT CANONICAL SOP + NEXT/DOCTRINE/REVISIT/TRACE -> LIVE SHADOW -> DTS -> LIVE READBACK BEFORE MUTATION`

## Conflict
`CONFLICT -> RECOVERY/AUDIT -> LOCALIZE -> REPAIR/SUPERSEDE -> READBACK -> RESUME`

## v1.1 repair focus
- semantic-read ledger v1 identity and attestation checks are fully enforced;
- qualification surfaces are mutually pinned by a qualification contract and checked by a structurally separate meta-verifier;
- hostile case names/count are fixed and qualification refuses silent suite shrinkage;
- the five externally reproduced audit failures are permanent hostile classes;
- phrase-bounded anti-binding residuals are disclosed rather than hidden;
- detached release evidence is mandatory and distributed outside the self-verifying payload;
- optional epoch/hash compare-and-swap mechanization converts currentness readback from operator care into an executable guard where local state permits it.
