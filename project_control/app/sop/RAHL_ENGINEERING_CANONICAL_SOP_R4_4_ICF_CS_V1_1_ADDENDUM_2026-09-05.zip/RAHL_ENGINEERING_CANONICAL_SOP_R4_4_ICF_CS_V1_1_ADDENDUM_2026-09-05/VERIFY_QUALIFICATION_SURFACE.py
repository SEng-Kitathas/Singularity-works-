from __future__ import annotations
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent).resolve()
EXPECTED_NAMES=['direction_constraint_collapse', 'constraint_frontier_collapse', 'frontier_history_collapse', 'historical_handoff_promoted', 'donor_promoted', 'timestamp_promoted', 'stale_green_promoted', 'pointer_promoted_to_proof', 'expected_label_leak', 'benchmark_promoted', 'format_semantic_collapse', 'agreement_fidelity_collapse', 'recency_wins_synonym', 'donor_bypass_synonym', 'stale_green_synonym', 'label_leak_synonym', 'benchmark_authority_synonym', 'agreement_fidelity_synonym', 'obsolete_version_pin', 'ingress_requirement_weakened', 'project_specific_contamination', 'semantic_ledger_byte_count_tamper', 'external_audit_null_attestations', 'external_audit_ledger_identity_omission', 'external_audit_gutted_verifier', 'external_audit_truncated_suite', 'external_audit_donor_paraphrase', 'external_audit_label_leak_paraphrase', 'claim_ceiling_residual_removed', 'qualification_contract_suite_count_tamper', 'manifest_member_omission', 'epoch_guard_stale_cas', 'epoch_guard_hash_mismatch', 'epoch_guard_out_of_band_drift', 'epoch_guard_concurrent_cas_single_winner']
EXPECTED_COUNT=len(EXPECTED_NAMES)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(m):print('META_FAIL:',m);raise SystemExit(2)
try:c=json.loads((ROOT/'machine/QUALIFICATION_CONTRACT.json').read_text(encoding='utf-8'))
except Exception as e:fail('contract parse '+repr(e))
if c.get('expected_hostile_names')!=EXPECTED_NAMES or c.get('expected_hostile_count')!=EXPECTED_COUNT:fail('hostile contract set/count drift')
for rel,want in c.get('release_critical_hashes',{}).items():
 if not (ROOT/rel).exists() or sha(ROOT/rel)!=want:fail('critical file drift '+rel)
# hostile suite must expose exact --list JSON names independent of normal run
import subprocess
cp=subprocess.run([sys.executable,str(ROOT/'tests/RUN_ICF_CS_HOSTILE_TESTS.py'),'--list'],capture_output=True,text=True)
if cp.returncode:fail('hostile --list failed')
try:names=json.loads(cp.stdout)
except Exception as e:fail('hostile --list parse '+repr(e))
if names!=EXPECTED_NAMES:fail('hostile implementation names drift')
# qualification runner source must contain explicit count/name checks
qt=(ROOT/'RUN_ICF_CS_QUALIFICATION.py').read_text(encoding='utf-8')
for witness in ['expected_hostile_names','hostile_names','expected_hostile_count','hostile_cases']:
 if witness not in qt:fail('qualification runner missing witness '+witness)
print('META_PASS: qualification contract, release-critical hashes, hostile exact name set/count, runner witness surface')
