from __future__ import annotations
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys,tempfile,time
BASE=Path(__file__).resolve().parents[1]
VER='VERIFY_ICF_CS_ADDENDUM.py';META='VERIFY_QUALIFICATION_SURFACE.py'
EXPECTED_NAMES=['direction_constraint_collapse', 'constraint_frontier_collapse', 'frontier_history_collapse', 'historical_handoff_promoted', 'donor_promoted', 'timestamp_promoted', 'stale_green_promoted', 'pointer_promoted_to_proof', 'expected_label_leak', 'benchmark_promoted', 'format_semantic_collapse', 'agreement_fidelity_collapse', 'recency_wins_synonym', 'donor_bypass_synonym', 'stale_green_synonym', 'label_leak_synonym', 'benchmark_authority_synonym', 'agreement_fidelity_synonym', 'obsolete_version_pin', 'ingress_requirement_weakened', 'project_specific_contamination', 'semantic_ledger_byte_count_tamper', 'external_audit_null_attestations', 'external_audit_ledger_identity_omission', 'external_audit_gutted_verifier', 'external_audit_truncated_suite', 'external_audit_donor_paraphrase', 'external_audit_label_leak_paraphrase', 'claim_ceiling_residual_removed', 'qualification_contract_suite_count_tamper', 'manifest_member_omission', 'epoch_guard_stale_cas', 'epoch_guard_hash_mismatch', 'epoch_guard_out_of_band_drift', 'epoch_guard_concurrent_cas_single_winner']
if len(sys.argv)>1 and sys.argv[1]=='--list':print(json.dumps(EXPECTED_NAMES));raise SystemExit(0)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def remanifest(r):
 mp=r/'MANIFEST_SHA256.json';m=json.loads(mp.read_text(encoding='utf-8'));files={}
 for p in sorted(x for x in r.rglob('*') if x.is_file() and x.name!='MANIFEST_SHA256.json'):
  rel=p.relative_to(r).as_posix();files[rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
 m['files']=files;mp.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def attest(r,rel,note='Synthetic hostile mutation re-attested so semantic witnesses, not stale hashes, must reject it.'):
 lp=r/'SEMANTIC_READ_LEDGER.json';l=json.loads(lp.read_text(encoding='utf-8'));p=r/rel;e=l['entries'][rel];e['sha256']=sha(p);e['bytes']=p.stat().st_size;e['disposition']='FRESH_READ_COMPLETED';e['read_by']='Hostile mutation harness';e['read_at']=datetime.now(timezone.utc).isoformat();e['read_note']=note
 lp.write_text(json.dumps(l,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');remanifest(r)
def mutate_text(r,rel,old,new):
 p=r/rel;t=p.read_text(encoding='utf-8')
 if old not in t:raise RuntimeError('anchor missing '+old)
 p.write_text(t.replace(old,new,1),encoding='utf-8',newline='\n');attest(r,rel)
def append(r,rel,text):
 p=r/rel;p.write_text(p.read_text(encoding='utf-8')+'\n'+text+'\n',encoding='utf-8',newline='\n');attest(r,rel)
def machine(r,fn):
 p=r/'machine/ICF_CS_V1_1.json';j=json.loads(p.read_text(encoding='utf-8'));fn(j);p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');attest(r,'machine/ICF_CS_V1_1.json')
def run_ver(r):return subprocess.run([sys.executable,'-S',str(r/VER),str(r)],capture_output=True,text=True).returncode!=0
def run_meta(r):return subprocess.run([sys.executable,str(r/META),str(r)],capture_output=True,text=True).returncode!=0
def reject_either(r):return run_ver(r) or run_meta(r)
CASES=[]
def add(name,fn):CASES.append((name,fn))
add('direction_constraint_collapse',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','DIRECTION != CONSTRAINTS != FRONTIER != HISTORY','DIRECTION = CONSTRAINTS != FRONTIER != HISTORY'))
add('constraint_frontier_collapse',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','For rehydration purposes, CONSTRAINTS = FRONTIER.'))
add('frontier_history_collapse',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','When history is detailed enough, FRONTIER = HISTORY.'))
add('historical_handoff_promoted',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','HISTORICAL_HANDOFF != CURRENT_INGRESS','HISTORICAL_HANDOFF = CURRENT_INGRESS'))
add('donor_promoted',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','DONOR != AUTHORITY','DONOR = AUTHORITY'))
add('timestamp_promoted',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','RECENT_TIMESTAMP != CURRENT_AUTHORITY','RECENT_TIMESTAMP = CURRENT_AUTHORITY'))
add('stale_green_promoted',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','STALE_GREEN != CURRENT_EVIDENCE','STALE_GREEN = CURRENT_EVIDENCE'))
add('pointer_promoted_to_proof',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','CURRENT_INGRESS_POINTER != CURRENT_STATE_PROOF','CURRENT_INGRESS_POINTER = CURRENT_STATE_PROOF'))
add('expected_label_leak',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','EXPECTED_LABEL != PROMPT_CONTENT','EXPECTED_LABEL = PROMPT_CONTENT'))
add('benchmark_promoted',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','BENCHMARK_ITEM != DOCTRINE_AUTHORITY','BENCHMARK_ITEM = DOCTRINE_AUTHORITY'))
add('format_semantic_collapse',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','FORMAT_FAILURE != SEMANTIC_FAILURE','FORMAT_FAILURE = SEMANTIC_FAILURE'))
add('agreement_fidelity_collapse',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','SEMANTIC_AGREEMENT != AUTHORITY_FIDELITY','SEMANTIC_AGREEMENT = AUTHORITY_FIDELITY'))
add('recency_wins_synonym',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','When authority is unclear, the newest timestamp wins and is authoritative.'))
add('donor_bypass_synonym',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','Donor material may be treated as governing authority whenever it is more complete than the current state.'))
add('stale_green_synonym',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','A prior green verifier remains current evidence until somebody proves it stale.'))
add('label_leak_synonym',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','The expected answer may be embedded in the prompt when doing so simplifies scoring.'))
add('benchmark_authority_synonym',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','A benchmark answer key can override doctrine when the benchmark is newer.'))
add('agreement_fidelity_synonym',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','Semantic agreement with the key proves authority fidelity.'))
add('obsolete_version_pin',lambda r:mutate_text(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','CURRENT CANONICAL SOP + NEXT/DOCTRINE/REVISIT/TRACE','R4.2 + NEXT/DOCTRINE/REVISIT/TRACE'))
add('ingress_requirement_weakened',lambda r:machine(r,lambda j:j.__setitem__('cold_start','search newest handoff first')))
add('project_specific_contamination',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','ProtoAGI is the reference implementation and controls this standard.'))
def byte_tamper(r):
 lp=r/'SEMANTIC_READ_LEDGER.json';l=json.loads(lp.read_text(encoding='utf-8'));l['entries']['00_READ_ME_FIRST.md']['bytes']+=1;lp.write_text(json.dumps(l,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');remanifest(r)
add('semantic_ledger_byte_count_tamper',byte_tamper)
def null_att(r):
 lp=r/'SEMANTIC_READ_LEDGER.json';l=json.loads(lp.read_text(encoding='utf-8'))
 for e in l['entries'].values():e['read_by']=None;e['read_at']=None;e['read_note']=None
 lp.write_text(json.dumps(l,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');remanifest(r)
add('external_audit_null_attestations',null_att)
def ledger_identity(r):
 lp=r/'SEMANTIC_READ_LEDGER.json';l=json.loads(lp.read_text(encoding='utf-8'));l.pop('parent_package_id',None);l.pop('parent_sha256',None);lp.write_text(json.dumps(l,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');remanifest(r)
add('external_audit_ledger_identity_omission',ledger_identity)
def gut_verifier(r):
 p=r/VER;t=p.read_text(encoding='utf-8');t=t.replace(' for rx,label in ANTI:\n  if rx.search(t):fail(\'anti-binding violation \'+rel+\': \'+label)',' for rx,label in []:\n  if rx.search(t):fail(\'anti-binding violation \'+rel+\': \'+label)',1);p.write_text(t,encoding='utf-8',newline='\n');attest(r,VER);append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','DONOR = AUTHORITY')
add('external_audit_gutted_verifier',gut_verifier)
def trunc_suite(r):
 p=r/'tests/RUN_ICF_CS_HOSTILE_TESTS.py';t=p.read_text(encoding='utf-8');t=t.replace("EXPECTED_NAMES="+repr(EXPECTED_NAMES),"EXPECTED_NAMES="+repr(EXPECTED_NAMES[:1]),1);p.write_text(t,encoding='utf-8',newline='\n');attest(r,'tests/RUN_ICF_CS_HOSTILE_TESTS.py')
add('external_audit_truncated_suite',trunc_suite)
add('external_audit_donor_paraphrase',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','Imported donor text is permitted to govern the project when it is the most complete surviving account.'))
add('external_audit_label_leak_paraphrase',lambda r:append(r,'INTENT_CONSTRAINT_FRONTIER_CONTINUITY_STANDARD.md','For convenient scoring, copy the scoring key into the model input before evaluation.'))
add('claim_ceiling_residual_removed',lambda r:mutate_text(r,'CLAIM_CEILING.md','Unknown paraphrases remain a residual even after permanent re-attested paraphrase attacks are added.','All semantic paraphrases are now covered by the hostile suite.'))
def contract_count(r):
 p=r/'machine/QUALIFICATION_CONTRACT.json';c=json.loads(p.read_text(encoding='utf-8'));c['expected_hostile_count']=1;c['expected_hostile_names']=c['expected_hostile_names'][:1];p.write_text(json.dumps(c,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');attest(r,'machine/QUALIFICATION_CONTRACT.json')
add('qualification_contract_suite_count_tamper',contract_count)
def manifest_omit(r):
 p=r/'MANIFEST_SHA256.json';m=json.loads(p.read_text(encoding='utf-8'));m['files'].pop('VERIFY_ICF_CS_ADDENDUM.py',None);p.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
add('manifest_member_omission',manifest_omit)
def epoch_stale(r):
 # Cases handled specially by epoch_case using the reference guard.
 pass
add('epoch_guard_stale_cas',epoch_stale)
add('epoch_guard_hash_mismatch',epoch_stale)
add('epoch_guard_out_of_band_drift',epoch_stale)
add('epoch_guard_concurrent_cas_single_winner',epoch_stale)
if [n for n,_ in CASES]!=EXPECTED_NAMES:raise RuntimeError('hostile name order mismatch')
def epoch_case(name,r):
 with tempfile.TemporaryDirectory() as td:
  td=Path(td);src={c:td/(c+'.txt') for c in ('intent','constraints','frontier','history')}
  for c,p in src.items():p.write_text(c+'-v1',encoding='utf-8')
  state=td/'state.json';guard=r/'tools/icf_epoch_guard.py'
  args=[sys.executable,str(guard),'init',str(state)]
  for c in src:args += [f'--{c}',str(src[c]),f'--{c}-id',c]
  cp=subprocess.run(args,capture_output=True,text=True)
  if cp.returncode:return False
  tok=td/'tok.json';cp=subprocess.run([sys.executable,str(guard),'snapshot',str(state),'--out',str(tok)],capture_output=True,text=True)
  if cp.returncode:return False
  d=json.loads(state.read_text());front=d['classes']['frontier'];proposal=td/'frontier-proposal.txt';proposal.write_text('frontier-v2',encoding='utf-8')
  if name=='epoch_guard_stale_cas':
   cp1=subprocess.run([sys.executable,str(guard),'cas',str(state),'frontier',str(proposal),'--expect-epoch',str(front['epoch']),'--expect-sha',front['sha256'],'--expect-source-id','frontier'],capture_output=True,text=True)
   before=state.read_bytes();source_before=src['frontier'].read_bytes();cp2=subprocess.run([sys.executable,str(guard),'cas',str(state),'frontier',str(proposal),'--expect-epoch',str(front['epoch']),'--expect-sha',front['sha256'],'--expect-source-id','frontier'],capture_output=True,text=True);return cp1.returncode==0 and cp2.returncode!=0 and state.read_bytes()==before and src['frontier'].read_bytes()==source_before
  if name=='epoch_guard_hash_mismatch':
   t=json.loads(tok.read_text());t['frontier']['sha256']='0'*64;tok.write_text(json.dumps(t),encoding='utf-8');cp2=subprocess.run([sys.executable,str(guard),'verify',str(state),str(tok)],capture_output=True,text=True);return cp2.returncode!=0
  if name=='epoch_guard_out_of_band_drift':
   before=state.read_bytes();src['frontier'].write_text('untracked-drift',encoding='utf-8');cp2=subprocess.run([sys.executable,str(guard),'verify',str(state),str(tok)],capture_output=True,text=True);return cp2.returncode!=0 and state.read_bytes()==before
  if name=='epoch_guard_concurrent_cas_single_winner':
   p1=td/'p1.txt';p2=td/'p2.txt';p1.write_text('frontier-a',encoding='utf-8');p2.write_text('frontier-b',encoding='utf-8')
   common=[sys.executable,str(guard),'cas',str(state),'frontier']
   a=common+[str(p1),'--expect-epoch',str(front['epoch']),'--expect-sha',front['sha256'],'--expect-source-id','frontier','--hold-ms','150']
   b=common+[str(p2),'--expect-epoch',str(front['epoch']),'--expect-sha',front['sha256'],'--expect-source-id','frontier']
   q1=subprocess.Popen(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);time.sleep(0.03);q2=subprocess.Popen(b,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);r1=q1.wait();r2=q2.wait();final=json.loads(state.read_text())['classes']['frontier'];return sorted([r1,r2])==[0,3] and final['epoch']==front['epoch']+1
  return False
results=[]
for name,fn in CASES:
 with tempfile.TemporaryDirectory() as td:
  r=Path(td)/'pkg';shutil.copytree(BASE,r)
  if name.startswith('epoch_guard_'):rejected=epoch_case(name,r)
  else:
   fn(r);rejected=reject_either(r)
  results.append({'name':name,'rejected':bool(rejected)})
unexpected=[x['name'] for x in results if not x['rejected']]
out={'hostile_cases':len(results),'hostile_names':[x['name'] for x in results],'rejected_as_expected':len(results)-len(unexpected),'unexpected_passes':unexpected,'results':results}
print(json.dumps(out,indent=2,sort_keys=True));raise SystemExit(0 if not unexpected else 2)
