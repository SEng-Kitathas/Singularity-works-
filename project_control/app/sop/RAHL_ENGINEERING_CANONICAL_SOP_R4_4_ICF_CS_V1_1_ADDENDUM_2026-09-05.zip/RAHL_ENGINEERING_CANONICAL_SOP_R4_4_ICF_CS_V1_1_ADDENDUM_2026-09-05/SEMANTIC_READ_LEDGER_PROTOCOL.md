# ICF-CS v1.1 — Semantic Read Ledger Protocol

Schema: `rahl.sop.semantic-read-ledger.v1`
Parent package ID: `RAHL_ENGINEERING_CANONICAL_SOP_R4_4_2026-09-04`
Parent SHA-256: `04f3e94efe8c901cc83a12a9c8531be8a9bb350728b8f9eba53db0fd082b3bbc`

All meaningfully readable load-bearing payload members SHALL be completely linearly read on exact candidate bytes before payload qualification.

The ledger SHALL contain and the verifier SHALL enforce:
- `schema` exactly `rahl.sop.semantic-read-ledger.v1`;
- `package_id` exactly the v1.1 payload ID;
- `parent_package_id` exactly the canonical R4.4 package ID;
- `parent_sha256` exactly the canonical R4.4 SHA-256;
- exact coverage of load-bearing readable members declared by the qualification contract;
- `sha256` and `bytes` agreement with the frozen manifest;
- valid disposition for every entry;
- non-placeholder `read_by`, `read_at`, `read_note` for `FRESH_READ_COMPLETED`;
- null attestation fields for `FRESH_READ_REQUIRED`;
- exact sealed-parent proof for any `REUSED_EXACT_HASH` entry.

Placeholder blacklist for completed read attestations: `TBD`, `TODO`, `N/A`, `PENDING`, `NULL`, `X`, empty/whitespace, and non-string values.

`AUTOMATED_CHECKS != LINEAR_SEMANTIC_READ`
`ATTESTATION != COMPREHENSION`
`VERIFIER_NAMED_X != VERIFIER_CHECKS_X`

The manifest and semantic ledger cannot self-hash each other without circularity. The semantic ledger is therefore itself frozen and completely read after attestation; its hash and the manifest hash are pinned by the detached external release receipt.
