from __future__ import annotations
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent
EXPECTED_NAMES=['direction_constraint_collapse', 'constraint_frontier_collapse', 'frontier_history_collapse', 'historical_handoff_promoted', 'donor_promoted', 'timestamp_promoted', 'stale_green_promoted', 'pointer_promoted_to_proof', 'expected_label_leak', 'benchmark_promoted', 'format_semantic_collapse', 'agreement_fidelity_collapse', 'recency_wins_synonym', 'donor_bypass_synonym', 'stale_green_synonym', 'label_leak_synonym', 'benchmark_authority_synonym', 'agreement_fidelity_synonym', 'obsolete_version_pin', 'ingress_requirement_weakened', 'project_specific_contamination', 'semantic_ledger_byte_count_tamper', 'external_audit_null_attestations', 'external_audit_ledger_identity_omission', 'external_audit_gutted_verifier', 'external_audit_truncated_suite', 'external_audit_donor_paraphrase', 'external_audit_label_leak_paraphrase', 'claim_ceiling_residual_removed', 'qualification_contract_suite_count_tamper', 'manifest_member_omission', 'epoch_guard_stale_cas', 'epoch_guard_hash_mismatch', 'epoch_guard_out_of_band_drift', 'epoch_guard_concurrent_cas_single_winner']
def run(args):return subprocess.run(args,capture_output=True,text=True)
v=run([sys.executable,'-S',str(ROOT/'VERIFY_ICF_CS_ADDENDUM.py'),str(ROOT)])
m=run([sys.executable,str(ROOT/'VERIFY_QUALIFICATION_SURFACE.py'),str(ROOT)])
h=run([sys.executable,str(ROOT/'tests/RUN_ICF_CS_HOSTILE_TESTS.py')])
try:hj=json.loads(h.stdout)
except Exception:hj={}
expected_hostile_names=EXPECTED_NAMES;expected_hostile_count=len(EXPECTED_NAMES);hostile_names=hj.get('hostile_names');hostile_cases=hj.get('hostile_cases')
ok=(v.returncode==0 and m.returncode==0 and h.returncode==0 and hostile_names==expected_hostile_names and hostile_cases==expected_hostile_count and hj.get('rejected_as_expected')==expected_hostile_count and not hj.get('unexpected_passes'))
out={'verifier_rc':v.returncode,'meta_verifier_rc':m.returncode,'hostile_rc':h.returncode,'hostile_cases':hostile_cases,'hostile_names':hostile_names,'expected_hostile_count':expected_hostile_count,'expected_hostile_names':expected_hostile_names,'hostile_rejected':hj.get('rejected_as_expected'),'hostile_unexpected':hj.get('unexpected_passes'),'state':'QUALIFIED_PAYLOAD_PENDING_EXTERNAL_RECEIPT' if ok else 'UNQUALIFIED'}
print(json.dumps(out,indent=2,sort_keys=True));raise SystemExit(0 if ok else 2)
