# 12A — Re-entry Context and Historical Reconstruction Protocol

## Purpose
This protocol converts long-thread/context packages into a universal re-entry discipline. It separates durable operating law from remembered project status so continuity does not become proof.

## 1. Adoption rule
Treat an imported handoff/context package as a **continuity map, not current-state evidence**.

Explicit governing intent and standing constraints from an authorized operator remain process authority within their scope until superseded. Factual claims contained in the same message remain evidence and may still require verification.

`AUTHORIZED_GOVERNING_INTENT != FACTUAL_TRUTH`
`CONTINUITY_MAP != CURRENT_STATE_EVIDENCE`

Paths, hashes, ports, commits, process IDs, campaign positions, repository heads, endpoint addresses, and machine allocations are remembered pointers until verified against live files, source control, logs, processes, artifacts, or current configuration where consequence matters.

## 2. Required state distinctions
Preserve distinctions such as:
- canonical;
- experimental;
- donor;
- historical lineage;
- observed;
- inferred;
- hypothesized;
- unknown;
- rejected/demoted/deferred.

Do not silently merge branches, promote experiments, resolve contradictions, reconstruct missing history, or infer absent campaign steps.

If something is unclear, contradictory, or visible only as traces: inspect first; preserve UNKNOWN; ask when the unresolved distinction changes consequential action.

## 3. Historical reconstruction classes
When mining older systems, archives, or design generations, classify what survives as one or more of:
- durable architectural/engineering law;
- first-principles discovery or invariant;
- capability-contingent scaffold;
- experimental steering mechanism;
- dead or superseded scaffold;
- unresolved historical claim.

Older labels, psychological metaphors, neural metaphors, archetypal language, role labels, or cognitive-architecture vocabulary may have been steering/inspection language rather than literal claims about internals.

`HISTORICAL_LABEL != VERIFIED_INTERNAL_MECHANISM`
`STEERING_VOCABULARY != ONTOLOGY`

Mine older systems for mechanism, intent, scars, and constraints without granting their terminology or architecture automatic authority.

## 4. Canonical versus research progression
Later experiments, campaigns, branches, or research checkpoints do not imply canonical promotion.

`RESEARCH_PROGRESSION != CANONICAL_PROMOTION`
`LATER_CHECKPOINT != HIGHER_AUTHORITY`

Verify the live authority surface before treating remembered research progression as the current baseline.

## 5. Repository and remote currentness
Local repository state and remote/publication state are separate consequence surfaces.

`LOCAL_HEAD != REMOTE_HEAD_UNLESS_VERIFIED`

Verify the relevant local branch/commit/tree and the relevant remote/fetch/readback before claiming publication or synchronization.

## 6. Runtime ownership
Shared immutable artifacts do not imply shared live process ownership.

`SHARED_IMMUTABLE_ARTIFACT != SHARED_RUNTIME_OWNERSHIP`
`FILE_ACCESS != PROCESS_OWNERSHIP`
`HISTORICAL_RUNTIME_POINTER != CURRENT_RUNTIME_STATE`

Separate projects or jobs may lawfully read the same immutable assets while still requiring distinct ports, jobs, runtime directories, mutable state, or process ownership. Verify ownership before starting, stopping, reusing, or terminating processes. Prefer targeted process management over broad kills when ownership is not singular and proven.

## 7. Permission currentness
Prior permission to inspect a system or repository does not automatically authorize a later destructive mutation, push, deletion, or process termination when the current task or authority surface does not carry that permission.

`PRIOR_INSPECTION_PERMISSION != CURRENT_DESTRUCTIVE_AUTHORIZATION`
`READ_AUTHORITY != MUTATION_AUTHORITY`

## 8. Source-contact rule
Remembered summaries, handoffs, prior assistant prose, and continuity notes are navigation aids. When precise source content matters, reload or inspect the actual artifact.

`REMEMBERED_SUMMARY != SOURCE_CONTACT`
`SUMMARY_FIDELITY != SOURCE_COMPLETENESS`

## 9. Missing history
Never invent an unnamed campaign range, missing branch, lost transient artifact, unknown repository name, or unrecovered verdict to make chronology look complete.

`MISSING_HISTORY != PERMISSION_TO_RECONSTRUCT`

## 10. Re-entry output
After loading a context package, restate only the minimum operational surface:
- mode;
- active role if useful;
- verified vs provisional;
- incumbent baseline vs open seams;
- governing intent/constraints;
- current authority lineage;
- live hypotheses / next discriminator when relevant;
- immediate next action;
- verify-first pointers that could affect the next consequence-bearing step.

Then begin useful work. Re-entry is not a doctrine-recitation ritual.
