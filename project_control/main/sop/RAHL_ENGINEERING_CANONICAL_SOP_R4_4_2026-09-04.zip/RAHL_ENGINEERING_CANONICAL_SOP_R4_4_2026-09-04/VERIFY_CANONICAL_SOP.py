from __future__ import annotations
import hashlib,json,re,sys,zipfile
from pathlib import Path
PACKAGE_ID='RAHL_ENGINEERING_CANONICAL_SOP_R4_4_2026-09-04'
PARENT_ID='RAHL_ENGINEERING_CANONICAL_SOP_R4_3_2026-09-04'
PARENT_SHA='cd46c482608f48b1d15ad99acf4eafd07712de6b0efc44dc9e8638b3fdaaf58e'
R42_SHA='eb167543e9ceb2ae01449f421d2916e61b7dd924270ea2e83e3364c9d808ce9a'
R41_SHA='af4364fbcf8e5d33aa2ad06e4da9c4669d4be2ffcbc332e416742bec1543f4d2'
R40_SHA='020fcfb642a304869f2d266080f4dcf21959ca09c5fa14f60c0ec06616273f0a'
R31_SHA='4d205becc2413889bdb37c6b6ff7513d6f759a7dff1d9f9b8fddaddd8235a278'
EVIDENCE={'evidence/receiver_continuity_qualification/CANDIDATE_SEAL.json':'16c04f9460a1dcad12485db00ee6639f63f8382862262eadf26ea5af7829fdea','evidence/receiver_continuity_qualification/CONTINUITY_ENVELOPE_V0_1.patch':'59fef362ce36896a20379d1514ae865aad547b3ce57705fad9b8add382bc106a','evidence/receiver_continuity_qualification/QUALIFICATION_REPORT.md':'5a8d50cf7dcd95722756116db786dae32944efb7360d1cf7f47ad37e88115aa7','evidence/receiver_continuity_qualification/SOURCE_SNAPSHOT_MANIFEST.json':'20c83018ee217de05e714edaaef3b97ce49899d4d18db2cb6601f0d01c83d24f'}
BS=chr(92)
FORBIDDEN_ACTIVE=['PCMMAD','HOSTILE-OS','Microseed','Proto-AGI','PAL','CFE','Singularity Works','Forge','StarMap','CIC-NERV','Steve Grand','Tommy','SPECIFICPROJECT_SENTINEL']
HOST_PATTERNS=[
 ('drive_letter_root',re.compile(r'(?<![A-Za-z0-9])[A-Za-z]:['+BS*2+r'/](?!['+BS*2+r'/])'),'runtime at E:'+BS+'sandbox'+BS+'projects','see https://example.invalid/docs at 12:30 UTC'),
 ('posix_home',re.compile(r'/home/[A-Za-z0-9._-]+/'),'logs under /home/someaccount/runs','logs under /home/ and /var/log/'),
 ('posix_users',re.compile(r'/Users/[A-Za-z0-9._-]+/'),'logs under /Users/someaccount/runs','see the Users section'),
 ('unc_share',re.compile(r'(?<!\S)'+BS*4+r'[A-Za-z0-9._-]+'+BS*2+r'[A-Za-z0-9._$-]+'),'share at '+BS*2+'buildhost'+BS+'drop','prose mentioning a network share')]
HOST_ACCOUNT_TOKENS=[]
ANTI_BINDINGS=[
 (re.compile(r'convenience alone is (?:sufficient|enough|acceptable)',re.I),'assistant-side convenience promoted to sufficient'),
 (re.compile(r'(?:advisory only|purely advisory|non-binding|optional and advisory)',re.I),'standing obligation demoted to advisory'),
 (re.compile(r'MAY bypass (?:approval|safety|authority|access-control)',re.I),'fallback promoted to authority bypass'),
 (re.compile(r'automated checks (?:may|can|do) (?:substitute|replace)',re.I),'automated checks promoted over semantic read'),
 (re.compile(r'semantic read (?:may be|can be|is) (?:skipped|optional|waived)',re.I),'semantic gate waived'),
 (re.compile(r'(?:this|the) (?:rule|obligation|gate|constraint) (?:may|can) be (?:ignored|waived|skipped)',re.I),'blanket waiver clause'),
 (re.compile(r'(?:operator[- ]side|operator owned|operator-owned).{0,120}(?:merely a suggestion|just a suggestion|may be ignored|can be ignored).{0,120}(?:assistant|model)',re.I|re.S),'operator-side default demoted by synonym'),
 (re.compile(r'automated (?:verification|checks|tests).{0,120}(?:sufficient|enough|adequate).{0,120}semantic (?:admission|read|review)',re.I|re.S),'automated evidence promoted to semantic admission'),
 (re.compile(r'(?:repeated appearance|recurrence|recurrent).{0,140}(?:sufficient|enough|adequate).{0,140}universal (?:doctrine|authority|law)',re.I|re.S),'recurrence promoted to universal authority'),
 (re.compile(r'remembered pointer.{0,140}(?:acted on|treated|used).{0,80}(?:as )?current',re.I|re.S),'remembered pointer promoted to current state'),
 (re.compile(r'shared (?:access to )?.{0,80}immutable.{0,120}(?:enough|sufficient|adequate).{0,160}(?:(?:live process|runtime).{0,100}ownership|ownership.{0,100}(?:live process|runtime))',re.I|re.S),'shared immutable access promoted to runtime ownership'),
 (re.compile(r'historical .{0,80}label.{0,120}(?:accepted|treated).{0,100}literal internal (?:mechanism|truth|state)',re.I|re.S),'historical label promoted to literal internals'),
 (re.compile(r'(?:completed )?ledger entry.{0,120}(?:sufficient|enough|adequate).{0,100}proof.{0,80}(?:understood|comprehension)',re.I|re.S),'ledger attestation promoted to comprehension proof'),
 (re.compile(r'(?<![A-Za-z0-9_])[A-Z][A-Z_]{6,} = [A-Z][A-Z_]{6,}'),'non-equivalence collapsed')]
REQUIRED_DOCS=[f'{i:02d}_' for i in range(17)]
REQUIRED_FIXED={'PROMOTION_RECEIPT.md','RELEASE_VERIFICATION.md','VERIFY_CANONICAL_SOP.py','RUN_R4_4_QUALIFICATION.py','SEMANTIC_READ_LEDGER.json','tests/RUN_HOSTILE_TESTS.py','machine/AUTHORITY_CLASSES.json','machine/BASE_TIER_ENGINEERING_METABOLISM.json','machine/CONTINUITY_INSTRUMENTS.json','machine/EXECUTION_AND_ENVIRONMENT.json','machine/SCARS.json','machine/INTERFACE_AND_REENTRY.json','machine/GLOBAL_SCAR_LEDGER_CONTRACT.json','machine/ACTIVE_SURFACE_SECTIONS.json','03A_COLLABORATION_WRITING_AND_TEACHING_INTERFACE.md','06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','11A_GLOBAL_CROSS_PROJECT_SCAR_LEDGER_PROTOCOL.md','12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','16_SEMANTIC_READ_LEDGER_PROTOCOL.md','publication/GITATTRIBUTES_FRAGMENT.txt','ancestry/RAHL_ENGINEERING_CANONICAL_SOP_R4_3_2026-09-04.zip','ancestry/RAHL_ENGINEERING_CANONICAL_SOP_R4_2_2026-09-03.zip','ancestry/RAHL_ENGINEERING_CANONICAL_SOP_R4_1_2026-09-03.zip','ancestry/RAHL_ENGINEERING_CANONICAL_SOP_R4_0_2026-09-02.zip','ancestry/RAHL_ENGINEERING_IN_HOUSE_SOP_SPLIT_CANDIDATE_R3_1_2026-08-29.zip'}
SELF='VERIFY_CANONICAL_SOP.py'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(msg):print('FAIL:',msg);return 2
def headings(t):return [ln.rstrip() for ln in t.splitlines() if ln.startswith('#')]
def guard_self_test():
 for name,pat,pos,neg in HOST_PATTERNS:
  if not pat.search(pos):return f'host guard {name} failed positive-detection self-test'
  if pat.search(neg):return f'host guard {name} matched negative control'
 return None
def main(root):
 root=root.resolve()
 if root.name!=PACKAGE_ID:return fail(f'package id {root.name!r}')
 st=guard_self_test()
 if st:return fail(st)
 mf=root/'MANIFEST_SHA256.json'
 try:m=json.loads(mf.read_text(encoding='utf-8'))
 except Exception as e:return fail(f'manifest parse {e}')
 if m.get('package_id')!=PACKAGE_ID or m.get('schema')!='rahl.sop.package-manifest.v1':return fail('manifest identity/schema')
 expected=set(m['files']);actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=mf}
 if not REQUIRED_FIXED.issubset(expected):return fail(f'required fixed missing={sorted(REQUIRED_FIXED-expected)}')
 for prefix in REQUIRED_DOCS:
  matches=sorted(rel for rel in expected if '/' not in rel and rel.startswith(prefix) and rel.endswith('.md'))
  if len(matches)!=1:return fail(f'required canonical doc {prefix} count={len(matches)} matches={matches}')
 if expected!=actual:return fail(f'membership missing={sorted(expected-actual)} extra={sorted(actual-expected)}')
 for rel,meta in m['files'].items():
  p=root/rel
  if p.stat().st_size!=meta['bytes'] or h(p)!=meta['sha256']:return fail(f'hash/size {rel}')
 if any(BS in rel for rel in m['files']):return fail('backslash member identity in manifest')
 active=[]
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root).as_posix()
  if rel.startswith(('ancestry/','evidence/','tests/','publication/')):continue
  if p.suffix.lower() not in {'.md','.json','.py'}:continue
  try:t=p.read_text(encoding='utf-8')
  except UnicodeDecodeError:return fail(f'active utf8 {rel}')
  active.append((rel,t))
 for rel,t in active:
  if rel==SELF:continue
  for token in FORBIDDEN_ACTIVE:
   if re.search(r'(?<![A-Za-z0-9_-])'+re.escape(token)+r'(?![A-Za-z0-9_-])',t,re.I):return fail(f'project/person contamination {token!r} in {rel}')
  for name,pat,_p,_n in HOST_PATTERNS:
   mt=pat.search(t)
   if mt:return fail(f'host identity contamination {name} in {rel}: {mt.group(0)!r}')
  for token in HOST_ACCOUNT_TOKENS:
   if re.search(r'(?<![A-Za-z0-9_-])'+re.escape(token)+r'(?![A-Za-z0-9_-])',t,re.I):return fail(f'operator account token in {rel}')
  for pat,desc in ANTI_BINDINGS:
   mt=pat.search(t)
   if mt:return fail(f'anti-binding violation in {rel}: {desc} ({mt.group(0)!r})')
 old='PROBE -> DERIVE -> EMBODY -> VERIFY -> RECURSE'
 for rel,t in active:
  if rel!=SELF and old in t:return fail(f'legacy PDVER ordering in {rel}')
 try:sections=json.loads((root/'machine/ACTIVE_SURFACE_SECTIONS.json').read_text(encoding='utf-8'))
 except Exception as e:return fail(f'section registry parse {e}')
 if sections.get('schema')!='rahl.sop.active-surface-sections.v1':return fail('section registry schema')
 declared=sections['documents'];md_active=sorted(rel for rel,_ in active if rel.endswith('.md'))
 if sorted(declared)!=md_active:return fail(f'section registry coverage missing={sorted(set(md_active)-set(declared))} extra={sorted(set(declared)-set(md_active))}')
 for rel,t in active:
  if rel.endswith('.md') and headings(t)!=declared[rel]:return fail(f'section inventory drift in {rel}')
 bindings={
 '00_READ_ME_FIRST.md':['Rahl Engineering Canonical SOP — R4.4','GATE_ASSERTED != GATE_WITNESSED','SIBLING_DONOR != CANONICAL_PARENT'],
 '02_ENGINEERING_AUTHORITY_SURFACE.md':['C27 — Mechanism-first technical interface','C30 — Scar aggregation and reuse discipline','C31 — Publication-surface host and operator identity hygiene','C32 — Gate obligations require an evidence surface','C33 — Guards and attack suites require structurally different witnesses','GUARD_PRESENT != GUARD_EXERCISED','PROTECTED_STRING_INTACT != MEANING_INTACT'],
 '03A_COLLABORATION_WRITING_AND_TEACHING_INTERFACE.md':['mechanism -> example -> technical name -> application','mechanism first -> precision second -> style third','Do not dumb down the model of reality.'],
 '04_RESEARCH_GOVERNANCE.md':['PROBE -> DERIVE -> VERIFY -> EMBODY -> RECURSE'],
 '05_RESEARCH_MACHINERY_AND_MODES.md':['BASE_TIER_FUNCTIONAL_OBLIGATIONS != OPTIONAL_FOR_NONTRIVIAL_WORK'],
 '06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md':['E23 — Runtime ownership is not file ownership','E24 — Permission and remote currentness','E25 — Publication normalization residual','E26 — Additive mutation is a first-class attack class','SEALED_BYTES != PUBLISHED_BYTES'],
 '06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md':['Use the strongest surviving plane, not the prettiest plane.','Assistant-side convenience alone is not enough.'],
 '07C_RESEARCH_EPISTEMIC_SHADOW_PROTOCOL.md':['RES_CONTENT != GOVERNING_DOCTRINE'],
 '09_UNKNOWN_TRACE_AND_RECOVERY_RULE.md':['Never guess across the gap'],
 '11A_GLOBAL_CROSS_PROJECT_SCAR_LEDGER_PROTOCOL.md':['SCAR_AGGREGATION != SCAR_AUTHORITY_PROMOTION','CROSS_PROJECT_COPY != INDEPENDENT_REDERIVATION','RECURRENCE != UNIVERSALITY'],
 '12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md':['CONTINUITY_MAP != CURRENT_STATE_EVIDENCE','RESEARCH_PROGRESSION != CANONICAL_PROMOTION','REMEMBERED_SUMMARY != SOURCE_CONTACT'],
 '13_PACKAGE_ARCHIVE_AND_PROVENANCE.md':['Publication surface reconciliation','SEALING_EXEMPTION != PUBLICATION_EXEMPTION'],
 '14_CHANGELOG_AND_CULL_LEDGER.md':['R4.4 synthesis — canonical R4.3 + independent enforcement sibling','SIBLING_DONOR != CANONICAL_PARENT'],
 '15_CLAIM_CEILING_AND_NONCLAIMS.md':['section-inventory and anti-binding witnesses are independent evidence','semantic-read ledger proves comprehension'],
 '16_SEMANTIC_READ_LEDGER_PROTOCOL.md':['GATE_ASSERTED != GATE_WITNESSED','REUSED_EXACT_HASH','FRESH_READ_REQUIRED','FRESH_READ_COMPLETED','ATTESTATION != COMPREHENSION']}
 for rel,need in bindings.items():
  t=(root/rel).read_text(encoding='utf-8')
  for s in need:
   if s not in t:return fail(f'binding missing {rel}: {s}')
 for rel in ['machine/AUTHORITY_CLASSES.json','machine/BASE_TIER_ENGINEERING_METABOLISM.json','machine/CONTINUITY_INSTRUMENTS.json','machine/EXECUTION_AND_ENVIRONMENT.json','machine/SCARS.json','machine/INTERFACE_AND_REENTRY.json','machine/GLOBAL_SCAR_LEDGER_CONTRACT.json','machine/ACTIVE_SURFACE_SECTIONS.json']:
  try:json.loads((root/rel).read_text(encoding='utf-8'))
  except Exception as e:return fail(f'json {rel}: {e}')
 anc=[('parent R4.3',root/'ancestry'/(PARENT_ID+'.zip'),PARENT_SHA),('retained R4.2',root/'ancestry'/'RAHL_ENGINEERING_CANONICAL_SOP_R4_2_2026-09-03.zip',R42_SHA),('retained R4.1',root/'ancestry'/'RAHL_ENGINEERING_CANONICAL_SOP_R4_1_2026-09-03.zip',R41_SHA),('retained R4.0',root/'ancestry'/'RAHL_ENGINEERING_CANONICAL_SOP_R4_0_2026-09-02.zip',R40_SHA),('retained R3.1',root/'ancestry'/'RAHL_ENGINEERING_IN_HOUSE_SOP_SPLIT_CANDIDATE_R3_1_2026-08-29.zip',R31_SHA)]
 for label,p,d in anc:
  if h(p)!=d:return fail(f'{label} ancestry hash')
  try:
   with zipfile.ZipFile(p) as z:
    if z.testzip() is not None:return fail(f'{label} CRC')
  except Exception as e:return fail(f'{label} zip {e}')
 for rel,d in EVIDENCE.items():
  if h(root/rel)!=d:return fail(f'evidence identity {rel}')
 try:led=json.loads((root/'SEMANTIC_READ_LEDGER.json').read_text(encoding='utf-8'))
 except Exception as e:return fail(f'ledger parse {e}')
 if led.get('schema')!='rahl.sop.semantic-read-ledger.v1' or led.get('package_id')!=PACKAGE_ID or led.get('parent_package_id')!=PARENT_ID or led.get('parent_sha256')!=PARENT_SHA:return fail('ledger identity/schema')
 try:
  with zipfile.ZipFile(root/'ancestry'/(PARENT_ID+'.zip')) as z:pm=json.loads(z.read(PARENT_ID+'/MANIFEST_SHA256.json').decode())['files']
 except Exception as e:return fail(f'parent manifest read {e}')
 need={rel for rel in m['files'] if not rel.startswith('ancestry/') and rel!='SEMANTIC_READ_LEDGER.json'};ent=led.get('entries',{})
 if set(ent)!=need:return fail(f'ledger coverage missing={sorted(need-set(ent))} extra={sorted(set(ent)-need)}')
 pending=[]
 for rel,e in sorted(ent.items()):
  if e.get('sha256')!=m['files'][rel]['sha256'] or e.get('bytes')!=m['files'][rel]['bytes']:return fail(f'ledger hash disagreement {rel}')
  d=e.get('disposition')
  if d=='REUSED_EXACT_HASH':
   if rel not in pm or pm[rel]['sha256']!=e['sha256'] or e.get('parent_sha256')!=pm[rel]['sha256']:return fail(f'ledger reuse contradicts parent {rel}')
  elif d=='FRESH_READ_COMPLETED':
   for f in ('read_by','read_at','read_note'):
    v=e.get(f)
    if not isinstance(v,str) or not v.strip() or v.strip().upper() in {'TBD','TODO','N/A','PENDING','NULL','X'}:return fail(f'ledger attestation incomplete {rel}: {f}')
  elif d=='FRESH_READ_REQUIRED':
   if any(e.get(f) is not None for f in ('read_by','read_at','read_note')):return fail(f'unread carries attestation {rel}')
   pending.append(rel)
  else:return fail(f'ledger disposition {rel}: {d!r}')
 pr=(root/'PROMOTION_RECEIPT.md').read_text(encoding='utf-8');mdis=re.search(r'^Disposition: `([A-Z_]+)`\s*$',pr,re.M)
 if not mdis:return fail('promotion receipt disposition missing')
 dis=mdis.group(1)
 status_text=(root/'00_READ_ME_FIRST.md').read_text(encoding='utf-8')
 if pending:
  if dis!='CANDIDATE_PENDING_SEMANTIC_READ' or 'Status: `CANDIDATE_PENDING_SEMANTIC_READ`' not in status_text:return fail(f'promotion/readiness claimed with {len(pending)} unread')
  state=f'NOT_PROMOTED; {len(pending)} pending'
 else:
  if dis=='CANDIDATE_READY_FOR_PROMOTION':
   if 'Status: `CANDIDATE_READY_FOR_PROMOTION`' not in status_text:return fail('ready receipt/status mismatch')
   state='READY_FOR_PROMOTION'
  elif dis=='PROMOTED_TO_CANONICAL_IN_HOUSE_SOP':
   if 'Status: `CANONICAL_IN_HOUSE_SOP`' not in status_text:return fail('promoted receipt/status mismatch')
   state='PROMOTED'
  else:return fail(f'bad disposition {dis}')
 print('PASS: merged R4.4 structure, host guards+self-test, section inventory, anti-binding, semantic bindings, exact ancestry/evidence, semantic-read ledger vs sealed R4.3 parent. STATE: '+state)
 return 0
if __name__=='__main__':raise SystemExit(main(Path(sys.argv[1] if len(sys.argv)>1 else '.')))
