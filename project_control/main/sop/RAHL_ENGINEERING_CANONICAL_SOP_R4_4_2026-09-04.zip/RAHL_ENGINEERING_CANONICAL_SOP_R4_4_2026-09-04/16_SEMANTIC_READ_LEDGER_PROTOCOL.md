# 16 — Semantic Read Ledger Protocol

The linear semantic-read gate (C24, C32, E13, `08`, `13`) is a load-bearing admission rule. Receipt prose asserting that a read occurred is not the machine-checkable record the gate requires.

`GATE_ASSERTED != GATE_WITNESSED`

## Purpose
The ledger records, per manifest member, whether semantic-read evidence is reused by exact hash from the sealed parent or freshly read for this release, and who attested a fresh read. It does not prove comprehension. It makes the claim explicit, byte-bound, internally checkable, and falsifiable against the sealed parent.

## Instrument
`SEMANTIC_READ_LEDGER.json`, schema `rahl.sop.semantic-read-ledger.v1`.

Required top-level fields:
- `schema`;
- `package_id`;
- `parent_package_id`;
- `parent_sha256`;
- `entries`.

The ledger records every manifest member except `ancestry/*` archives and the ledger file itself. The self-exclusion avoids an impossible self-referential hash. Each entry carries `sha256`, `bytes`, `disposition`, and for reuse `parent_sha256`.

## Dispositions
- `REUSED_EXACT_HASH` — bytes match the same logical path in the sealed parent and governing role/scope is unchanged; verifier checks against the parent's own manifest.
- `FRESH_READ_REQUIRED` — new/changed member not yet attested; `read_by`, `read_at`, `read_note` are null.
- `FRESH_READ_COMPLETED` — complete linear semantic read attested; `read_by`, `read_at`, `read_note` are present and non-placeholder.

## Promotion interlock
While any entry remains `FRESH_READ_REQUIRED`, the package SHALL declare candidate status and SHALL NOT declare itself promoted. The verifier enforces this interlock. Promotion requires a separate mutation/re-manifest/re-verification/re-seal cycle after the ledger is complete.

`CANDIDATE_STATUS_IS_THE_HONEST_STATE_UNTIL_THE_READ_IS_DONE`

## Claim ceiling
The ledger is an attestation surface. It establishes that a named authority claims a specific read over specific bytes at a specific time and that no member escaped the question. It does not establish comprehension, attention, or correctness. Reuse by hash inherits the quality of the parent's read.

`ATTESTATION != COMPREHENSION`
`REUSE_BY_HASH_INHERITS_PARENT_READ_QUALITY`
