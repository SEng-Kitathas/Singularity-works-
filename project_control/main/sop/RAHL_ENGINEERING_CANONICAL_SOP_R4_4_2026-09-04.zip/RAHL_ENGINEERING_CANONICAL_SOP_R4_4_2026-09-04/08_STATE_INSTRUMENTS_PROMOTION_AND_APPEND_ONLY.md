# 08 — State Instruments, Promotion, and Append-Oriented History

## State instruments
### Current State
Present operational status, exact baseline, active frontier, verified/provisional split, and blockers.

### Next Steps
Only actionable upcoming work/discriminators. Do not use as a history dump.

### Doctrine Snapshot
Currently active laws, constraints, methods, and deltas. Historical ideas do not become current doctrine by proximity.

### Revisit Ledger
Anything important enough to replay, demote, confirm, or un-block gets an explicit return path.

### Trace Matrix
Anything carrying structural weight should map upstream evidence -> interpretation/derivation -> embodiment -> verification -> status -> demotion trigger.

## Promotion ladder
`RAW -> SEED -> CANDIDATE -> WORKING -> LOAD_BEARING -> CANON`

Nothing becomes `CANON` without, at minimum:
- embodiment where embodiment is applicable;
- verification suited to the claim;
- contradiction/adversarial pressure;
- scope/generalization argument beyond one local seam.

## Demotion
Use `QUESTIONED`, `LOCAL_ONLY`, `DEPRECATED`, `TOMBSTONED`, or an explicit narrower status when evidence defeats or narrows a prior claim.

## Append-oriented law
Once sealed, evidence/history SHALL NOT be silently rewritten. Prefer new artifacts/addenda. If replacement is unavoidable, record what changed, why, what it supersedes, and what risk the replacement introduces.

`IMMUTABLE_RECORD != IMMUTABLE_INTERPRETATION`
`CANONICAL != FINAL`
`PRESERVE_NEGATIVE_HISTORY != FREEZE_NEGATIVE_AS_PERMANENT_DOCTRINE`

## Linear semantic admission rule
For any meaningfully readable artifact, complete linear semantic reading is a necessary admission condition before `LOAD_BEARING`, `CANON`, sealing, publication, or equivalent authority-bearing use. Automated checks can establish structural, syntactic, integrity, test, and hostile-mutation facts; they do not substitute for semantic reading.

An exact-hash semantic-read receipt may be reused only while both exact bytes and governing scope remain unchanged. If semantics change, the changed artifact must be read again before renewed authority transition.

`AUTOMATED_CHECKS != LINEAR_SEMANTIC_READ`
`WRITE_COMPLETED != SEMANTIC_GATE_SATISFIED`


## Global Scar Ledger as adjacent state instrument
The Global Scar Ledger is a mutable cross-project navigation instrument adjacent to Current State, Doctrine Snapshot, Revisit Ledger, Trace Matrix, Live Shadow, Design Thread Stream, and RES.

It does not replace any of them:
- Scar Ledger = prior failure distinctions across projects;
- Doctrine Snapshot = rules active now;
- Revisit Ledger = unresolved seams that must return;
- Trace Matrix = current load-bearing claim/artifact lineage.

`SCAR_LEDGER != DOCTRINE_SNAPSHOT`
`SCAR_LEDGER != REVISIT_LEDGER`
`SCAR_LEDGER != TRACE_MATRIX`
