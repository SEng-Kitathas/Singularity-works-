# Release Verification — R4.4

Status: `PROMOTED_CANONICAL_RELEASE; PROMOTION_VALID_ONLY_AFTER_FINAL_SEMANTIC_READ_REQUALIFICATION_AND_RESEAL`
Date: 2026-09-04
Assurance ceiling: `STRUCTURE_MEMBERSHIP_HASH_BINDING_BASE_TIER_METABOLISM_SEMANTIC_READ_LEDGER_LOCAL_EXECUTION_INTERFACE_REENTRY_SCAR_LEDGER_HOST_IDENTITY_SECTION_INVENTORY_ANTIBINDING_PUBLICATION_RECONCILIATION_AND_HOSTILE_MUTATION_ONLY`

## Required automated gates
- exact membership/hash/byte verification;
- host identity patterns with positive/negative self-test;
- active-surface heading inventory;
- anti-binding scan for common additive reversals;
- canonical R4.3 interface/re-entry/global-scar bindings;
- semantic-read ledger coverage/hash agreement/reuse verification against the sealed R4.3 parent;
- promotion interlock while unread members remain;
- exact canonical parent and retained ancestry/evidence;
- additive and substitution hostile attacks;
- deterministic qualification seal.

## Claim ceiling
The added witnesses are structurally different, not independently authored. Anti-binding remains phrase-bounded, but re-manifested and re-attested synonym-reversal attacks are now mandatory hostile cases. Ledger attestation is not comprehension. Publication reconciliation exposes residuals rather than erasing them.
