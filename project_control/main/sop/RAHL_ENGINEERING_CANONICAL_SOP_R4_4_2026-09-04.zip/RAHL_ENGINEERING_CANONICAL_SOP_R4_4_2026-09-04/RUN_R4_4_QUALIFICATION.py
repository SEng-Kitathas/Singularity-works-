from pathlib import Path
import json,subprocess,sys,tempfile,zipfile,hashlib
ROOT=Path(__file__).resolve().parent
PY=sys.executable
def run(cmd):return subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
def seal(path):
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(x for x in ROOT.rglob('*') if x.is_file()):
   if p==path:continue
   rel=p.relative_to(ROOT).as_posix();zi=zipfile.ZipInfo(ROOT.name+'/'+rel,date_time=(2026,9,4,8,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.create_system=3;zi.external_attr=0o100644<<16;z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 v=run([PY,'-S',str(ROOT/'VERIFY_CANONICAL_SOP.py'),str(ROOT)])
 hs=run([PY,str(ROOT/'tests/RUN_HOSTILE_TESTS.py')])
 with tempfile.TemporaryDirectory() as td:
  a=Path(td)/'a.zip';b=Path(td)/'b.zip';seal(a);seal(b);det=h(a)==h(b)
 try:j=json.loads(hs.stdout)
 except Exception:j={}
 out={'verifier_rc':v.returncode,'hostile_rc':hs.returncode,'hostile_cases':j.get('hostile_cases'),'hostile_rejected':j.get('rejected_as_expected'),'hostile_unexpected':[x.get('name') for x in j.get('unexpected_passes',[])],'deterministic_seal':det,'verifier_tail':v.stdout.strip().splitlines()[-1:] if v.stdout else []}
 print(json.dumps(out,sort_keys=True));return 0 if v.returncode==0 and hs.returncode==0 and det else 2
if __name__=='__main__':raise SystemExit(main())
