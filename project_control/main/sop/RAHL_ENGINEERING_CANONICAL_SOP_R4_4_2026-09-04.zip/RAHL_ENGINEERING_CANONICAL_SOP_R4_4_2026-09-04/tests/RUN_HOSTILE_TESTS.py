from __future__ import annotations
import hashlib, json, shutil, subprocess, sys, tempfile
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
PY=sys.executable

def sha(p:Path)->str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(root:Path):
    return subprocess.run([PY,'-S',str(root/'VERIFY_CANONICAL_SOP.py'),str(root)],capture_output=True,text=True)

def rehash(root:Path, rel:str):
    mf=root/'MANIFEST_SHA256.json'
    m=json.loads(mf.read_text(encoding='utf-8'))
    p=root/rel
    m['files'][rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
    mf.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')

def mutate(root:Path, rel:str, old:str, new:str, *, remanifest:bool=True):
    p=root/rel
    t=p.read_text(encoding='utf-8')
    if old not in t:raise RuntimeError(f'mutation anchor missing {rel}: {old}')
    p.write_text(t.replace(old,new,1),encoding='utf-8',newline='\n')
    if remanifest:
        rehash(root,rel)

def append_and_rehash(root:Path, rel:str, text:str):
    p=root/rel
    p.write_text(p.read_text(encoding='utf-8')+text,encoding='utf-8',newline='\n')
    rehash(root,rel)

def reattest_changed_member(root:Path, rel:str):
    from datetime import datetime, timezone
    led=root/'SEMANTIC_READ_LEDGER.json'; d=json.loads(led.read_text(encoding='utf-8')); p=root/rel
    e=d['entries'][rel]; e['bytes']=p.stat().st_size; e['sha256']=sha(p); e['disposition']='FRESH_READ_COMPLETED'; e.pop('parent_sha256',None)
    e['read_by']='Hostile mutation harness'; e['read_at']=datetime.now(timezone.utc).isoformat(); e['read_note']='Synthetic hostile mutation re-attested so semantic witnesses must reject it.'
    led.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n'); rehash(root,'SEMANTIC_READ_LEDGER.json')

def append_semantic_reattested(root:Path, rel:str, text:str):
    p=root/rel; p.write_text(p.read_text(encoding='utf-8')+'\n'+text+'\n',encoding='utf-8',newline='\n'); rehash(root,rel); reattest_changed_member(root,rel)

def delete_and_remanifest(root:Path, rel:str):
    p=root/rel
    p.unlink()
    mf=root/'MANIFEST_SHA256.json'
    m=json.loads(mf.read_text(encoding='utf-8'))
    m['files'].pop(rel,None)
    mf.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')

def mutate_manifest_package_id(root:Path):
    mf=root/'MANIFEST_SHA256.json'
    m=json.loads(mf.read_text(encoding='utf-8'))
    m['package_id']='RAHL_ENGINEERING_CANONICAL_SOP_R4_3_2026-09-04'
    mf.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')

def main():
    cases=[]
    # Semantic mutations are deliberately re-manifested so rejection must come from
    # semantic/authority guards rather than the trivial fact that bytes changed.
    cases.append(('candidate_id_collision',lambda r: mutate(r,'00_READ_ME_FIRST.md','R4.4','R4.3')))
    cases.append(('continuity_becomes_proof',lambda r: mutate(r,'00_READ_ME_FIRST.md','CONTINUITY != PROOF','CONTINUITY = PROOF')))
    cases.append(('remembered_pointer_becomes_current',lambda r: mutate(r,'00_READ_ME_FIRST.md','REMEMBERED_POINTER != CURRENT_STATE_EVIDENCE','REMEMBERED_POINTER = CURRENT_STATE_EVIDENCE')))
    cases.append(('base_tier_becomes_optional',lambda r: mutate(r,'05_RESEARCH_MACHINERY_AND_MODES.md','BASE_TIER_FUNCTIONAL_OBLIGATIONS != OPTIONAL_FOR_NONTRIVIAL_WORK','BASE_TIER_FUNCTIONAL_OBLIGATIONS = OPTIONAL_FOR_NONTRIVIAL_WORK')))
    cases.append(('pdver_order_regresses',lambda r: mutate(r,'04_RESEARCH_GOVERNANCE.md','PROBE -> DERIVE -> VERIFY -> EMBODY -> RECURSE','PROBE -> DERIVE -> EMBODY -> VERIFY -> RECURSE')))
    cases.append(('ai_coprocessor_removed',lambda r: mutate(r,'05_RESEARCH_MACHINERY_AND_MODES.md','## AI co-processor obligation','## Optional AI assistance')))
    cases.append(('res_self_promotes',lambda r: mutate(r,'07C_RESEARCH_EPISTEMIC_SHADOW_PROTOCOL.md','RES_CONTENT != GOVERNING_DOCTRINE','RES_CONTENT = GOVERNING_DOCTRINE')))
    cases.append(('environment_identity_collapsed',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','SEALED_ARTIFACT != SEALED_ENVIRONMENT','SEALED_ARTIFACT = SEALED_ENVIRONMENT')))
    cases.append(('fixed_transport_limit_reintroduced',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','No fixed transport limit is universal SOP law','Universal archive part limit is 200000000 bytes')))
    cases.append(('unknown_guessing_allowed',lambda r: mutate(r,'09_UNKNOWN_TRACE_AND_RECOVERY_RULE.md','Never guess across the gap','Guess across the gap when convenient')))
    cases.append(('fresh_chat_blindness_collapse',lambda r: mutate(r,'12_COLD_START_PROTOCOL.md','FRESH_THREAD != FRESH_EVALUATOR_IF_MEMORY_OR_HISTORY_IS_SHARED','FRESH_THREAD = FRESH_EVALUATOR_IF_MEMORY_OR_HISTORY_IS_SHARED')))
    cases.append(('extra_unmanifested_file',lambda r: (r/'SURPRISE.txt').write_text('x',encoding='utf-8')))
    cases.append(('project_specific_contamination',lambda r: append_and_rehash(r,'02_ENGINEERING_AUTHORITY_SURFACE.md','\nSpecific project: SPECIFICPROJECT_SENTINEL\n')))
    def corrupt_parent(r:Path):
        p=r/'ancestry'/'RAHL_ENGINEERING_CANONICAL_SOP_R4_3_2026-09-04.zip'
        with p.open('ab') as f:f.write(b'X')
        rehash(r,'ancestry/RAHL_ENGINEERING_CANONICAL_SOP_R4_3_2026-09-04.zip')
    cases.append(('parent_ancestry_corrupted_but_remanifested',corrupt_parent))
    cases.append(('semantic_read_gate_demoted',lambda r: mutate(r,'02_ENGINEERING_AUTHORITY_SURFACE.md','it SHALL receive a complete linear semantic read','it MAY receive a partial semantic skim')) )
    cases.append(('automated_checks_replace_semantic_read',lambda r: mutate(r,'02_ENGINEERING_AUTHORITY_SURFACE.md','AUTOMATED_CHECKS != LINEAR_SEMANTIC_READ','AUTOMATED_CHECKS = LINEAR_SEMANTIC_READ')) )
    cases.append(('response_failure_becomes_execution_failure',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','CONTROL_PLANE_RESPONSE_FAILURE != LOCAL_EXECUTION_FAILURE','CONTROL_PLANE_RESPONSE_FAILURE = LOCAL_EXECUTION_FAILURE')) )
    cases.append(('control_plane_becomes_bulk_plane',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','CONTROL_PLANE != BULK_DATA_PLANE','CONTROL_PLANE = BULK_DATA_PLANE')) )
    cases.append(('semantic_read_skipped_for_transport',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','CONTROL_PLANE_MINIMIZATION != SEMANTIC_READ_SKIPPING','CONTROL_PLANE_MINIMIZATION = SEMANTIC_READ_SKIPPING')) )
    cases.append(('canonical_path_regression',lambda r: (r/'MANIFEST_SHA256.json').write_text((r/'MANIFEST_SHA256.json').read_text(encoding='utf-8').replace('machine/AUTHORITY_CLASSES.json','machine\\\\AUTHORITY_CLASSES.json',1),encoding='utf-8')))
    cases.append(('required_doc_deleted_and_remanifested',lambda r: delete_and_remanifest(r,'03_PROJECT_OBLIGATION_INTERFACE.md')))
    cases.append(('operator_side_default_demoted',lambda r: mutate(r,'06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','Default to the operator-owned/local/server side for as much as possible.','Default to assistant-side execution for as much as possible.')) )
    cases.append(('prettiest_plane_promoted',lambda r: mutate(r,'06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','Use the strongest surviving plane, not the prettiest plane.','Use the prettiest plane, not the strongest surviving plane.')) )
    cases.append(('assistant_convenience_becomes_enough',lambda r: mutate(r,'06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','Assistant-side convenience alone is not enough.','Assistant-side convenience alone is enough.')) )
    cases.append(('fallback_becomes_authority_bypass',lambda r: mutate(r,'06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','EXECUTION_PLANE_FALLBACK != AUTHORITY_BYPASS','EXECUTION_PLANE_FALLBACK = AUTHORITY_BYPASS')) )
    cases.append(('mechanism_first_order_removed',lambda r: mutate(r,'03A_COLLABORATION_WRITING_AND_TEACHING_INTERFACE.md','mechanism -> example -> technical name -> application','technical name -> mechanism -> application -> example')) )
    cases.append(('reality_model_dumbed_down',lambda r: mutate(r,'03A_COLLABORATION_WRITING_AND_TEACHING_INTERFACE.md','Do not dumb down the model of reality.','Simplify the model of reality whenever prose is easier.')) )
    cases.append(('scar_aggregation_promotes_authority',lambda r: mutate(r,'11A_GLOBAL_CROSS_PROJECT_SCAR_LEDGER_PROTOCOL.md','SCAR_AGGREGATION != SCAR_AUTHORITY_PROMOTION','SCAR_AGGREGATION = SCAR_AUTHORITY_PROMOTION')) )
    cases.append(('copied_scar_becomes_independent',lambda r: mutate(r,'11A_GLOBAL_CROSS_PROJECT_SCAR_LEDGER_PROTOCOL.md','CROSS_PROJECT_COPY != INDEPENDENT_REDERIVATION','CROSS_PROJECT_COPY = INDEPENDENT_REDERIVATION')) )
    cases.append(('continuity_map_becomes_current_evidence',lambda r: mutate(r,'12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','CONTINUITY_MAP != CURRENT_STATE_EVIDENCE','CONTINUITY_MAP = CURRENT_STATE_EVIDENCE')) )
    cases.append(('historical_label_becomes_internal_truth',lambda r: mutate(r,'12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','HISTORICAL_LABEL != VERIFIED_INTERNAL_MECHANISM','HISTORICAL_LABEL = VERIFIED_INTERNAL_MECHANISM')) )
    cases.append(('research_progression_becomes_canon',lambda r: mutate(r,'12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','RESEARCH_PROGRESSION != CANONICAL_PROMOTION','RESEARCH_PROGRESSION = CANONICAL_PROMOTION')) )
    cases.append(('prior_inspection_becomes_destructive_auth',lambda r: mutate(r,'12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','PRIOR_INSPECTION_PERMISSION != CURRENT_DESTRUCTIVE_AUTHORIZATION','PRIOR_INSPECTION_PERMISSION = CURRENT_DESTRUCTIVE_AUTHORIZATION')) )
    cases.append(('shared_file_becomes_runtime_ownership',lambda r: mutate(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','SHARED_IMMUTABLE_ARTIFACT != SHARED_RUNTIME_OWNERSHIP','SHARED_IMMUTABLE_ARTIFACT = SHARED_RUNTIME_OWNERSHIP')) )
    cases.append(('remembered_summary_becomes_source_contact',lambda r: mutate(r,'12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','REMEMBERED_SUMMARY != SOURCE_CONTACT','REMEMBERED_SUMMARY = SOURCE_CONTACT')) )
    def edit_ledger(r,fn):
        led=r/'SEMANTIC_READ_LEDGER.json';d=json.loads(led.read_text(encoding='utf-8'));fn(d);led.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');rehash(r,'SEMANTIC_READ_LEDGER.json')
    def append_semantic(r,rel,text):
        p=r/rel;p.write_text(p.read_text(encoding='utf-8')+text,encoding='utf-8',newline='\n');rehash(r,rel)
    cases.append(('additive_operator_default_reversal',lambda r: append_semantic(r,'06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','\n## Amendment\nThe operator-side default above is advisory only.\n')))
    cases.append(('additive_semantic_gate_waiver',lambda r: append_semantic(r,'02_ENGINEERING_AUTHORITY_SURFACE.md','\n### Exception\nFor routine releases the semantic read may be skipped.\n')))
    cases.append(('host_drive_path_leak',lambda r: append_semantic(r,'10_SUBSTRATE_PROFILE_ACTIVATION.md','\nRuntime root: E:\\sandbox\\projects\n')))
    cases.append(('host_posix_home_leak',lambda r: append_semantic(r,'10_SUBSTRATE_PROFILE_ACTIVATION.md','\nLogs under /home/exampleaccount/runs\n')))
    def disable_guard(r):
        p=r/'VERIFY_CANONICAL_SOP.py';t=p.read_text(encoding='utf-8');t=t.replace("('posix_home',re.compile(r'/home/[A-Za-z0-9._-]+/')","('posix_home',re.compile(r'/home/THIS_WILL_NEVER_MATCH/')",1);p.write_text(t,encoding='utf-8',newline='\n');rehash(r,'VERIFY_CANONICAL_SOP.py')
    cases.append(('host_guard_silently_disabled',disable_guard))
    cases.append(('section_registry_deleted',lambda r: delete_and_remanifest(r,'machine/ACTIVE_SURFACE_SECTIONS.json')))
    cases.append(('semantic_ledger_deleted',lambda r: delete_and_remanifest(r,'SEMANTIC_READ_LEDGER.json')))
    cases.append(('semantic_protocol_deleted',lambda r: delete_and_remanifest(r,'16_SEMANTIC_READ_LEDGER_PROTOCOL.md')))
    cases.append(('ledger_parent_identity_forged',lambda r: edit_ledger(r,lambda d:d.__setitem__('parent_sha256','0'*64))))
    cases.append(('ledger_member_dropped',lambda r: edit_ledger(r,lambda d:d['entries'].pop('15_CLAIM_CEILING_AND_NONCLAIMS.md',None))))
    def claim_promotion(r):
        led=r/'SEMANTIC_READ_LEDGER.json';d=json.loads(led.read_text(encoding='utf-8'));e=d['entries']['15_CLAIM_CEILING_AND_NONCLAIMS.md'];e['disposition']='FRESH_READ_REQUIRED';e['read_by']=None;e['read_at']=None;e['read_note']=None;led.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n');rehash(r,'SEMANTIC_READ_LEDGER.json')
        p=r/'PROMOTION_RECEIPT.md';pt=p.read_text(encoding='utf-8').replace('CANDIDATE_READY_FOR_PROMOTION','PROMOTED_TO_CANONICAL_IN_HOUSE_SOP').replace('CANDIDATE_PENDING_SEMANTIC_READ','PROMOTED_TO_CANONICAL_IN_HOUSE_SOP');p.write_text(pt,encoding='utf-8',newline='\n');rehash(r,'PROMOTION_RECEIPT.md')
    cases.append(('promotion_claimed_past_unread_members',claim_promotion))
    cases.append(('reattested_operator_default_synonym_reversal',lambda r: append_semantic_reattested(r,'06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md','The operator-side preference is merely a suggestion and may be ignored whenever assistant execution is easier.')))
    cases.append(('reattested_semantic_gate_equivalence_bypass',lambda r: append_semantic_reattested(r,'02_ENGINEERING_AUTHORITY_SURFACE.md','For ordinary releases, automated verification is deemed sufficient evidence of semantic admission.')))
    cases.append(('reattested_scar_recurrence_authority_bypass',lambda r: append_semantic_reattested(r,'11A_GLOBAL_CROSS_PROJECT_SCAR_LEDGER_PROTOCOL.md','Repeated appearance across projects is sufficient to treat a scar as universal doctrine without separate promotion.')))
    cases.append(('reattested_remembered_pointer_currentness_bypass',lambda r: append_semantic_reattested(r,'00_READ_ME_FIRST.md','A remembered pointer may be acted on as current unless later evidence contradicts it.')))
    cases.append(('reattested_runtime_ownership_bypass',lambda r: append_semantic_reattested(r,'06_EXECUTION_RELEASE_AND_ENVIRONMENT_DISCIPLINE.md','Shared access to an immutable model file is enough to presume ownership of the associated live process.')))
    cases.append(('reattested_historical_label_truth_bypass',lambda r: append_semantic_reattested(r,'12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md','A historical architecture label may be accepted as a literal internal mechanism unless evidence disproves it.')))
    cases.append(('reattested_attestation_comprehension_bypass',lambda r: append_semantic_reattested(r,'16_SEMANTIC_READ_LEDGER_PROTOCOL.md','A completed ledger entry is sufficient proof that the attester understood the artifact.')))
    cases.append(('manifest_package_id_drift',mutate_manifest_package_id))

    passed=[]; failed=[]
    for name,fn in cases:
        with tempfile.TemporaryDirectory() as td:
            dst=Path(td)/BASE.name
            shutil.copytree(BASE,dst)
            fn(dst)
            cp=run(dst)
            if cp.returncode!=0:
                passed.append({'name':name,'verifier_output':cp.stdout.strip().splitlines()[-1:]})
            else:
                failed.append({'name':name,'stdout':cp.stdout,'stderr':cp.stderr})
    result={'hostile_cases':len(cases),'rejected_as_expected':len(passed),'rejections':passed,'unexpected_passes':failed}
    print(json.dumps(result,indent=2))
    return 0 if not failed else 2

if __name__=='__main__':raise SystemExit(main())
