# 11A — Global Cross-Project Scar Ledger Protocol

## Purpose
The Global Scar Ledger is the central navigation surface for earned scars, failure boundaries, non-equivalences, and recurring semantic-collapse warnings across projects.

Its job is to make prior failure information discoverable without laundering project-local evidence into universal doctrine.

## Core laws
`SCAR_AGGREGATION != SCAR_AUTHORITY_PROMOTION`
`CROSS_PROJECT_COPY != INDEPENDENT_REDERIVATION`
`RECURRENCE != UNIVERSALITY`
`SCAR_LEDGER != DOCTRINE_SNAPSHOT`
`SCAR != PROHIBITION`

A scar records earned failure information or a distinction that must not be silently collapsed. A scar may imply a prohibition, guard, trigger, warning, or discriminator depending on its source scope. The word "scar" alone does not manufacture a universal ban.

## Three-tier structure
### Tier 1 — Raw scar quarry
Broad collection from project doctrine, state, research, failure reports, tests, handoffs, and historical surfaces.

Purpose: recall and archaeology.

Raw quarry MAY contain duplicate files, copied history, runtime debris, stale interpretations, and project-local language. It is evidence, not a clean authority surface.

### Tier 2 — Provenance-clean global registry
Normalize scar identities while preserving:
- source project;
- source path;
- source line/location;
- exact source-file hash;
- source class;
- exact source wording;
- recurrence count;
- distinct source-byte identities;
- copied-source aliases;
- current aggregation status.

Filter obvious execution/build transport debris and collapse exact duplicate source files by content hash before interpreting recurrence.

Cross-project recurrence SHOULD distinguish:
- recurrence from distinct source bytes / independently evolved surfaces;
- exact copied text propagated across projects;
- one-project repetition.

### Tier 3 — Promoted universal scar index
Only scars that pass explicit doctrine review may enter the sealed universal active scar index.

Promotion requires, as applicable:
1. source provenance is inspectable;
2. the scar's actual failure boundary is understood;
3. project-local assumptions have been removed or bounded;
4. recurrence/cross-project evidence is not merely copied text;
5. the scar does not contradict higher authority;
6. the universal wording preserves the earned mechanism;
7. explicit promotion is recorded.

## Query rule
Before inventing a new primitive, ontology, authority mechanism, runtime pattern, verification gate, or recovery strategy, query the Global Scar Ledger for relevant prior failures when the ledger is available.

Use the sequence:

`QUERY -> INSPECT SOURCES -> RE-DERIVE UNDER CURRENT CONSTRAINTS -> APPLY OR REJECT`

Do not copy a scar into the current project merely because it looks relevant.

## Mutable-state boundary
The full cross-project scar registry is mutable project/server state because new projects and new scars continue to appear. It SHOULD NOT be embedded wholesale into every sealed portable SOP package.

The sealed SOP contains:
- this protocol;
- the current promoted universal scar index;
- the machine contract describing the live global ledger surface.

The live environment contains the large raw/clean registries and their provenance manifests.

`MUTABLE_GLOBAL_LEDGER != SEALED_SOP_PAYLOAD`

## Promotion / demotion
A scar can be:
- `PROJECT_LOCAL`;
- `CROSS_PROJECT_RECURRENT_NOT_PROMOTED`;
- `EXACT_COPY_NOT_INDEPENDENT`;
- `UNIVERSAL_CANDIDATE`;
- `CANONICAL_ACTIVE`;
- `NARROWED`;
- `DEPRECATED`;
- `TOMBSTONED`.

Promotion or demotion SHALL be explicit and append-oriented. Do not delete the historical source trail when interpretation changes.

## Fresh-thread use
A fresh thread SHOULD load the compact active scar index with the SOP. When project/server access exists, it SHOULD query the global registry when a relevant design or failure seam appears rather than preloading the entire cross-project corpus into chat.

Thread life is not a reason to forget scars; it is a reason to keep the large ledger server-side and retrieve only relevant evidence.
