# Canonical Promotion Receipt — R4.4

Date: 2026-09-04
Disposition: `PROMOTED_TO_CANONICAL_IN_HOUSE_SOP`
Scope: project-agnostic / thread-agnostic process and cold-start authority.

## Basis
- canonical parent R4.3 exact SHA-256 `cd46c482608f48b1d15ad99acf4eafd07712de6b0efc44dc9e8638b3fdaaf58e` preserved under ancestry;
- independent sibling donor R4.3 `7d72e57dc2021af20753a942f87da38bf8ad31fbb89a6bd21145bd8e263d8552` is recorded as donor evidence, not ancestry authority;
- R4.3 interface/re-entry/global-scar mechanisms retained;
- host guard self-tests, heading inventory, anti-binding scan, semantic-read ledger/interlock, publication reconciliation, and additive hostile attacks integrated;
- automated qualification cannot advance this disposition while any ledger entry remains `FRESH_READ_REQUIRED`.

## Authority effect
R4.4 is promoted to canonical in-house process/cold-start authority only after this promotion mutation is itself re-manifested, completely linearly read on its changed readable surfaces, re-attested, re-verified, hostile-requalified, and deterministically re-sealed. R4.3 remains exact sealed ancestry rather than current authority.

`SIBLING_DONOR != CANONICAL_PARENT`
`GATE_ASSERTED != GATE_WITNESSED`
`ATTESTATION != COMPREHENSION`
