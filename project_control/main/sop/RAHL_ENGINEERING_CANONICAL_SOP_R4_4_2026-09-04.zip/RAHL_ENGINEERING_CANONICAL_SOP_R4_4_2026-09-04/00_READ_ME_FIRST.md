# Rahl Engineering Canonical SOP — R4.4

Date: 2026-09-04
Status: `CANONICAL_IN_HOUSE_SOP`
Scope: `PROJECT_AGNOSTIC_THREAD_AGNOSTIC_PROCESS_AUTHORITY`
Domain / product / architecture authority: `NONE_BY_INCLUSION`
Parent operational lineage: `R4.3`
Parent adopted ZIP SHA-256: `cd46c482608f48b1d15ad99acf4eafd07712de6b0efc44dc9e8638b3fdaaf58e`
Retained R3.1 ancestry SHA-256: `4d205becc2413889bdb37c6b6ff7513d6f759a7dff1d9f9b8fddaddd8235a278`
Assurance ceiling: `STRUCTURE_MEMBERSHIP_HASH_BINDING_BASE_TIER_METABOLISM_SEMANTIC_READ_LEDGER_LOCAL_EXECUTION_INTERFACE_REENTRY_SCAR_LEDGER_HOST_IDENTITY_SECTION_INVENTORY_ANTIBINDING_PUBLICATION_RECONCILIATION_AND_HOSTILE_MUTATION_ONLY`

This is the active canonical engineering/research SOP. R4.3 is preserved as exact sealed parent ancestry; R4.4 now supplies the canonical project-agnostic/thread-agnostic process and cold-start default.

"Universal" here means project-agnostic process default. It does **not** mean every rule is a law of nature, a product requirement, or a substitute for local safety/legal/contractual obligations.


## Base-tier operating rule
For any **nontrivial** engineering, research, architecture, diagnosis, implementation, audit, or synthesis task, the standing default approach is the combined functional metabolism of:

- **PDVER** — Probe -> Derive -> Verify -> Embody -> Recurse;
- **hostile engineering** — attack the strongest plausible survivor and preserve failure information;
- **Semantic Helix** — propose the next valuable discriminator and integrate meaning changes;
- **Attention Reservoir** — maintain breadth, neglected hypotheses, and deferred-but-live signal;
- **Loop+** — expand source contact, isomorph search, translation, control update, experiment pressure, and replay;
- **OARR** — adversarial observation / attack / replay / revision pressure;
- **CSC** — bounded cross-surface / cross-system review;
- **AI co-processor strengths** — additive search, synthesis, contradiction/blind-spot discovery, isomorphism hunting, cross-domain transfer, independent recomputation, embodiment support, and useful incidental-signal capture.

These are **standing functional obligations, not a mandatory visible choreography**. Apply them proportionally to consequence, uncertainty, novelty, reversibility, and complexity. A genuinely trivial task may collapse the machinery to near-zero explicit overhead.

`BASE_TIER_FUNCTIONAL_OBLIGATIONS != MANDATORY_LINEAR_PIPELINE`
`PROPORTIONALITY != DISPENSATION_FROM_ENGINEERING_DISCIPLINE`
`TRIVIAL_TASK != FULL_CEREMONY`

## Absolute adoption rule
1. Treat continuity artifacts as navigation and preserved state, not automatic current-state proof.
2. Governing intent and standing obligations remain active until superseded by the authority that owns them.
3. Paths, hashes, commits, process IDs, ports, campaign positions, environment facts, and repository states are pointers until live evidence verifies their currentness.
4. Preserve truth and authority classes explicitly; do not flatten them into one confidence tone.
5. Never silently merge branches, promote experiments, resolve contradictions, reconstruct missing history, or infer across unread gaps.
6. Inspect durable evidence first. If a load-bearing unknown or unexplained trace remains, ask the owning authority rather than guess across the gap.
7. Project-local context belongs in project state, not in this universal SOP.
8. If a meaningfully readable artifact is to be promoted, sealed, published, admitted, or treated as load-bearing, complete its linear semantic read first. Automated checks may support this gate; they may not substitute for it.
9. Put finite deterministic bulk work where the state lives: prefer bounded durable local/server execution with local evidence and compact control-plane receipts over bridge-mediated bulk transport.
10. If a control-plane response is lost after possible mutation, inspect consequence-bearing local state before rerunning anything. After the first transport-size/timeout/truncation/response-loss failure on deterministic batch work, substantially repeating the same bridge-heavy architecture without rerouting is presumptively a process error.

## Truth-state grammar
- `VERIFIED` — directly earned by an appropriate verification path.
- `OBSERVED` — present in evidence without a stronger mechanistic interpretation.
- `INFERRED` — structural interpretation supported by evidence but not directly established.
- `HYPOTHESIZED` — candidate explanation requiring discrimination.
- `INTUITION_SIGNAL` — researcher/operator-origin clue worth preserving without promotion.
- `UNKNOWN` — unresolved and not lawfully collapsible.
- `REJECTED_DEMOTED` — previously live interpretation defeated, narrowed, or superseded.

## State / authority grammar
- `RAW -> SEED -> CANDIDATE -> WORKING -> LOAD_BEARING -> CANON`
- Demotion: `QUESTIONED -> LOCAL_ONLY -> DEPRECATED -> TOMBSTONED`
- `CANON != FINAL`
- `CONTINUITY != PROOF`
- `REMEMBERED_POINTER != CURRENT_STATE_EVIDENCE`
- `PROJECT_LOCAL_OBLIGATION != UNIVERSAL_SOP_LAW`

## Cold-start order
Read `01` through `13` in order. Load project-local state only after the universal authority/continuity rules are understood. Use `12_COLD_START_PROTOCOL.md` as the ingress checklist.

`AUTOMATED_CHECKS != LINEAR_SEMANTIC_READ`
`CONTROL_PLANE_RESPONSE_FAILURE != LOCAL_EXECUTION_FAILURE`
`CONTROL_PLANE_MINIMIZATION != SEMANTIC_READ_SKIPPING`
`DO_THE_WORK_WHERE_THE_STATE_LIVES`


## Execution-plane default
For consequence-bearing work, prefer the strongest available operator-side/local/server plane. Assistant/model-side execution is an explicit exception when materially better or faster for the specific step; convenience alone is insufficient.

Under degraded conditions use the plane-order and resumability rules in `06A_SERVER_EXECUTION_METHODOLOGY_FOR_UNRELIABLE_PLANES.md`.

`STRONGEST_SURVIVING_PLANE != PRETTIEST_PLANE`
`OPERATOR_SIDE_DEFAULT != ASSISTANT_SIDE_PROHIBITED`
`ASSISTANT_SIDE_CONVENIENCE != MATERIAL_ADVANTAGE`
`EXECUTION_PLANE_FALLBACK != AUTHORITY_BYPASS`


## Interface, re-entry, and global scar additions
- Read `03A_COLLABORATION_WRITING_AND_TEACHING_INTERFACE.md` when technical collaboration, explanation, public-facing writing, or instructional coding matters.
- Read `11A_GLOBAL_CROSS_PROJECT_SCAR_LEDGER_PROTOCOL.md` before treating cross-project scars as reusable design pressure.
- Read `12A_REENTRY_CONTEXT_AND_HISTORICAL_RECONSTRUCTION_PROTOCOL.md` for imported context packages, archaeology, historical reconstruction, and verify-first re-entry.

Preferred explanation order: **mechanism -> example -> technical name -> application**.

`PLAIN_LANGUAGE != LOW_RESOLUTION_MODEL`
`SCAR_AGGREGATION != SCAR_AUTHORITY_PROMOTION`
`CROSS_PROJECT_COPY != INDEPENDENT_REDERIVATION`
`CONTINUITY_MAP != CURRENT_STATE_EVIDENCE`
`RESEARCH_PROGRESSION != CANONICAL_PROMOTION`


## R4.4 enforcement synthesis
R4.4 preserves R4.3's interface/re-entry/global-scar corrections and adds enforcement mechanisms learned from an independent sibling R4.3 candidate. The sibling remains evidence/donor, not ancestry authority. This R4.4 release is canonical only because its promotion mutation, semantic-read gate, verifier, hostile qualification, and deterministic seal are completed as a separate authority transition.

`GATE_ASSERTED != GATE_WITNESSED`
`GUARD_PRESENT != GUARD_EXERCISED`
`PROTECTED_STRING_INTACT != MEANING_INTACT`
`SEALED_BYTES != PUBLISHED_BYTES`
`SEALING_EXEMPTION != PUBLICATION_EXEMPTION`
`SIBLING_DONOR != CANONICAL_PARENT`
