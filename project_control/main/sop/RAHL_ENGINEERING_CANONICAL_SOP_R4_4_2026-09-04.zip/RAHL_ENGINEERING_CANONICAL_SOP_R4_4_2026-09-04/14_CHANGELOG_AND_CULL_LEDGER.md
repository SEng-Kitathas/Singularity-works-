# 14 — R4.4 Convergence / Cull Ledger

## Purpose
This release converges earlier SOP and continuity work into a project-agnostic cold-start surface.






## R4.4 synthesis — canonical R4.3 + independent enforcement sibling
R4.4 synthesizes two different R4.3 payloads without pretending they were one artifact:
- canonical parent R4.3 SHA-256 `cd46c482608f48b1d15ad99acf4eafd07712de6b0efc44dc9e8638b3fdaaf58e` contributes the mechanism-first interface, re-entry/historical reconstruction protocol, Global Cross-Project Scar Ledger protocol, operator-side execution methodology, and already-promoted R4.3 process surface;
- sibling donor R4.3 SHA-256 `7d72e57dc2021af20753a942f87da38bf8ad31fbb89a6bd21145bd8e263d8552` contributes stronger enforcement patterns discovered by independent audit.

Adopted donor mechanisms:
1. host-path/operator-identity guards match real representations and self-test with positive/negative controls;
2. active-surface heading inventory plus anti-binding scan provide structurally different witnesses beyond a binding table;
3. semantic-read ledger verifies reuse against the sealed canonical parent's own manifest and interlocks promotion while unread members remain;
4. publication reconciliation distinguishes sealed bytes from normalized publication bytes and provides a `.gitattributes` fragment where exact bytes matter;
5. additive hostile attacks are first-class and leave protected strings intact.

Identifier collision resolution: canonical R4.3 already used C27–C30 and E23–E24 for different laws. Donor C27–C29/E23–E24 are preserved as R4.4 C31–C33/E25–E26 rather than overwriting either meaning.

Residuals retained honestly: heading inventory and anti-binding scans remain same-author verifier witnesses rather than independent verification; phrase-based anti-binding cannot enumerate every semantic reversal; semantic ledger attestation is not comprehension; host identity guards remain an enumeration; publication reconciliation makes residuals visible rather than making publication identical to the seal.

`SIBLING_DONOR != CANONICAL_PARENT`
`GATE_ASSERTED != GATE_WITNESSED`
`PROTECTED_STRING_INTACT != MEANING_INTACT`

## R4.3 correction — interface laws, re-entry reconstruction, and global scars
R4.3 corrects an overbroad cull in R4.2. R4.2 classified person-specific communication/teaching/vocabulary/coding-language preferences as non-universal; that bucket incorrectly removed several **transferable interface mechanisms** along with truly personal preferences.

R4.3 restores and universalizes:
- explanation order `mechanism -> example -> technical name -> application`;
- plain practical language around mechanisms while preserving real technical vocabulary;
- roughly "1991-ish" general vocabulary as the public-facing research-writing default, without removing proper technical terms;
- `mechanism first -> precision second -> style third`;
- explicit uncertainty and competing interpretations;
- the prohibition against dumbing down the model of reality;
- context-first translation;
- coherent single-author voice for outward-facing multi-model artifacts;
- instructional cycle `prediction -> execution -> mechanism -> modification`;
- mistakes as diagnostic evidence and independent reasoning as the teaching goal;
- Python as the preferred first teaching substrate only when language is otherwise unconstrained and compatible with the task.

Still project/user-local rather than universal:
- personal address/title preferences;
- individual humor/profanity/idiolect preferences;
- collaborator/contact history;
- arbitrary naming preferences;
- project-mandated implementation languages.

R4.3 also universalizes the durable parts of long-horizon context packages: continuity-map adoption, canonical/experimental/donor/history distinctions, historical reconstruction classes, no invented missing history, canonical-vs-research separation, local-vs-remote currentness, runtime ownership, permission currentness, and source-contact requirements. Named projects, stale paths/hashes/ports/commits/campaign positions, personal biography, and current project status remain outside universal SOP.

Finally, R4.3 adds the Global Cross-Project Scar Ledger protocol. The large mutable scar corpus remains server/project state; the sealed SOP carries only the protocol, machine contract, and promoted universal active scar index.

`PERSONAL_STYLE_PREFERENCE != UNIVERSAL_INTERFACE_LAW`
`SCAR_AGGREGATION != SCAR_AUTHORITY_PROMOTION`
`CROSS_PROJECT_COPY != INDEPENDENT_REDERIVATION`
`RECURRENCE != UNIVERSALITY`

## R4.2 integration — semantic admission + durable local execution
R4.2 incorporates two previously additive governing doctrines directly into the canonical SOP surface rather than requiring external overlays:

1. **Linear Human Read / Semantic Gate** — meaningfully readable artifacts require complete linear semantic reading before promotion, sealing, publication, admission, or load-bearing use; automated checks support but do not substitute; exact-hash receipts may be reused only while bytes and governing scope remain unchanged.
2. **Durable Local Execution / Control-Plane Minimization** — substantial finite deterministic work belongs on the local/server work plane wherever practical, with durable evidence and compact control-plane receipts; response loss triggers local readback before retry; after the first deterministic transport failure, repeating the same bridge-heavy architecture without rerouting is presumptively a process error.

The execution scar is preserved canonically as: **DO THE WORK WHERE THE STATE LIVES; RETURN ONLY THE EVIDENCE NEEDED TO CONTROL IT.**

R4.1 remains exact ancestry. The standalone addenda remain project-history evidence but no longer need to carry active authority once R4.2 is promoted.

## R4.1 correction — base-tier engineering metabolism
R4.1 corrects an authority/interpretation drift introduced in R4.0.

R4.0 preserved PDVER / OARR / Loop+ / Semantic Helix / CSC / Attention Reservoir as optional named machinery and stated that they should be used only when a named instrument earned a causal job. Operator authority clarified that the **underlying functions were always intended as the default base-tier approach for nontrivial work**, paired with hostile engineering and additive AI co-processing.

R4.1 therefore:
- makes the combined functional metabolism a standing obligation for nontrivial work;
- keeps the machinery non-linear and proportionate rather than ceremonial;
- fixes PDVER ordering to `PROBE -> DERIVE -> VERIFY -> EMBODY -> RECURSE`;
- keeps post-embodiment readback/attack active rather than treating pre-embodiment verification as sufficient;
- removes the universal fixed 20-pass research-campaign default in favor of a justified bounded campaign;
- distinguishes base-tier functional obligations from disposable historical tool/ritual embodiments;
- strengthens hostile mutation tests so semantic mutations are re-manifested before verification, forcing rejection on semantic guards rather than trivial byte drift;
- hardens package self-verification so manifest package identity/schema and required canonical document/fixed-member presence are enforced independently of the manifest's own membership declaration; adds hostile deletion+remanifest and manifest-identity-drift cases;
- adds explicit AI co-processor obligations without granting model output truth authority;
- preserves exact R4.0 and R3.1 ancestry.

`BASE_TIER_FUNCTIONAL_OBLIGATIONS != MANDATORY_LINEAR_PIPELINE`
`PROCESS_IMPLEMENTATION_CAN_BE_RETIRED != PROCESS_FUNCTION_CAN_BE_SILENTLY_DROPPED`

## Preserved and generalized
- reality/evidence precedence;
- authority classes and conflict resolution;
- uniform donor intake / strip-for-parts;
- composition-first before new primitives;
- bounded discriminator-led hostile campaigns;
- base-tier research functions with proportionate/non-linear named machinery, and optional mode/role labels without naming-based authority;
- execution/readback/release discipline;
- environment/reproduction identity contracts;
- UNKNOWN/trace/ask rule;
- Live Shadow + Design Thread Stream;
- Research Epistemic Shadow (RES);
- doctrine/trace/revisit/next-step separation;
- append-oriented promotion/demotion history;
- fresh-evaluator isolation when blinding matters.

## Deliberately culled from active universal SOP
The following classes belong in project/user-specific state and SHALL NOT be baked into a universal cold-start package:
- personal biography or long-horizon project narrative;
- named active projects/repositories and their current authority states;
- exact filesystem paths, endpoints, ports, process/job IDs, commits, tags, hashes, campaign positions, machine profiles, or runtime allocations except package ancestry/evidence identity required to verify this release;
- project-specific Commander/governing intent;
- remembered campaign results and code-level scars that apply only to one project;
- collaborator/contact history;
- person-specific address, humor/idiolect, collaborator-specific presentation, arbitrary naming, or project-mandated language preferences; transferable explanation/teaching mechanisms are retained under `03A`;
- fixed archive part-size limits tied to one transport environment.

These are not declared false or unimportant. They are **out of universal SOP scope** and belong in project contracts, continuity, RES, substrate profiles, or user-preference surfaces.

## Major R4.0 additions retained
- RES as third core shadow: `Live Shadow = now`, `Design Thread Stream = chronology`, `RES = learned meaning/frontier`.
- explicit continuity hardening H01–H13;
- artifact-class-relative environment identity discipline;
- exact-vs-normalized reproduction assurance separation;
- ecological vs controlled-causal claim separation;
- identifying vs developmental evaluation distinction;
- observation-time subject binding;
- negative-history preservation without fossilization.


## R4.2 integration — unreliable-plane execution methodology
R4.2 also incorporates the project-agnostic **Server Execution Methodology for Unreliable Planes** as active SOP surface `06A`.

Preserved universally:
- strongest surviving plane over prettiest plane;
- operator-side/local/server execution default when available and sufficient;
- assistant/model-side execution only when materially better or faster for the specific step;
- explicit degraded-plane order: server-native project execution -> direct server-side subprocess/Python -> durable local script -> ad hoc bridge/chat;
- durable scripts for consequential runs;
- incremental/resumable long operations where semantics permit;
- machine execution truth over conversational/transport appearance;
- inference/benchmark durability rules;
- provenance discipline for cross-environment tooling imports;
- bounded smoke runs before widening unstable workflows;
- explicit boundary that execution-plane fallback does not bypass safety, approval, access-control, or authority.

Culled as non-universal:
- dated alignment timestamps;
- named-lab/project adoption notes;
- statements whose only job was to describe one project's current activation state.
