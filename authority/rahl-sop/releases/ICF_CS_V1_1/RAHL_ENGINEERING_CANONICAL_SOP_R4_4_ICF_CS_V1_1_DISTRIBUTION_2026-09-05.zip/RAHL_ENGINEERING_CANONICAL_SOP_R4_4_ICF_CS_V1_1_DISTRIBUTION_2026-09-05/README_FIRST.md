# ICF-CS v1.1 Distribution Bundle

This bundle carries two authority-relevant objects that must stay distinct:

1. `RAHL_ENGINEERING_CANONICAL_SOP_R4_4_ICF_CS_V1_1_ADDENDUM_2026-09-05.zip` — the internally qualified ICF-CS v1.1 additive payload. It does not activate itself.
2. `ICF_CS_V1_1_DETACHED_RELEASE_RECEIPT_2026-09-05.json` — detached release evidence produced outside the payload after deterministic seal, CRC, and clean-extraction replay.

Run `VERIFY_DISTRIBUTION.py` from this directory to verify the payload/receipt binding.

`SELF_VERIFYING_PACKAGE != VERIFIED_PACKAGE`
`DETACHED_WITNESS != INDEPENDENT_AUTHORSHIP`
`DISTRIBUTION_BUNDLE != PAYLOAD_AUTHORITY`

R4.4 remains the exact sealed canonical base embedded inside the payload. ICF-CS v1.0 is demoted historical evidence. ICF-CS v1.1 is active binding additive doctrine only when this detached receipt matches the exact payload bytes.
