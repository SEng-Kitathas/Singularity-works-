from pathlib import Path
import hashlib,json,sys,zipfile
ROOT=Path(__file__).resolve().parent
PAYLOAD='RAHL_ENGINEERING_CANONICAL_SOP_R4_4_ICF_CS_V1_1_ADDENDUM_2026-09-05.zip'
RECEIPT='ICF_CS_V1_1_DETACHED_RELEASE_RECEIPT_2026-09-05.json'
EXPECTED_PAYLOAD_SHA='f6f4ab2bafdb0ef2a7db1622a00462990baf980284d5b33827807caea1d41f63'
BASE_SHA='04f3e94efe8c901cc83a12a9c8531be8a9bb350728b8f9eba53db0fd082b3bbc'
EXPECTED_HOSTILE_COUNT=35
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(m):print("FAIL:",m);raise SystemExit(2)
rp=ROOT/RECEIPT;pp=ROOT/PAYLOAD
if not rp.exists() or not pp.exists():fail("distribution missing payload or receipt")
r=json.loads(rp.read_text(encoding="utf-8"))
if sha(pp)!=EXPECTED_PAYLOAD_SHA or r.get("payload_zip_sha256")!=EXPECTED_PAYLOAD_SHA:fail("payload hash mismatch")
if r.get("canonical_base_sha256")!=BASE_SHA:fail("base hash mismatch")
if r.get("decision")!="ACTIVE_BINDING_ADDITIVE_DOCTRINE":fail("receipt decision not active")
if r.get("hostile_suite",{}).get("cases")!=EXPECTED_HOSTILE_COUNT or r.get("hostile_suite",{}).get("unexpected_passes")!=0:fail("hostile receipt mismatch")
if r.get("distribution_verifier_sha256")!=sha(Path(__file__)):fail("distribution verifier hash mismatch")
with zipfile.ZipFile(pp) as z:
 if z.testzip() is not None:fail("payload CRC failure")
print("PASS: detached receipt matches exact ICF-CS v1.1 payload; release decision ACTIVE_BINDING_ADDITIVE_DOCTRINE")
