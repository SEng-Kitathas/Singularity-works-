#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,sys,os
R=Path(__file__).resolve().parent
BASE='04f3e94efe8c901cc83a12a9c8531be8a9bb350728b8f9eba53db0fd082b3bbc';ICF='62be845da364ae81f59b6320c9b34b136236bf5be8aa8036018da48efcb754f4';QUAL='8b7164d1303e15bba1a31e7790e9dd4e76338f8bf07c215f72ad3dee17efe0b5';PROMO='a4be78a7de9dd3225db68bd97dda2b027f274e7ef7eecf747ae8cbdf58795780';INV='4f06428c7b57d8f134d2cf9750a80655f11bb9bcdec869445a2542dd45b8f0e9'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(m):print('FAIL:',m);raise SystemExit(2)
m=json.loads((R/'MANIFEST_SHA256.json').read_text());l=json.loads((R/'SEMANTIC_READ_LEDGER.json').read_text())
if m.get('package_id')!=R.name or m.get('canonical_base_sha256')!=BASE or m.get('icf_cs_v1_1_standard_sha256')!=ICF:fail('package/parent drift')
expected=set(m['files']);actual={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json'}
if expected!=actual:fail('membership mismatch')
for rel,e in m['files'].items():
 p=R/rel
 if p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']:fail('hash drift '+rel)
if l.get('state')!='SEMANTICALLY_ADMITTED':fail('semantic ledger state')
for rel,e in l['entries'].items():
 p=R/rel
 if e.get('disposition')!='FRESH_READ_COMPLETED' or e.get('sha256')!=sha(p):fail('semantic ledger drift '+rel)
rd=json.loads((R/'release/GOVERNANCE_CONTACT_RELEASE_DESCRIPTOR.json').read_text());inv=json.loads((R/'release/TARGET_INVENTORY_V1.json').read_text())
readme=(R/'00_READ_ME_FIRST.md').read_text(encoding='utf-8');std=(R/'GOVERNANCE_CONTACT_STANDARD.md').read_text(encoding='utf-8');ce=(R/'CLAIM_CEILING.md').read_text(encoding='utf-8');promo=(R/'lineage/PROMOTION_DECISION.md').read_text(encoding='utf-8');life=(R/'release/SOP_SELF_APPLICATION_RELEASE_LIFECYCLE_GATE.md').read_text(encoding='utf-8')
if 'State: `PACKAGE_QUALIFIED_PENDING_DETACHED_RELEASE`' not in readme or 'Authority effect: `NONE_PENDING_RELEASE_LIFECYCLE`' not in readme:fail('readme release-state ceiling')
if rd.get('release_state')!='PACKAGE_QUALIFIED_PENDING_DETACHED_RELEASE' or rd.get('authority_effect')!='NONE_PENDING_RELEASE_LIFECYCLE':fail('descriptor release-state ceiling')
for law in ['GOVERNANCE_BELONGS_BESIDE_DATA_NOT_INSIDE_DATA','CONTACT_RECEIPT_VALID != SOURCE_UNCHANGED_SINCE_CONTACT','LOCAL_FILE_CONTACT_REQUIRES_COMMIT_REHASH','PROMOTED_PENDING_RELEASE_LIFECYCLE != ACTIVE']:
 if law not in std:fail('release standard law missing '+law)
for law in ['SIDECAR != TRUTH','LOCATOR != AUTHORITY','CONTACT_SET_SATISFIED != AUTHORITY_GRANTED','POST_PUBLICATION_READBACK != ACTIVE']:
 if law not in ce:fail('release claim ceiling missing '+law)
if 'Decision state: `PROMOTION_DECISION_RECORDED_PENDING_RELEASE_LIFECYCLE`' not in promo or 'Authority effect now: `NONE_PENDING_RELEASE_LIFECYCLE`' not in promo:fail('promotion decision ceiling')
for state in ['DRAFTED','SEMANTICALLY_ADMITTED','PACKAGE_QUALIFIED','DETACHED_RELEASED','TARGET_PUBLISHED','REPOSITORY_ADMITTED','LOCAL_AUTHORITY_RECONCILED','POST_PUBLICATION_READBACK','ACTIVE']:
 if state not in life:fail('lifecycle state missing '+state)
if inv.get('target_count')!=17 or inv.get('inventory_state')!='FROZEN_PRE_DETACHED_RELEASE':fail('target inventory')
ids=[x.get('id') for x in inv.get('targets',[])]
if len(ids)!=17 or len(set(ids))!=17:fail('target identity cardinality')
if sha(R/'release/TARGET_INVENTORY_V1.json')!=INV or rd.get('target_inventory_sha256')!=INV:fail('frozen target inventory binding')
if sha(R/'lineage/PROMOTION_DECISION.md')!=PROMO or rd.get('promotion_decision_sha256')!=PROMO:fail('promotion decision exact binding')
if sha(R/'lineage/QUALIFICATION_RECEIPT_V2.json')!=QUAL or rd['qualified_candidate']['qualification_sha256']!=QUAL:fail('qualification receipt exact binding')
q=json.loads((R/'lineage/QUALIFICATION_RECEIPT_V2.json').read_text(encoding='utf-8'))
if q.get('state')!='QUALIFIED_CANDIDATE_NOT_BINDING' or q.get('authority_effect')!='NONE':fail('qualification receipt state/authority ceiling')
qm=q.get('candidate_members',{})
exact_candidate={'state/doctrine_snapshot/GOVERNANCE_SIDECAR_AND_CONTACT_GATE_CANDIDATE.md':'state/doctrine_snapshot/GOVERNANCE_SIDECAR_AND_CONTACT_GATE_CANDIDATE.md','machine/GOVERNANCE_CONTACT_SIDECAR_CONTRACT.json':'machine/GOVERNANCE_CONTACT_SIDECAR_CONTRACT.json','tools/governance_contact_resolver.py':'tools/governance_contact_resolver.py','tools/verify_governance_contact_candidate.py':'tools/verify_governance_contact_candidate.py','tools/test_governance_contact_resolver_hostile.py':'tools/test_governance_contact_resolver_hostile.py'}
for qkey,rel in exact_candidate.items():
 if qm.get(qkey)!=sha(R/rel):fail('qualified candidate exact-byte lineage drift '+rel)
if sha(R/'state/doctrine_snapshot/GOVERNANCE_SIDECAR_AND_CONTACT_GATE_CANDIDATE.md')!=rd['qualified_candidate']['candidate_sha256']:fail('candidate prose descriptor drift')
if sha(R/'machine/GOVERNANCE_CONTACT_SIDECAR_CONTRACT.json')!=rd['qualified_candidate']['contract_sha256']:fail('candidate contract descriptor drift')
env=os.environ.copy();env['PYTHONDWRITEBYTECODE']='1'
for script,witness in [('tools/verify_governance_contact_candidate.py','CANDIDATE_STRUCTURAL_VERIFICATION_PASS'),('tools/test_governance_contact_resolver_hostile.py','hostile_rejected')]:
 cp=subprocess.run([sys.executable,str(R/script)],cwd=R,capture_output=True,text=True,timeout=120,env=env)
 if cp.returncode!=0 or witness not in cp.stdout:fail('embedded replay '+script+' '+(cp.stdout+cp.stderr)[-1200:])
print('PASS: GOVERNANCE_CONTACT_RELEASE_PACKAGE_QUALIFIED_INTERNAL')
