# Governance Sidecars + Required Contact Gate — Candidate

Date: 2026-09-06
Status: `CANDIDATE_NOT_BINDING`
Authority effect: `NONE`
Privileged-core effect: `NONE` — this candidate composes existing authority/scope, currentness/continuity, admission/LHRSG, provenance/lineage, and mutation-lifecycle functions. It does not add a ninth privileged-core function.

## Problem
R4.4 already contains strong doctrine for authority classes, source contact, re-entry, scars, semantic admission, currentness, recovery, and project obligations. The server already holds a large cross-project scar registry and many project-local Commander’s Intent / invariant / doctrine / continuity surfaces.

The remaining failure is operational:

`KNOWLEDGE_AGGREGATED != KNOWLEDGE_CONTACTED`
`FILE_EXISTS + ACKNOWLEDGED != GOVERNANCE`
`CONTINUITY_SURFACE_VALID != CURRENT_TASK_CONTACT_COMPLETE`

An agent can possess, locate, or acknowledge governance information without actually contacting the subset that is load-bearing for the consequence it is about to create.

## Core architectural decision
**Governance belongs beside data, not inside data.**

Source artifacts, observations, historical records, donor material, code, experiment outputs, and other payloads remain faithful to their own role. Separately versioned governance sidecars describe how those payloads may presently be located, interpreted, composed, constrained, admitted, or used.

`DATA != GOVERNANCE`
`CORPUS_CONTENT != AUTHORITY`
`GOVERNANCE_BELONGS_BESIDE_DATA_NOT_INSIDE_DATA`
`SUPERSESSION_UPDATES_GOVERNANCE_NOT_HISTORY`

A sidecar may point at Markdown, code, a Git blob, an archive member, a remote endpoint, a runtime process, or another sidecar. The sidecar does not make the subject true or current merely by referring to it.

## Locality model
The design SHALL prefer:

`LOCALLY_ENUMERABLE + LOCATABLE != GLOBALLY_COMPREHENDED`

A project or subsystem should expose machine-enumerable governance facts where they live and enough locator information for another plane to find them when consequence requires contact.

This does **not** require a globally centralized registry, a single global manager, or preloading all doctrine/history into model context.

`LOCATABLE != PRELOADED`
`LOCATABLE != CENTRALLY_INDEXED`
`GLOBAL_REACHABILITY != GLOBAL_COMPREHENSION`
`NOT_IN_WORKING_SET != UNLOCATABLE`

## Sidecar role
A governance sidecar is a separately versioned control record associated with a subject. A sidecar SHOULD be able to state:
- sidecar identity and schema;
- governed subject locator and optional exact subject identity;
- project/scope;
- authority class and authority source locator;
- currentness state and currentness basis;
- supersession/predecessor lineage;
- constraints / claim ceiling;
- mechanism/failure-topology tags;
- task/consequence selectors that require contact;
- provenance / evidence locators;
- explicit exceptions or unresolved state.

Sidecars are control metadata, not truth or semantic comprehension.

`SIDECAR != TRUTH`
`SIDECAR_PRESENT != SIDECAR_CURRENT`
`SIDECAR_AUTHORIZES_USE != PAYLOAD_CLAIM_TRUE`
`LOCATOR != AUTHORITY`
`LOCATOR != CURRENTNESS`

## Task contact resolution
Before consequential action, a resolver receives a bounded task description:
- project/scope;
- mutation class;
- consequence classes;
- touched paths or subject locators;
- mechanism/failure-topology tags;
- optional requested capabilities.

The resolver matches applicable sidecars and contact rules to derive a **Required Contact Set**.

The resolver SHALL NOT treat the contact set as a complete model of the world. It is the minimum known governance surface required by the current consequence description.

A project-local **orientation profile** SHALL define mandatory governance coverage for relevant task classes so the catalog cannot silently define its own completeness by omission. The profile may pin exact project-local sidecar identities (for example the current Commander’s Intent sidecar) and/or require an authority class (for example a topology-matched scar). A required class only counts as covered when an eligible sidecar actually contributes a contact to the derived set.

`CATALOG_CONTENT != CATALOG_COMPLETENESS`
`ORIENTATION_PROFILE_PRESENT != ORIENTATION_PROFILE_CURRENT`
`REQUIRED_CLASS_PRESENT != REQUIRED_CLASS_CONTACTED`
`CONTACT_SET_HASH_VALID != CONTACT_SET_COMPLETE`
`CONTACT_SET_DERIVED != COMPLETE_WORLD_MODEL`
`TASK_SCOPE_EXPANDED -> CONTACT_SET_REDERIVE`

A contact set entry binds at least:
- contact identity;
- source/subject locator;
- expected identity when known;
- reason for contact;
- semantic extent required (`FULL_ARTIFACT`, `BOUNDED_SEMANTIC_SECTION`, `MACHINE_READBACK`, or explicit non-semantic integrity mode);
- currentness requirement;
- authority class;
- originating sidecar/rule.

## Contact evidence
`LOCATED` is not enough.
`HASHED` is not enough.
`ACKNOWLEDGED` is not enough.

Readable load-bearing governance artifacts requiring full semantic contact SHALL receive complete semantic contact on the exact bytes bound by the contact set or a lawfully reusable exact-byte/same-scope receipt.

Machine/runtime state uses an appropriate readback receipt rather than pretending logs/process tables are human prose.

Every contact receipt SHALL bind:
- contact-set identity;
- contact identity;
- exact observed identity/hash when applicable;
- semantic/readback extent;
- attester/read path;
- governing task scope;
- currentness basis/readback;
- timestamp;
- non-empty note.

`CONTACT_RECEIPT != COMPREHENSION`
`CONTACT_RECEIPT != MUTATION_AUTHORIZATION`
`HASH_MATCH != SEMANTIC_CURRENTNESS`

## Admission / authorization
The gate may return `CONTACT_SET_SATISFIED` only when every mandatory entry has a valid, scope-matching, current receipt.

The gate does not itself grant domain truth or mutation authority. It is an admission precondition that a higher mutation lifecycle may require.

`CONTACT_SET_SATISFIED != AUTHORITY_GRANTED`
`CONTACT_GATE != NEW_AUTHORITY_SYSTEM`

If any required contact is missing, stale, wrong-scope, wrong-hash, superseded, contradictory, or unresolved, the result SHALL be fail-closed or route to AUDIT/RECOVERY according to the governing project rules.

## Currentness and race handling
A contact receipt is bound to the observed bytes/currentness basis. If the governing sidecar, subject identity, Commander’s Intent, constraint surface, or relevant currentness frontier changes before commit, the contact set must be re-derived/re-admitted as applicable.

`CONTACT_FRESH_AT_PREFLIGHT != CONTACT_FRESH_AT_COMMIT`
`CONTACT_RECEIPT_VALID != SOURCE_UNCHANGED_SINCE_CONTACT`

Each contact SHALL declare a commit recheck mode. `LOCAL_FILE_SHA256` means admission must resolve the locator as a local file and re-hash the current bytes immediately before satisfaction; missing bytes or hash drift reject the contact even when the earlier receipt and contact-set digest are internally valid. `RECEIPT_BOUND_EXTERNAL` is permitted only when the source is not locally re-readable at admission; it carries an explicit ceiling that the local gate did not independently reverify the external source after the receipt was produced.

`LOCAL_FILE_CONTACT_REQUIRES_COMMIT_REHASH`
`RECEIPT_BOUND_EXTERNAL != LOCAL_COMMIT_RECHECK`

No contact token may survive a scope expansion that would introduce additional mandatory sidecars.

## Scar composition
Scar matching SHOULD prefer mechanism/failure topology over project noun when the source evidence supports the transfer.

Examples of topology tags:
- `DERIVED_PROJECTION_FROM_APPEND_HISTORY`;
- `SEQUENCE_AUTHORITY`;
- `CURRENTNESS_GUARD`;
- `READBACK_PLANE`;
- `RUNTIME_OWNERSHIP`;
- `REJECTED_MECHANISM_RESURRECTION`;
- `NORMALIZATION_OR_SERIALIZATION_IDENTITY`.

This allows a Microseed, Receiver, NEXUS, HSP, Forge, or continuity failure to become locatable when the same mechanism topology reappears without pretending those projects share ontology.

`SCAR_MATCH_BY_TOPOLOGY != SCAR_AUTHORITY_PROMOTION`
`RECURRENCE != UNIVERSALITY`

## Historical intent
Historical Commander’s Intent and doctrine bytes SHALL remain historical source bytes. Currentness and supersession are represented by sidecar lineage/pointers rather than retroactive source rewriting.

`HISTORY_REMAINS_HISTORY`
`SUPERSESSION != SOURCE_REWRITE`
`LATEST_FILENAME != CURRENT_AUTHORITY`

An archaeology task may intentionally traverse predecessor intent. A current engineering task resolves the governing intent through project-local authority/currentness sidecars.

## Orientation handshake
An arriving agent should be able to ask the environment, mechanically:
- where am I / what plane is this;
- what projects/scopes are exposed;
- what capabilities exist;
- what authority is currently held;
- what governance locators are relevant;
- what contacts are required for the requested task;
- what remains unknown or unresolved.

`ENDPOINT_CONNECTED != ENVIRONMENT_UNDERSTOOD`
`CAPABILITY_VISIBLE != CAPABILITY_AUTHORIZED`

The orientation result is navigation/control metadata, not global comprehension.

## Hostile requirements
Qualification SHALL attack at least:
- governance artifact exists but is not contacted;
- fake `ACKNOWLEDGED` receipt;
- wrong artifact hash;
- wrong task scope;
- stale/superseded sidecar;
- currentness basis missing;
- Commander’s Intent omitted despite applicable rule;
- relevant scar omitted despite matching topology;
- historical copy substituted for current authority;
- scope expands after contact without re-resolution;
- duplicate exact-copy scars miscounted as independent recurrence;
- sidecar forged to claim authority it does not possess;
- contact-set self-deletion or optionalization;
- archive member `LOCATED` misrepresented as `READ`;
- global preload accepted as substitute for required bounded contact;
- unresolved contradictory current sidecars silently resolved.

## Claim ceiling
This candidate does not prove that every relevant governance surface has been located, every sidecar is current, semantic comprehension occurred, sidecars are tamper-proof, or all action paths are mediated.

Current disk locator audits are research/quarry evidence. They do not become authority merely by being indexed.

`GOVERNANCE_SURFACE_LOCATOR != GOVERNANCE_AUTHORITY`
`GOVERNANCE_LOCATOR_COMPLETE != WORLD_COMPLETE`
`GUARD_PRESENT != MUTATION_PATH_GUARDED`

Promotion requires real task use where the gate catches/prevents a consequence-bearing contact omission, hostile qualification, full semantic read of final readable candidate bytes, and explicit lineage decision. Until then: `CANDIDATE_NOT_BINDING`.
