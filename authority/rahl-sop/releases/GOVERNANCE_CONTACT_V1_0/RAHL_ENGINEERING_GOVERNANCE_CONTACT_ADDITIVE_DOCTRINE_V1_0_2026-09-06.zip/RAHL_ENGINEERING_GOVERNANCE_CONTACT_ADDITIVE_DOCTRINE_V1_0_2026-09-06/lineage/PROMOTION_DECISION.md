# Governance Sidecars + Required Contact Gate — Additive Doctrine Promotion Decision

Date: 2026-09-06
Decision state: `PROMOTION_DECISION_RECORDED_PENDING_RELEASE_LIFECYCLE`
Authority effect now: `NONE_PENDING_RELEASE_LIFECYCLE`

## Decision
The qualified Governance Sidecars + Required Contact Gate successor SHALL enter the Rahl Engineering SOP lineage as a **separately versioned additive doctrine successor** above the unchanged authority stack:

1. exact sealed R4.4 canonical base;
2. receipt-qualified ICF-CS v1.1 additive process doctrine;
3. Governance Sidecars + Required Contact Gate additive doctrine successor, **pending its own release lifecycle**.

R4.4 SHALL NOT be rewritten or renamed as R4.5 merely to absorb this mechanism. ICF-CS v1.1 SHALL NOT be rewritten.

This decision records lineage intent and promotion routing. It does **not** make the new doctrine ACTIVE.

`QUALIFIED_CANDIDATE != BINDING_DOCTRINE`
`PROMOTION_DECISION != ACTIVE_RELEASE`
`SOP_DOCTRINE != SOP_RELEASE_PROCESS`

## Qualified successor identity
- prose: `state/doctrine_snapshot/GOVERNANCE_SIDECAR_AND_CONTACT_GATE_CANDIDATE.md`
  - SHA-256 `ec560334ade98f448d776f9930477ce866eb24718c32fa39722514b1f95e8578`
- machine contract: `machine/GOVERNANCE_CONTACT_SIDECAR_CONTRACT.json`
  - SHA-256 `4c1f48ce4ec54a129d3da354a93e753792b24fa828eadbd6986cf40895d4acad`
- resolver: `tools/governance_contact_resolver.py`
  - SHA-256 `860431c1b88a3ce97bf8bf6b85c6ab7fcfd458d6fe5a2e581c927b1ea15c98e8`
- structural verifier: `tools/verify_governance_contact_candidate.py`
  - SHA-256 `0010f7b7f7eaef4fa2640d4dce193fd4fed120ace805c8d351befa5bf8351e80`
- hostile suite: `tools/test_governance_contact_resolver_hostile.py`
  - SHA-256 `2ec0c396f60b4c9e15ce55c3601ad6b2413f2b2d273706f543121078588e9f11`

Qualification receipt:
`state/verification/governance_contact_candidate/GOVERNANCE_CONTACT_CANDIDATE_QUALIFICATION_RECEIPT_V2_2026-09-06.json`
SHA-256 `8b7164d1303e15bba1a31e7790e9dd4e76338f8bf07c215f72ad3dee17efe0b5`.

Qualification evidence includes:
- structural verification PASS;
- hostile suite `27/27` rejected;
- positive controls `3/3` passed;
- final exact-byte semantic-read ledger SHA `0e93ca26b6cc95c35d8276a16c0e229a9f097966a3672cf4d221fccecb87d56a`;
- real successor omission-prevention receipt SHA `a20658f1f993cc136b8f3127eba86687d3c5e6c961883549cf1b98d589a9dd0a`;
- source-race fix receipt SHA `ae0047b9a0bbb5deeddb6107d83a5c27be917984bd8b5371f7c251b1e1212396`;
- real cross-project composition/recovery receipt SHA `502c00cbf7a3aafd059ff98c0a93ed302bca600db87d270f64d342b69fc7aad4`.

## Promoted doctrine content
The additive successor carries the qualified mechanisms and ceilings, including:

`DATA != GOVERNANCE`
`GOVERNANCE_BELONGS_BESIDE_DATA_NOT_INSIDE_DATA`
`LOCALLY_ENUMERABLE + LOCATABLE != GLOBALLY_COMPREHENDED`
`KNOWLEDGE_AGGREGATED != KNOWLEDGE_CONTACTED`
`FILE_EXISTS + ACKNOWLEDGED != GOVERNANCE`
`CATALOG_CONTENT != CATALOG_COMPLETENESS`
`REQUIRED_CLASS_PRESENT != REQUIRED_CLASS_CONTACTED`
`CONTACT_SET_HASH_VALID != CONTACT_SET_COMPLETE`
`CONTACT_FRESH_AT_PREFLIGHT != CONTACT_FRESH_AT_COMMIT`
`CONTACT_RECEIPT_VALID != SOURCE_UNCHANGED_SINCE_CONTACT`
`LOCAL_FILE_CONTACT_REQUIRES_COMMIT_REHASH`
`SUPERSESSION != SOURCE_REWRITE`
`PROCESS_AUTHORITY_RECONCILIATION != DOMAIN_AUTHORITY_REWRITE`
`CONTACT_SET_SATISFIED != AUTHORITY_GRANTED`
`SIDECAR != TRUTH`
`LOCATOR != AUTHORITY`

## Release lifecycle obligation
The promoted additive doctrine SHALL now be processed under the Self-Application release lifecycle:

`DRAFTED -> SEMANTICALLY_ADMITTED -> PACKAGE_QUALIFIED -> DETACHED_RELEASED -> TARGET_PUBLISHED -> REPOSITORY_ADMITTED -> LOCAL_AUTHORITY_RECONCILED -> POST_PUBLICATION_READBACK -> ACTIVE`

The release must preserve:
- exact candidate/qualification lineage;
- complete semantic admission of changed/new readable release members;
- deterministic package identity;
- detached external release receipt;
- frozen target inventory;
- target-specific publication/admission/readback;
- project-local authority reconciliation;
- explicit exceptions/pins/blockers;
- no silent project-domain authority rewrite.

## Promotion target class
This is universal process/governance doctrine. The initial target inventory SHALL be derived from the same consequence-bearing universal process planes used by the current R4.4 + ICF-CS authority carrier, then re-probed before publication rather than copied by assumption.

`OLD_TARGET_INVENTORY != CURRENT_TARGET_PROOF`
`TARGET_DECLARED != TARGET_ADMITTED`

## Claim ceiling
This promotion decision does not claim:
- that the additive doctrine is ACTIVE;
- that every project orientation profile has already been built;
- that every locator class has commit-time recheck parity with local files;
- that every historical archive member has been read;
- that sidecar metadata is truth;
- that release publication/admission/currentness has already occurred.

Final activation SHALL be delegated to detached lifecycle evidence after all required targets complete the applicable states.
