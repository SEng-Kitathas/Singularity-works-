# SOP Self-Application / Release Lifecycle Gate v1.0

## Purpose
Any SOP/process/doctrine change that becomes load-bearing SHALL be processed under the same control discipline it imposes on downstream work.

`SOP_APPLIES_TO_MAKING_SOP`

## Mandatory release state machine
A release advances only through explicit states:

1. `DRAFTED`
2. `SEMANTICALLY_ADMITTED`
3. `PACKAGE_QUALIFIED`
4. `DETACHED_RELEASED`
5. `TARGET_PUBLISHED`
6. `REPOSITORY_ADMITTED`
7. `LOCAL_AUTHORITY_RECONCILED`
8. `POST_PUBLICATION_READBACK`
9. `ACTIVE`

No later state may be inferred from an earlier state by tone, timestamp, location, or package existence.

## State obligations
### DRAFTED -> SEMANTICALLY_ADMITTED
Every meaningfully readable load-bearing changed/new member receives complete linear semantic read on exact bytes. Automated checks supplement; they do not substitute.

### SEMANTICALLY_ADMITTED -> PACKAGE_QUALIFIED
Manifest, ancestry, exact identity, verifier, meta-verifier where applicable, hostile suite, claim ceiling, and deterministic packaging gates pass.

### PACKAGE_QUALIFIED -> DETACHED_RELEASED
A structurally external release witness pins exact package bytes and qualification evidence. The payload cannot self-activate.

### DETACHED_RELEASED -> TARGET_PUBLISHED
The exact released carrier is copied to every declared required target. Intentional non-targets and explicit local version pins are enumerated, not silently skipped.

### TARGET_PUBLISHED -> REPOSITORY_ADMITTED
Each target repository's own admission rules are run on the post-publication bytes. This includes whole-repo manifests, generated indexes, checksums, CI/workflow gates, branch protection, file normalization policy, and repository-specific validators.

`CARRIER_BYTES_VALID != REPOSITORY_ADMISSION_COMPLETE`
`FILE_PUBLICATION != MANIFEST_RECONCILIATION`

### REPOSITORY_ADMITTED -> LOCAL_AUTHORITY_RECONCILED
Every required project-local currentness/authority surface is classified:
- `MATCHES_RELEASE`
- `EXPLICIT_COMPATIBLE_PIN`
- `REQUIRES_SUPERSESSION`
- `NOT_APPLICABLE`
- `BLOCKED`

A project may retain an explicit local pin, but the pin must be deliberate, current, and recorded. Silent stale authority is a failure.

`OLDER_EXPLICIT_PIN != AUTOMATIC_STALE_DEFECT`
`SILENT_STALE_POINTER != EXPLICIT_PIN`

### LOCAL_AUTHORITY_RECONCILED -> POST_PUBLICATION_READBACK
Read back consequence-bearing target state from the target plane, not the source working copy. Minimum readback:
- remote head/ref or equivalent target identity;
- exact carrier hash/bytes;
- repository admission result;
- current authority pointer status;
- line-ending/normalization policy where text byte identity matters.

`SOURCE_BYTES != TARGET_BYTES_UNLESS_VERIFIED`
`TEXT_SEMANTIC_EQUIVALENCE != BYTE_IDENTITY`
`NORMALIZED_EQUIVALENCE != SEALED_BYTE_IDENTITY`

### POST_PUBLICATION_READBACK -> ACTIVE
A detached lifecycle receipt binds the exact release to a complete target matrix. `ACTIVE` requires:
- zero undeclared required targets;
- zero repository-admission failures;
- zero silent stale local-authority pointers;
- zero unread changed load-bearing release-process surfaces;
- all allowed exceptions explicit and scoped.

## Self-application rule
This gate is not binding merely because it describes the lifecycle. Its own first activation MUST execute the full lifecycle above against itself.

`GATE_ASSERTED != GATE_WITNESSED`
`SELF_APPLICATION_DESCRIBED != SELF_APPLICATION_EXECUTED`

## Release target declaration
Before publication, the release witness SHALL freeze a target inventory. Discovering a new required target after publication reopens the lifecycle from `TARGET_PUBLISHED` for that target; it does not silently preserve ACTIVE.

## Repository-admission probing
Before writing to a target repository, inspect its admission surfaces. At minimum probe:
- `.gitignore` / attributes / line-ending rules;
- root and scoped manifests;
- CI workflows triggered by the planned path;
- repository verification scripts;
- generated indexes/checksum registries;
- branch/default-head and protection constraints when observable.

`PRE_PUBLISH_REPO_PROBE != POST_PUBLISH_REPO_VERIFY`
Both are required when the target has consequence-bearing admission machinery.

## Qualification specimen purity
Verification, compilation, tests, launchers, and readback commands SHALL NOT silently add runtime byproducts to the release specimen. Package manifests SHALL reject transient control/runtime paths such as `__pycache__/`, `.pcmmad_sync_runs/`, `.pytest_cache/`, and VCS metadata. Syntax checks SHOULD use non-materializing parsing or an external temporary output plane.

`QUALIFICATION_SIDE_EFFECT != RELEASE_PAYLOAD`
`VERIFICATION_SUCCESS != PERMISSION_TO_MATERIALIZE_RUNTIME_BYPRODUCTS`

## Currentness propagation
A universal release MAY be active while a project has an explicit compatible local pin, but the release lifecycle cannot represent that project as reconciled unless the local pin is inspected and classified. A project with a silent stale pointer is unreconciled.

## Failure handling
Any failed target gate localizes to that target. Do not weaken the gate to regain green. Repair the target admission/currentness surface, rerun target verification, then update lifecycle receipt.

`CI_FAILURE_AFTER_PUBLICATION != WEAKEN_GATE`

## Closure
Release closure is an evidence object, not prose confidence. The lifecycle receipt must enumerate each target and every state transition actually earned.
