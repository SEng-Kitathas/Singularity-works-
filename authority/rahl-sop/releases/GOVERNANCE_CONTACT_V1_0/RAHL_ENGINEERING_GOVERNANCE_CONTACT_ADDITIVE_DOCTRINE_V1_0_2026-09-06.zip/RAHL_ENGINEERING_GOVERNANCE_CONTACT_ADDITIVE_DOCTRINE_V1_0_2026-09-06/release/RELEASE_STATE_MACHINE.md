# Release State Machine

Allowed monotonic path:
`DRAFTED -> SEMANTICALLY_ADMITTED -> PACKAGE_QUALIFIED -> DETACHED_RELEASED -> TARGET_PUBLISHED -> REPOSITORY_ADMITTED -> LOCAL_AUTHORITY_RECONCILED -> POST_PUBLICATION_READBACK -> ACTIVE`

A target-specific failure may hold the global release at the earliest incomplete required state. Repair resumes from the failed state; earlier exact-byte evidence may be reused only if its governed bytes/scope did not change.

## Forbidden collapses
- semantic read -> active
- package verifier PASS -> published
- git push success -> repository admitted
- repository admitted -> local authority current
- normalized text equality -> byte identity
- carrier presence -> project adoption
- current universal release -> silent override of explicit local project authority

## Global versus target state
The release has one global state and a matrix of target states. Global `ACTIVE` is permitted only when every `REQUIRED_SYNC` target is at `POST_PUBLICATION_READBACK` or later and every `EXPLICIT_PIN` target has a verified pin classification with no false claim that it adopted the release.
