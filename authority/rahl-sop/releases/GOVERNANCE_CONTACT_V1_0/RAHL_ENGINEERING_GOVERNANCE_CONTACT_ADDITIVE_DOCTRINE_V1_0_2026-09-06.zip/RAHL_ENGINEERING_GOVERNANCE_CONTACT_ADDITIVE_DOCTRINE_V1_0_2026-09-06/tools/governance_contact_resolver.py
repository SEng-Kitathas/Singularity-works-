#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, sys, tempfile, contextlib, io

SCHEMA_CATALOG = "rahl.governance-sidecar-catalog.v0-candidate"
SCHEMA_TASK = "rahl.governance-task.v0-candidate"
SCHEMA_CONTACT_SET = "rahl.required-contact-set.v0-candidate"
SCHEMA_RECEIPTS = "rahl.contact-receipts.v0-candidate"
SCHEMA_AUTH = "rahl.contact-admission-result.v0-candidate"
ROOT = Path(__file__).resolve().parents[1]
SEMANTIC_EXTENTS = {"FULL_ARTIFACT", "BOUNDED_SEMANTIC_SECTION", "MACHINE_READBACK", "INTEGRITY_ONLY"}
COMMIT_RECHECK_MODES = {"LOCAL_FILE_SHA256", "RECEIPT_BOUND_EXTERNAL"}
CURRENTNESS = {"CURRENT", "HISTORICAL_SUPERSEDED", "UNKNOWN", "CONTRADICTORY"}


def fail(msg: str, code: int = 2):
    print(json.dumps({"ok": False, "error": msg}, sort_keys=True))
    raise SystemExit(code)


def load(path: str | Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def canonical(obj) -> bytes:
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha_file(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path: str | Path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    os.replace(tmp, p)


def req(obj: dict, fields: list[str], ctx: str):
    for f in fields:
        if f not in obj:
            fail(f"{ctx}: missing required field {f}")


def string_list(v, ctx: str) -> list[str]:
    if v is None:
        return []
    if not isinstance(v, list) or any(not isinstance(x, str) or not x for x in v):
        fail(f"{ctx}: expected list of non-empty strings")
    return v


def validate_task(task: dict):
    req(task, ["schema", "task_id", "project_scopes", "mutation_class", "consequence_classes", "mechanism_tags", "touched_paths", "capabilities"], "task")
    if task["schema"] != SCHEMA_TASK:
        fail("task: schema mismatch")
    if not isinstance(task["task_id"], str) or not task["task_id"]:
        fail("task: task_id must be non-empty string")
    for f in ["project_scopes", "consequence_classes", "mechanism_tags", "touched_paths", "capabilities"]:
        string_list(task[f], f"task.{f}")
    if not isinstance(task["mutation_class"], str) or not task["mutation_class"]:
        fail("task: mutation_class must be non-empty string")


def validate_sidecar(sc: dict, idx: int):
    ctx = f"sidecar[{idx}]"
    req(sc, ["sidecar_id", "project_scope", "subject", "authority_class", "authority_source", "currentness", "provenance", "claim_ceiling", "contact_rules"], ctx)
    if not isinstance(sc["sidecar_id"], str) or not sc["sidecar_id"]:
        fail(f"{ctx}: invalid sidecar_id")
    if not isinstance(sc["project_scope"], str) or not sc["project_scope"]:
        fail(f"{ctx}: invalid project_scope")
    if not isinstance(sc["subject"], dict):
        fail(f"{ctx}: subject must be object")
    req(sc["subject"], ["locator", "subject_class"], ctx + ".subject")
    if not all(isinstance(sc["subject"].get(k), str) and sc["subject"][k] for k in ["locator", "subject_class"]):
        fail(f"{ctx}: invalid subject locator/class")
    if "sha256" in sc["subject"] and sc["subject"]["sha256"] is not None:
        h = sc["subject"]["sha256"]
        if not isinstance(h, str) or len(h) != 64 or any(c not in "0123456789abcdef" for c in h.lower()):
            fail(f"{ctx}: invalid subject.sha256")
    if not isinstance(sc["currentness"], dict):
        fail(f"{ctx}: currentness must be object")
    req(sc["currentness"], ["status", "basis"], ctx + ".currentness")
    if sc["currentness"]["status"] not in CURRENTNESS:
        fail(f"{ctx}: invalid currentness status")
    if not isinstance(sc["currentness"]["basis"], str) or not sc["currentness"]["basis"]:
        fail(f"{ctx}: currentness basis required")
    if not isinstance(sc["contact_rules"], list):
        fail(f"{ctx}: contact_rules must be list")
    for ri, rule in enumerate(sc["contact_rules"]):
        rctx = f"{ctx}.contact_rules[{ri}]"
        req(rule, ["rule_id", "selectors", "contact"], rctx)
        if not isinstance(rule["rule_id"], str) or not rule["rule_id"]:
            fail(f"{rctx}: invalid rule_id")
        if not isinstance(rule["selectors"], dict) or not isinstance(rule["contact"], dict):
            fail(f"{rctx}: selectors/contact must be objects")
        for sf in ["mutation_classes", "consequence_classes", "mechanism_tags", "path_prefixes", "capabilities"]:
            if sf in rule["selectors"]:
                string_list(rule["selectors"][sf], rctx + ".selectors." + sf)
        if "allow_historical" in rule["selectors"] and not isinstance(rule["selectors"]["allow_historical"], bool):
            fail(f"{rctx}: allow_historical must be boolean")
        c = rule["contact"]
        req(c, ["contact_id", "locator", "authority_class", "semantic_extent", "currentness_required", "commit_recheck", "reason"], rctx + ".contact")
        if c["semantic_extent"] not in SEMANTIC_EXTENTS:
            fail(f"{rctx}: invalid semantic_extent")
        for f in ["contact_id", "locator", "authority_class", "reason"]:
            if not isinstance(c[f], str) or not c[f]:
                fail(f"{rctx}: contact.{f} must be non-empty string")
        if not isinstance(c["currentness_required"], bool):
            fail(f"{rctx}: currentness_required must be bool")
        if c["commit_recheck"] not in COMMIT_RECHECK_MODES:
            fail(f"{rctx}: invalid commit_recheck")
        if c["commit_recheck"] == "LOCAL_FILE_SHA256" and not c.get("expected_sha256"):
            fail(f"{rctx}: LOCAL_FILE_SHA256 requires expected_sha256")
        if "expected_sha256" in c and c["expected_sha256"] is not None:
            h = c["expected_sha256"]
            if not isinstance(h, str) or len(h) != 64 or any(ch not in "0123456789abcdef" for ch in h.lower()):
                fail(f"{rctx}: invalid expected_sha256")


def validate_catalog(catalog: dict):
    req(catalog, ["schema", "project_profiles", "sidecars"], "catalog")
    if catalog["schema"] != SCHEMA_CATALOG:
        fail("catalog: schema mismatch")
    if not isinstance(catalog["project_profiles"], list):
        fail("catalog.project_profiles must be list")
    profile_ids = set()
    by_scope = {}
    for pi, pr in enumerate(catalog["project_profiles"]):
        pctx = f"project_profile[{pi}]"
        if not isinstance(pr, dict): fail(pctx + ": must be object")
        req(pr, ["profile_id", "project_scope", "currentness", "rules"], pctx)
        if not isinstance(pr["profile_id"], str) or not pr["profile_id"]: fail(pctx + ": invalid profile_id")
        if pr["profile_id"] in profile_ids: fail("duplicate profile_id: " + pr["profile_id"])
        profile_ids.add(pr["profile_id"])
        if not isinstance(pr["project_scope"], str) or not pr["project_scope"]: fail(pctx + ": invalid project_scope")
        if not isinstance(pr["currentness"], dict): fail(pctx + ": currentness must be object")
        req(pr["currentness"], ["status", "basis"], pctx + ".currentness")
        if pr["currentness"]["status"] not in CURRENTNESS: fail(pctx + ": invalid currentness status")
        if not isinstance(pr["currentness"]["basis"], str) or not pr["currentness"]["basis"]: fail(pctx + ": currentness basis required")
        if not isinstance(pr["rules"], list): fail(pctx + ": rules must be list")
        for ri, rule in enumerate(pr["rules"]):
            rctx=f"{pctx}.rules[{ri}]"
            req(rule,["rule_id","selectors","required_authority_classes","required_sidecar_ids"],rctx)
            if not isinstance(rule["selectors"],dict): fail(rctx+": selectors must be object")
            for sf in ["mutation_classes","consequence_classes","mechanism_tags","path_prefixes","capabilities"]:
                if sf in rule["selectors"]: string_list(rule["selectors"][sf],rctx+".selectors."+sf)
            string_list(rule["required_authority_classes"],rctx+".required_authority_classes")
            string_list(rule["required_sidecar_ids"],rctx+".required_sidecar_ids")
        if pr["currentness"]["status"] == "CURRENT": by_scope.setdefault(pr["project_scope"],[]).append(pr["profile_id"])
    for scope, ids2 in by_scope.items():
        if len(ids2) > 1: fail("multiple CURRENT project profiles for scope " + scope)
    if not isinstance(catalog["sidecars"], list):
        fail("catalog.sidecars must be list")
    ids = set()
    for i, sc in enumerate(catalog["sidecars"]):
        if not isinstance(sc, dict):
            fail(f"sidecar[{i}] must be object")
        validate_sidecar(sc, i)
        if sc["sidecar_id"] in ids:
            fail("duplicate sidecar_id: " + sc["sidecar_id"])
        ids.add(sc["sidecar_id"])
    # Current sidecars claiming the same governed subject must not disagree on pinned subject identity.
    by_subject: dict[tuple[str, str], set[str | None]] = {}
    for sc in catalog["sidecars"]:
        if sc["currentness"]["status"] != "CURRENT":
            continue
        key = (sc["project_scope"], sc["subject"]["locator"])
        by_subject.setdefault(key, set()).add(sc["subject"].get("sha256"))
    for key, hashes in by_subject.items():
        concrete = {h for h in hashes if h is not None}
        if len(concrete) > 1:
            fail(f"contradictory CURRENT sidecars for subject {key}: pinned hashes disagree")


def project_match(sc_scope: str, task_scopes: list[str]) -> bool:
    return sc_scope == "*" or sc_scope in task_scopes


def any_intersects(rule_vals: list[str], task_vals: list[str]) -> bool:
    return not rule_vals or bool(set(rule_vals) & set(task_vals))


def path_prefix_match(prefixes: list[str], touched: list[str]) -> bool:
    if not prefixes:
        return True
    norm = lambda s: s.replace("\\", "/")
    ps = [norm(x) for x in prefixes]
    ts = [norm(x) for x in touched]
    return any(t.startswith(p) for p in ps for t in ts)


def rule_matches(rule: dict, task: dict) -> bool:
    s = rule["selectors"]
    if not any_intersects(string_list(s.get("mutation_classes", []), "selector.mutation_classes"), [task["mutation_class"]]):
        return False
    if not any_intersects(string_list(s.get("consequence_classes", []), "selector.consequence_classes"), task["consequence_classes"]):
        return False
    if not any_intersects(string_list(s.get("mechanism_tags", []), "selector.mechanism_tags"), task["mechanism_tags"]):
        return False
    if not path_prefix_match(string_list(s.get("path_prefixes", []), "selector.path_prefixes"), task["touched_paths"]):
        return False
    if not any_intersects(string_list(s.get("capabilities", []), "selector.capabilities"), task["capabilities"]):
        return False
    return True


def profile_rule_matches(rule: dict, task: dict) -> bool:
    return rule_matches({"selectors": rule["selectors"]}, task)


def resolve(catalog_path: str, task_path: str, output: str):
    catalog = load(catalog_path)
    task = load(task_path)
    validate_catalog(catalog)
    validate_task(task)
    catalog_sha = sha_file(catalog_path)
    task_sha = sha_file(task_path)
    # Project-local orientation is mandatory: the catalog may not define its own completeness by omission.
    profiles_by_scope = {p["project_scope"]: p for p in catalog["project_profiles"] if p["currentness"]["status"] == "CURRENT"}
    orientation_requirements = []
    orientation_errors = []
    sidecars_by_id = {s["sidecar_id"]: s for s in catalog["sidecars"]}
    for scope in task["project_scopes"]:
        pr = profiles_by_scope.get(scope)
        if pr is None:
            orientation_errors.append({"project_scope": scope, "reason": "MISSING_CURRENT_PROJECT_PROFILE"})
            continue
        for rule in pr["rules"]:
            if not profile_rule_matches(rule, task): continue
            for cls in rule["required_authority_classes"]:
                eligible=[s for s in catalog["sidecars"] if s["authority_class"]==cls and project_match(s["project_scope"],task["project_scopes"]) and s["currentness"]["status"]=="CURRENT"]
                if not eligible:
                    orientation_errors.append({"project_scope": scope, "profile_id": pr["profile_id"], "rule_id": rule["rule_id"], "reason": "MISSING_REQUIRED_AUTHORITY_CLASS", "authority_class": cls})
            for sid in rule["required_sidecar_ids"]:
                s=sidecars_by_id.get(sid)
                if s is None or s["currentness"]["status"]!="CURRENT":
                    orientation_errors.append({"project_scope": scope, "profile_id": pr["profile_id"], "rule_id": rule["rule_id"], "reason": "MISSING_OR_NONCURRENT_REQUIRED_SIDECAR", "sidecar_id": sid})
            orientation_requirements.append({"project_scope":scope,"profile_id":pr["profile_id"],"rule_id":rule["rule_id"],"required_authority_classes":rule["required_authority_classes"],"required_sidecar_ids":rule["required_sidecar_ids"]})
    contacts: dict[str, dict] = {}
    matched_sidecars = []
    rejection_reasons = list(orientation_errors)
    for sc in catalog["sidecars"]:
        if not project_match(sc["project_scope"], task["project_scopes"]):
            continue
        matched_rules = [r for r in sc["contact_rules"] if rule_matches(r, task)]
        if not matched_rules:
            continue
        status = sc["currentness"]["status"]
        allow_hist = all(bool(r["selectors"].get("allow_historical")) for r in matched_rules)
        if status == "HISTORICAL_SUPERSEDED" and not allow_hist:
            rejection_reasons.append({"sidecar_id": sc["sidecar_id"], "reason": "MATCHED_HISTORICAL_SIDECAR_FOR_CURRENT_TASK"})
            continue
        if status in {"UNKNOWN", "CONTRADICTORY"}:
            rejection_reasons.append({"sidecar_id": sc["sidecar_id"], "reason": "MATCHED_SIDECAR_CURRENTNESS_" + status})
            continue
        matched_sidecars.append(sc["sidecar_id"])
        for rule in matched_rules:
            c = dict(rule["contact"])
            c["origin_sidecar_id"] = sc["sidecar_id"]
            c["origin_rule_id"] = rule["rule_id"]
            c["sidecar_currentness_status"] = status
            c["sidecar_currentness_basis"] = sc["currentness"]["basis"]
            c["project_scope"] = sc["project_scope"]
            cid = c["contact_id"]
            if cid in contacts:
                # Same contact_id may be required by many rules only if requirement is semantically identical apart from origin.
                old = contacts[cid]
                comparable = ["locator", "authority_class", "semantic_extent", "currentness_required", "commit_recheck", "expected_sha256"]
                if any(old.get(k) != c.get(k) for k in comparable):
                    fail("conflicting contact definition for contact_id " + cid)
                old.setdefault("additional_origins", []).append({"sidecar_id": sc["sidecar_id"], "rule_id": rule["rule_id"], "reason": c["reason"]})
            else:
                contacts[cid] = c
    # Orientation completeness is about actual task contact, not catalog presence.
    for reqrow in orientation_requirements:
        for cls in reqrow["required_authority_classes"]:
            if not any(e.get("authority_class") == cls for e in contacts.values()):
                rejection_reasons.append({"project_scope": reqrow["project_scope"], "profile_id": reqrow["profile_id"], "rule_id": reqrow["rule_id"], "reason": "REQUIRED_AUTHORITY_CLASS_DID_NOT_CONTRIBUTE_CONTACT", "authority_class": cls})
        for sid in reqrow["required_sidecar_ids"]:
            def origin_matches(e):
                if e.get("origin_sidecar_id") == sid: return True
                return any(x.get("sidecar_id") == sid for x in e.get("additional_origins", []))
            if not any(origin_matches(e) for e in contacts.values()):
                rejection_reasons.append({"project_scope": reqrow["project_scope"], "profile_id": reqrow["profile_id"], "rule_id": reqrow["rule_id"], "reason": "REQUIRED_SIDECAR_DID_NOT_CONTRIBUTE_CONTACT", "sidecar_id": sid})
    payload = {
        "schema": SCHEMA_CONTACT_SET,
        "status": "CONTACT_SET_REJECTED" if rejection_reasons else "CONTACT_SET_DERIVED",
        "task": task,
        "task_sha256": task_sha,
        "catalog_sha256": catalog_sha,
        "matched_sidecars": sorted(set(matched_sidecars)),
        "orientation_requirements": orientation_requirements,
        "entries": [contacts[k] for k in sorted(contacts)],
        "rejection_reasons": rejection_reasons,
        "laws": ["LOCATOR != AUTHORITY", "CONTACT_SET_DERIVED != COMPLETE_WORLD_MODEL", "CONTACT_SET_SATISFIED != AUTHORITY_GRANTED"]
    }
    digest_basis = dict(payload)
    payload["contact_set_sha256"] = sha_bytes(canonical(digest_basis))
    write_json(output, payload)
    print(json.dumps({"ok": not rejection_reasons, "state": payload["status"], "contacts": len(payload["entries"]), "contact_set_sha256": payload["contact_set_sha256"], "output": str(output)}, sort_keys=True))
    if rejection_reasons:
        raise SystemExit(3)


def validate_receipt(r: dict, idx: int):
    ctx = f"receipt[{idx}]"
    req(r, ["contact_set_sha256", "contact_id", "locator", "observed_sha256", "semantic_extent", "governing_scope", "currentness_basis", "read_by", "read_at", "read_note"], ctx)
    for f in ["contact_set_sha256", "contact_id", "locator", "semantic_extent", "governing_scope", "currentness_basis", "read_by", "read_at", "read_note"]:
        if not isinstance(r[f], str) or not r[f].strip():
            fail(f"{ctx}: {f} must be non-empty string")
    if r["semantic_extent"] not in SEMANTIC_EXTENTS:
        fail(f"{ctx}: invalid semantic extent")
    h = r["observed_sha256"]
    if not isinstance(h, str) or len(h) != 64 or any(ch not in "0123456789abcdef" for ch in h.lower()):
        fail(f"{ctx}: invalid observed_sha256")


def authorize(contact_set_path: str, receipts_path: str, catalog_path: str, task_path: str, output: str):
    cs = load(contact_set_path)
    receipts = load(receipts_path)
    req(cs, ["schema", "status", "task", "catalog_sha256", "entries", "contact_set_sha256"], "contact_set")
    if cs["schema"] != SCHEMA_CONTACT_SET:
        fail("contact_set schema mismatch")
    if cs["status"] != "CONTACT_SET_DERIVED":
        fail("contact_set is not eligible for admission")
    if cs.get("catalog_sha256") != sha_file(catalog_path):
        fail("catalog changed since contact-set derivation")
    if cs.get("task_sha256") != sha_file(task_path):
        fail("task changed since contact-set derivation")
    # Re-derive from current catalog + task. A self-consistent contact-set digest does not prove completeness.
    with tempfile.TemporaryDirectory(prefix="rahl_contact_rederive_") as td:
        rp = Path(td) / "expected.json"
        sink = io.StringIO()
        with contextlib.redirect_stdout(sink):
            resolve(catalog_path, task_path, str(rp))
        expected_cs = load(rp)
    if cs != expected_cs:
        fail("contact_set differs from current re-derived requirement set")
    digest_basis = dict(cs)
    claimed = digest_basis.pop("contact_set_sha256")
    if sha_bytes(canonical(digest_basis)) != claimed:
        fail("contact_set digest mismatch")
    req(receipts, ["schema", "receipts"], "receipts")
    if receipts["schema"] != SCHEMA_RECEIPTS or not isinstance(receipts["receipts"], list):
        fail("receipt bundle schema/list mismatch")
    by_id = {}
    for i, r in enumerate(receipts["receipts"]):
        validate_receipt(r, i)
        if r["contact_id"] in by_id:
            fail("duplicate receipt contact_id: " + r["contact_id"])
        by_id[r["contact_id"]] = r
    errors = []
    task_scope = "+".join(sorted(cs["task"]["project_scopes"])) + "|" + cs["task"]["task_id"]
    for e in cs["entries"]:
        cid = e["contact_id"]
        r = by_id.get(cid)
        if r is None:
            errors.append({"contact_id": cid, "error": "MISSING_RECEIPT"})
            continue
        if r["contact_set_sha256"] != claimed:
            errors.append({"contact_id": cid, "error": "WRONG_CONTACT_SET"})
        if r["locator"] != e["locator"]:
            errors.append({"contact_id": cid, "error": "WRONG_LOCATOR"})
        if r["governing_scope"] != task_scope:
            errors.append({"contact_id": cid, "error": "WRONG_GOVERNING_SCOPE"})
        if r["semantic_extent"] != e["semantic_extent"]:
            errors.append({"contact_id": cid, "error": "WRONG_SEMANTIC_EXTENT"})
        expected = e.get("expected_sha256")
        if expected and r["observed_sha256"] != expected:
            errors.append({"contact_id": cid, "error": "WRONG_HASH"})
        if e.get("commit_recheck") == "LOCAL_FILE_SHA256":
            source_path = Path(e["locator"])
            if not source_path.is_absolute():
                source_path = ROOT / source_path
            if not source_path.exists() or not source_path.is_file():
                errors.append({"contact_id": cid, "error": "LOCAL_SOURCE_MISSING_AT_ADMISSION", "locator": e["locator"]})
            else:
                actual_now = sha_file(source_path)
                if not expected or actual_now != expected:
                    errors.append({"contact_id": cid, "error": "LOCAL_SOURCE_DRIFT_AT_ADMISSION", "expected_sha256": expected, "actual_sha256": actual_now})
        if e.get("currentness_required") and not r["currentness_basis"].strip():
            errors.append({"contact_id": cid, "error": "MISSING_CURRENTNESS_BASIS"})
        if e["semantic_extent"] in {"FULL_ARTIFACT", "BOUNDED_SEMANTIC_SECTION"} and r["semantic_extent"] == "INTEGRITY_ONLY":
            errors.append({"contact_id": cid, "error": "INTEGRITY_ONLY_CANNOT_SATISFY_SEMANTIC_CONTACT"})
        if r["read_note"].strip().upper() in {"ACK", "ACKNOWLEDGED", "READ", "OK"}:
            errors.append({"contact_id": cid, "error": "NON_SUBSTANTIVE_ACKNOWLEDGEMENT_NOTE"})
    extra = sorted(set(by_id) - {e["contact_id"] for e in cs["entries"]})
    result = {
        "schema": SCHEMA_AUTH,
        "state": "CONTACT_SET_REJECTED" if errors else "CONTACT_SET_SATISFIED",
        "contact_set_sha256": claimed,
        "task_id": cs["task"]["task_id"],
        "required_contacts": len(cs["entries"]),
        "receipt_contacts": len(by_id),
        "errors": errors,
        "extra_receipts_ignored": extra,
        "authority_effect": "NONE",
        "laws": ["CONTACT_RECEIPT != COMPREHENSION", "CONTACT_RECEIPT != MUTATION_AUTHORIZATION", "CONTACT_SET_SATISFIED != AUTHORITY_GRANTED"]
    }
    result["result_sha256"] = sha_bytes(canonical(result))
    write_json(output, result)
    print(json.dumps({"ok": not errors, "state": result["state"], "errors": len(errors), "result_sha256": result["result_sha256"], "output": str(output)}, sort_keys=True))
    if errors:
        raise SystemExit(4)


def main():
    ap = argparse.ArgumentParser(description="Rahl governance sidecar / required-contact resolver candidate")
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("resolve")
    p.add_argument("--catalog", required=True)
    p.add_argument("--task", required=True)
    p.add_argument("--output", required=True)
    p.set_defaults(fn=lambda a: resolve(a.catalog, a.task, a.output))
    p = sp.add_parser("authorize")
    p.add_argument("--contact-set", required=True)
    p.add_argument("--receipts", required=True)
    p.add_argument("--catalog", required=True)
    p.add_argument("--task", required=True)
    p.add_argument("--output", required=True)
    p.set_defaults(fn=lambda a: authorize(a.contact_set, a.receipts, a.catalog, a.task, a.output))
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
