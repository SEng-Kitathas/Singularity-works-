#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import ast, hashlib, json, sys

ROOT=Path(__file__).resolve().parents[1]
PROSE=ROOT/'state/doctrine_snapshot/GOVERNANCE_SIDECAR_AND_CONTACT_GATE_CANDIDATE.md'
CONTRACT=ROOT/'machine/GOVERNANCE_CONTACT_SIDECAR_CONTRACT.json'
RESOLVER=ROOT/'tools/governance_contact_resolver.py'
HOSTILE=ROOT/'tools/test_governance_contact_resolver_hostile.py'

REQUIRED_LAWS=[
'DATA != GOVERNANCE',
'GOVERNANCE_BELONGS_BESIDE_DATA_NOT_INSIDE_DATA',
'LOCALLY_ENUMERABLE + LOCATABLE != GLOBALLY_COMPREHENDED',
'LOCATABLE != PRELOADED',
'SIDECAR != TRUTH',
'LOCATOR != AUTHORITY',
'KNOWLEDGE_AGGREGATED != KNOWLEDGE_CONTACTED',
'FILE_EXISTS + ACKNOWLEDGED != GOVERNANCE',
'CATALOG_CONTENT != CATALOG_COMPLETENESS',
'ORIENTATION_PROFILE_PRESENT != ORIENTATION_PROFILE_CURRENT',
'REQUIRED_CLASS_PRESENT != REQUIRED_CLASS_CONTACTED',
'CONTACT_SET_HASH_VALID != CONTACT_SET_COMPLETE',
'CONTACT_SET_DERIVED != COMPLETE_WORLD_MODEL',
'CONTACT_RECEIPT != COMPREHENSION',
'CONTACT_RECEIPT != MUTATION_AUTHORIZATION',
'CONTACT_SET_SATISFIED != AUTHORITY_GRANTED',
'CONTACT_GATE != NEW_AUTHORITY_SYSTEM',
'CONTACT_FRESH_AT_PREFLIGHT != CONTACT_FRESH_AT_COMMIT',
'CONTACT_RECEIPT_VALID != SOURCE_UNCHANGED_SINCE_CONTACT',
'LOCAL_FILE_CONTACT_REQUIRES_COMMIT_REHASH',
'SUPERSESSION != SOURCE_REWRITE',
'LATEST_FILENAME != CURRENT_AUTHORITY',
'ENDPOINT_CONNECTED != ENVIRONMENT_UNDERSTOOD',
'GOVERNANCE_SURFACE_LOCATOR != GOVERNANCE_AUTHORITY',
'GUARD_PRESENT != MUTATION_PATH_GUARDED']

REQUIRED_HOSTILES=[
'missing_project_profile','missing_commander_sidecar','missing_matching_scar_sidecar','forged_authority_class_cannot_replace_pinned_sidecar','required_class_present_but_not_contacted','historical_project_profile','historical_required_commander','unknown_matched_scar','duplicate_current_project_profiles','contradictory_current_subject_hash','conflicting_contact_definition','invalid_commit_recheck_mode','missing_receipt','ack_only_receipt','missing_currentness_basis','global_preload_not_substitute_for_required_contacts','archive_member_located_not_semantically_read','wrong_receipt_hash','wrong_receipt_scope','wrong_receipt_locator','wrong_semantic_extent','wrong_contact_set_in_receipt','contact_set_self_deletion_and_resign','catalog_changes_after_resolve','task_scope_expands_after_resolve','contact_set_embeds_smaller_task_and_resigns','local_source_drift_after_receipt']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(msg):print(json.dumps({'ok':False,'error':msg},sort_keys=True));raise SystemExit(2)

def main():
    for p in [PROSE,CONTRACT,RESOLVER,HOSTILE]:
        if not p.exists():fail('missing candidate member: '+str(p.relative_to(ROOT)))
    prose=PROSE.read_text(encoding='utf-8')
    contract=json.loads(CONTRACT.read_text(encoding='utf-8'))
    resolver=RESOLVER.read_text(encoding='utf-8')
    hostile=HOSTILE.read_text(encoding='utf-8')
    ast.parse(resolver);ast.parse(hostile)
    if 'Status: `CANDIDATE_NOT_BINDING`' not in prose or 'Authority effect: `NONE`' not in prose:fail('prose candidate ceiling missing')
    if contract.get('schema')!='rahl.governance-contact-sidecar.v0-candidate':fail('contract schema')
    if contract.get('status')!='CANDIDATE_NOT_BINDING' or contract.get('authority_effect')!='NONE' or contract.get('privileged_core_effect')!='NONE':fail('contract authority ceiling')
    for f in ['catalog_required_fields','project_profile_required_fields','sidecar_required_fields','task_required_fields','contact_receipt_required_fields','promotion_prerequisites']:
        if not contract.get(f):fail('empty/missing contract field '+f)
    laws=set(contract.get('laws',[]))
    for law in REQUIRED_LAWS:
        if law not in laws:fail('contract missing law '+law)
        if law not in prose:fail('prose missing law '+law)
    for witness in ['project_profiles','MISSING_CURRENT_PROJECT_PROFILE','MISSING_REQUIRED_AUTHORITY_CLASS','contact_set differs from current re-derived requirement set','catalog changed since contact-set derivation','task changed since contact-set derivation','NON_SUBSTANTIVE_ACKNOWLEDGEMENT_NOTE','REQUIRED_AUTHORITY_CLASS_DID_NOT_CONTRIBUTE_CONTACT','REQUIRED_SIDECAR_DID_NOT_CONTRIBUTE_CONTACT','LOCAL_SOURCE_DRIFT_AT_ADMISSION','LOCAL_SOURCE_MISSING_AT_ADMISSION','COMMIT_RECHECK_MODES']:
        if witness not in resolver:fail('resolver witness missing '+witness)
    for name in REQUIRED_HOSTILES:
        if name not in hostile:fail('hostile case missing '+name)
    for name in ['explicit_historical_contact_allowed','duplicate_exact_scar_does_not_mint_extra_contact','local_source_unchanged_commit_recheck_passes']:
        if name not in hostile:fail('positive control missing '+name)
    result={'ok':True,'state':'CANDIDATE_STRUCTURAL_VERIFICATION_PASS','authority_effect':'NONE','members':{
        str(PROSE.relative_to(ROOT)).replace('\\','/'):sha(PROSE),
        str(CONTRACT.relative_to(ROOT)).replace('\\','/'):sha(CONTRACT),
        str(RESOLVER.relative_to(ROOT)).replace('\\','/'):sha(RESOLVER),
        str(HOSTILE.relative_to(ROOT)).replace('\\','/'):sha(HOSTILE)},
        'required_law_count':len(REQUIRED_LAWS),'required_hostile_case_count':len(REQUIRED_HOSTILES),
        'claim_ceiling':['STRUCTURAL_VERIFICATION != SEMANTIC_COMPREHENSION','VERIFIER_PASS != HOSTILE_QUALIFICATION','CANDIDATE_PASS != BINDING_DOCTRINE']}
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':main()
