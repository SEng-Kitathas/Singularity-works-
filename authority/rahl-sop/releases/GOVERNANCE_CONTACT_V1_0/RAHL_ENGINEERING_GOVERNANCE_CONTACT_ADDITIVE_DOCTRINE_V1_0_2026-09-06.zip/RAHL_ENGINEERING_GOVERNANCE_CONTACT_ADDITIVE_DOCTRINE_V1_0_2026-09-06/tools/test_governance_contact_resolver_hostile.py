#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import copy, hashlib, json, subprocess, sys, tempfile

ROOT = Path(__file__).resolve().parents[1]
RESOLVER = ROOT / "tools/governance_contact_resolver.py"


def dump(p: Path, obj):
    p.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")


def canonical(obj) -> bytes:
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def run(*args):
    return subprocess.run([sys.executable, str(RESOLVER), *map(str, args)], cwd=ROOT, capture_output=True, text=True, timeout=15)


def baseline_catalog():
    return {
        "schema": "rahl.governance-sidecar-catalog.v0-candidate",
        "project_profiles": [
            {
                "profile_id": "demo-orientation-current",
                "project_scope": "demo",
                "currentness": {"status": "CURRENT", "basis": "demo current orientation pointer"},
                "rules": [
                    {
                        "rule_id": "consequential-demo-governance",
                        "selectors": {"mutation_classes": ["OTHER_CONSEQUENTIAL"]},
                        "required_authority_classes": ["CANONICAL_DOCTRINE", "COMMANDER_INTENT"],
                        "required_sidecar_ids": ["global-doctrine", "demo-commander"]
                    },
                    {
                        "rule_id": "derived-projection-scar-coverage",
                        "selectors": {"mechanism_tags": ["DERIVED_PROJECTION"]},
                        "required_authority_classes": ["SCAR"],
                        "required_sidecar_ids": []
                    }
                ]
            }
        ],
        "sidecars": [
            {
                "sidecar_id": "global-doctrine",
                "project_scope": "*",
                "subject": {"locator": "doctrine/R4.4.md", "subject_class": "DOCTRINE", "sha256": "a" * 64},
                "authority_class": "CANONICAL_DOCTRINE",
                "authority_source": "canonical receipt",
                "currentness": {"status": "CURRENT", "basis": "canonical release receipt"},
                "provenance": ["R4.4"],
                "claim_ceiling": "PROCESS_ONLY",
                "contact_rules": [
                    {
                        "rule_id": "doctrine-for-consequence",
                        "selectors": {"consequence_classes": ["AUTHORITY_RELEVANT"]},
                        "contact": {
                            "contact_id": "contact-doctrine",
                            "locator": "doctrine/R4.4.md",
                            "authority_class": "CANONICAL_DOCTRINE",
                            "semantic_extent": "FULL_ARTIFACT",
                            "currentness_required": True,
                            "commit_recheck": "RECEIPT_BOUND_EXTERNAL",
                            "expected_sha256": "a" * 64,
                            "reason": "Current canonical process doctrine governs consequential work."
                        }
                    }
                ]
            },
            {
                "sidecar_id": "demo-commander",
                "project_scope": "demo",
                "subject": {"locator": "state/COMMANDERS_INTENT_CURRENT.md", "subject_class": "COMMANDER_INTENT", "sha256": "b" * 64},
                "authority_class": "COMMANDER_INTENT",
                "authority_source": "project current pointer",
                "currentness": {"status": "CURRENT", "basis": "project-local current intent pointer"},
                "provenance": ["demo project"],
                "claim_ceiling": "PROJECT_DIRECTION_ONLY",
                "contact_rules": [
                    {
                        "rule_id": "intent-before-consequence",
                        "selectors": {"mutation_classes": ["OTHER_CONSEQUENTIAL"]},
                        "contact": {
                            "contact_id": "contact-intent",
                            "locator": "state/COMMANDERS_INTENT_CURRENT.md",
                            "authority_class": "COMMANDER_INTENT",
                            "semantic_extent": "FULL_ARTIFACT",
                            "currentness_required": True,
                            "commit_recheck": "RECEIPT_BOUND_EXTERNAL",
                            "expected_sha256": "b" * 64,
                            "reason": "Current project intent must constrain consequential mutation."
                        }
                    }
                ]
            },
            {
                "sidecar_id": "cross-project-fold-scar",
                "project_scope": "*",
                "subject": {"locator": "scars/derived-fold.md", "subject_class": "SCAR", "sha256": "c" * 64},
                "authority_class": "SCAR",
                "authority_source": "provenance-clean scar ledger",
                "currentness": {"status": "CURRENT", "basis": "scar registry current pointer"},
                "provenance": ["HSP", "RD", "NEXUS"],
                "claim_ceiling": "COUNTERPRESSURE_NOT_AUTHORITY",
                "contact_rules": [
                    {
                        "rule_id": "fold-topology-scar",
                        "selectors": {"mechanism_tags": ["DERIVED_PROJECTION"]},
                        "contact": {
                            "contact_id": "contact-fold-scar",
                            "locator": "scars/derived-fold.md",
                            "authority_class": "SCAR",
                            "semantic_extent": "FULL_ARTIFACT",
                            "currentness_required": True,
                            "commit_recheck": "RECEIPT_BOUND_EXTERNAL",
                            "expected_sha256": "c" * 64,
                            "reason": "Known repeated-rebuild failure topology matches this task."
                        }
                    }
                ]
            }
        ]
    }


def baseline_task():
    return {
        "schema": "rahl.governance-task.v0-candidate",
        "task_id": "task-1",
        "project_scopes": ["demo"],
        "mutation_class": "OTHER_CONSEQUENTIAL",
        "consequence_classes": ["AUTHORITY_RELEVANT"],
        "mechanism_tags": ["DERIVED_PROJECTION"],
        "touched_paths": ["state/foo.md"],
        "capabilities": ["WRITE_PROJECT_STATE"]
    }


def make_receipts(cs):
    scope = "demo|task-1"
    rows = []
    for e in cs["entries"]:
        rows.append({
            "contact_set_sha256": cs["contact_set_sha256"],
            "contact_id": e["contact_id"],
            "locator": e["locator"],
            "observed_sha256": e.get("expected_sha256") or ("d" * 64),
            "semantic_extent": e["semantic_extent"],
            "governing_scope": scope,
            "currentness_basis": "verified current pointer/readback for task",
            "read_by": "hostile-suite-attester",
            "read_at": "2026-09-06T20:30:00+00:00",
            "read_note": "Complete semantic contact performed against exact bound bytes for the stated task scope."
        })
    return {"schema": "rahl.contact-receipts.v0-candidate", "receipts": rows}


def resolve_case(td: Path, catalog, task):
    cp, tp, op = td / "catalog.json", td / "task.json", td / "contact_set.json"
    dump(cp, catalog); dump(tp, task)
    r = run("resolve", "--catalog", cp, "--task", tp, "--output", op)
    return r, cp, tp, op


def authorize_case(td: Path, catalog, task, mutate_cs=None, mutate_receipts=None, mutate_catalog_after=None, mutate_task_after=None):
    r, cp, tp, csp = resolve_case(td, catalog, task)
    if r.returncode != 0:
        return r
    cs = json.loads(csp.read_text(encoding="utf-8"))
    receipts = make_receipts(cs)
    if mutate_cs: mutate_cs(cs)
    if mutate_receipts: mutate_receipts(receipts)
    dump(csp, cs)
    rp, out = td / "receipts.json", td / "auth.json"
    dump(rp, receipts)
    if mutate_catalog_after:
        cat2 = json.loads(cp.read_text(encoding="utf-8")); mutate_catalog_after(cat2); dump(cp, cat2)
    if mutate_task_after:
        task2 = json.loads(tp.read_text(encoding="utf-8")); mutate_task_after(task2); dump(tp, task2)
    return run("authorize", "--contact-set", csp, "--receipts", rp, "--catalog", cp, "--task", tp, "--output", out)


def recompute_contact_set_digest(cs):
    basis = dict(cs)
    basis.pop("contact_set_sha256", None)
    cs["contact_set_sha256"] = hashlib.sha256(canonical(basis)).hexdigest()


def main():
    if not RESOLVER.exists():
        raise SystemExit("resolver missing")
    cases = []
    with tempfile.TemporaryDirectory(prefix="rahl_governance_contact_hostile_") as tmp:
        base = Path(tmp)
        # Positive baseline.
        td = base / "baseline"; td.mkdir()
        r, cp, tp, csp = resolve_case(td, baseline_catalog(), baseline_task())
        if r.returncode != 0:
            print("BASELINE_RESOLVE_FAIL", r.stdout, r.stderr); raise SystemExit(1)
        cs = json.loads(csp.read_text(encoding="utf-8"))
        if len(cs["entries"]) != 3:
            print("BASELINE_CONTACT_COUNT_FAIL", len(cs["entries"])); raise SystemExit(1)
        rp = td / "receipts.json"; dump(rp, make_receipts(cs))
        ar = run("authorize", "--contact-set", csp, "--receipts", rp, "--catalog", cp, "--task", tp, "--output", td / "auth.json")
        if ar.returncode != 0:
            print("BASELINE_AUTHORIZE_FAIL", ar.stdout, ar.stderr); raise SystemExit(1)

        def add(name, fn, expected_nonzero=True):
            td = base / name; td.mkdir()
            r = fn(td)
            rejected = r.returncode != 0
            cases.append({"name": name, "rejected": rejected, "return_code": r.returncode, "stdout_tail": r.stdout[-500:], "stderr_tail": r.stderr[-300:]})
            if rejected != expected_nonzero:
                print("UNEXPECTED", name, r.returncode, r.stdout, r.stderr)

        add("missing_project_profile", lambda td: resolve_case(td, {**baseline_catalog(), "project_profiles": []}, baseline_task())[0])
        add("missing_commander_sidecar", lambda td: resolve_case(td, {**baseline_catalog(), "sidecars": [s for s in baseline_catalog()["sidecars"] if s["authority_class"] != "COMMANDER_INTENT"]}, baseline_task())[0])
        add("missing_matching_scar_sidecar", lambda td: resolve_case(td, {**baseline_catalog(), "sidecars": [s for s in baseline_catalog()["sidecars"] if s["authority_class"] != "SCAR"]}, baseline_task())[0])
        def forged_commander_authority(td):
            c=baseline_catalog(); c["sidecars"]=[s for s in c["sidecars"] if s["sidecar_id"]!="demo-commander"]
            fake=copy.deepcopy(baseline_catalog()["sidecars"][1]); fake["sidecar_id"]="forged-commander"; fake["subject"]["locator"]="donor/fake_intent.md"; fake["subject"]["sha256"]="9"*64; c["sidecars"].append(fake)
            return resolve_case(td,c,baseline_task())[0]
        add("forged_authority_class_cannot_replace_pinned_sidecar", forged_commander_authority)
        def required_class_selector_does_not_fire(td):
            c=baseline_catalog(); c["sidecars"][1]["contact_rules"][0]["selectors"]={"mutation_classes":["AUTHORITY"]}
            return resolve_case(td,c,baseline_task())[0]
        add("required_class_present_but_not_contacted", required_class_selector_does_not_fire)
        add("historical_project_profile", lambda td: resolve_case(td, (lambda c: (c["project_profiles"][0]["currentness"].update({"status":"HISTORICAL_SUPERSEDED"}) or c))(baseline_catalog()), baseline_task())[0])
        add("historical_required_commander", lambda td: resolve_case(td, (lambda c: (c["sidecars"][1]["currentness"].update({"status":"HISTORICAL_SUPERSEDED"}) or c))(baseline_catalog()), baseline_task())[0])
        add("unknown_matched_scar", lambda td: resolve_case(td, (lambda c: (c["sidecars"][2]["currentness"].update({"status":"UNKNOWN"}) or c))(baseline_catalog()), baseline_task())[0])
        add("duplicate_current_project_profiles", lambda td: resolve_case(td, (lambda c: (c["project_profiles"].append(copy.deepcopy(c["project_profiles"][0])) or c))(baseline_catalog()), baseline_task())[0])
        def contradictory(td):
            c=baseline_catalog(); x=copy.deepcopy(c["sidecars"][1]); x["sidecar_id"]="demo-commander-conflict"; x["subject"]["sha256"]="e"*64; c["sidecars"].append(x); return resolve_case(td,c,baseline_task())[0]
        add("contradictory_current_subject_hash", contradictory)
        def contact_conflict(td):
            c=baseline_catalog(); x=copy.deepcopy(c["sidecars"][2]); x["sidecar_id"]="scar-conflict"; x["contact_rules"][0]["contact"]["locator"]="scars/other.md"; c["sidecars"].append(x); return resolve_case(td,c,baseline_task())[0]
        add("conflicting_contact_definition", contact_conflict)
        def invalid_commit_recheck(td):
            c=baseline_catalog(); c["sidecars"][0]["contact_rules"][0]["contact"]["commit_recheck"]="MAGIC"
            return resolve_case(td,c,baseline_task())[0]
        add("invalid_commit_recheck_mode", invalid_commit_recheck)
        add("missing_receipt", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"].pop()))
        add("ack_only_receipt", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"read_note":"ACKNOWLEDGED"})))
        add("missing_currentness_basis", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"currentness_basis":""})))
        def global_preload_only(r):
            r["receipts"]=[{"contact_set_sha256":r["receipts"][0]["contact_set_sha256"],"contact_id":"global-preload","locator":"context://all","observed_sha256":"8"*64,"semantic_extent":"FULL_ARTIFACT","governing_scope":"demo|task-1","currentness_basis":"preloaded context","read_by":"agent","read_at":"2026-09-06T20:30:00+00:00","read_note":"Entire governance corpus was preloaded instead of contacting required entries."}]
        add("global_preload_not_substitute_for_required_contacts", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=global_preload_only))
        add("archive_member_located_not_semantically_read", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"semantic_extent":"INTEGRITY_ONLY","read_note":"Archive member located and hash observed; semantic content not read."})))
        add("wrong_receipt_hash", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"observed_sha256":"f"*64})))
        add("wrong_receipt_scope", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"governing_scope":"wrong|task"})))
        add("wrong_receipt_locator", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"locator":"wrong/path"})))
        add("wrong_semantic_extent", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"semantic_extent":"INTEGRITY_ONLY"})))
        add("wrong_contact_set_in_receipt", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_receipts=lambda r:r["receipts"][0].update({"contact_set_sha256":"0"*64})))
        def drop_and_resign(cs): cs["entries"].pop(); recompute_contact_set_digest(cs)
        add("contact_set_self_deletion_and_resign", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_cs=drop_and_resign))
        add("catalog_changes_after_resolve", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_catalog_after=lambda c:c["sidecars"][1]["currentness"].update({"status":"HISTORICAL_SUPERSEDED"})))
        add("task_scope_expands_after_resolve", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_task_after=lambda t:t["project_scopes"].append("other-project")))
        def mutate_task_inside_cs(cs):
            cs["task"]["mechanism_tags"]=[]; recompute_contact_set_digest(cs)
        add("contact_set_embeds_smaller_task_and_resigns", lambda td: authorize_case(td,baseline_catalog(),baseline_task(),mutate_cs=mutate_task_inside_cs))
        def local_source_catalog(td):
            src=td/"local_source.txt"; src.write_text("VERSION_A\n",encoding="utf-8",newline="\n")
            hs=hashlib.sha256(src.read_bytes()).hexdigest()
            c=baseline_catalog(); s=c["sidecars"][0]; contact=s["contact_rules"][0]["contact"]
            s["subject"]["locator"]=str(src); s["subject"]["sha256"]=hs
            contact["locator"]=str(src); contact["expected_sha256"]=hs; contact["commit_recheck"]="LOCAL_FILE_SHA256"
            return c,src
        def local_source_drift_after_receipt(td):
            c,src=local_source_catalog(td)
            return authorize_case(td,c,baseline_task(),mutate_receipts=lambda receipts: src.write_text("VERSION_B\n",encoding="utf-8",newline="\n"))
        add("local_source_drift_after_receipt", local_source_drift_after_receipt)
        def local_source_unchanged(td):
            c,src=local_source_catalog(td)
            return authorize_case(td,c,baseline_task())
        add("local_source_unchanged_commit_recheck_passes", local_source_unchanged, expected_nonzero=False)
        def historical_allowed(td):
            c=baseline_catalog(); c["sidecars"][2]["currentness"].update({"status":"HISTORICAL_SUPERSEDED"}); c["sidecars"][2]["contact_rules"][0]["selectors"]={"mutation_classes":["ARCHAEOLOGY"],"allow_historical":True}
            task=baseline_task(); task["mutation_class"]="ARCHAEOLOGY"; task["mechanism_tags"]=[]
            r,_,_,op=resolve_case(td,c,task)
            return r
        # Historical explicitly allowed is a positive control; it should NOT be rejected.
        add("explicit_historical_contact_allowed", historical_allowed, expected_nonzero=False)
        def duplicate_exact_scar_collapses(td):
            c=baseline_catalog(); x=copy.deepcopy(c["sidecars"][2]); x["sidecar_id"]="cross-project-fold-scar-exact-copy"; c["sidecars"].append(x)
            r,_,_,op=resolve_case(td,c,baseline_task())
            if r.returncode==0:
                cs=json.loads(op.read_text(encoding="utf-8"))
                if len(cs["entries"])!=3: return subprocess.CompletedProcess(r.args,9,r.stdout+"\nDUPLICATE_CONTACT_COUNT",r.stderr)
            return r
        add("duplicate_exact_scar_does_not_mint_extra_contact", duplicate_exact_scar_collapses, expected_nonzero=False)

    positive_names={"explicit_historical_contact_allowed","duplicate_exact_scar_does_not_mint_extra_contact","local_source_unchanged_commit_recheck_passes"}
    unexpected=[c for c in cases if c["name"] not in positive_names and not c["rejected"]] + [c for c in cases if c["name"] in positive_names and c["rejected"]]
    hostile=[c for c in cases if c["name"] not in positive_names]
    out={"baseline":"PASS","hostile_expected":len(hostile),"hostile_rejected":sum(1 for c in hostile if c["rejected"]),"positive_controls":len(positive_names),"positive_controls_passed":sum(1 for c in cases if c["name"] in positive_names and not c["rejected"]),"unexpected":unexpected,"cases":cases}
    print(json.dumps(out,indent=2,sort_keys=True))
    raise SystemExit(0 if not unexpected and out["hostile_rejected"]==len(hostile) else 1)


if __name__ == "__main__":
    main()
